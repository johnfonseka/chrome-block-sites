"use strict";
(() => {
  var Yt = "4.1.14";
  var Pe = 92,
    We = 47,
    qe = 42,
    Zt = 34,
    Jt = 39,
    Ui = 58,
    Ge = 59,
    le = 10,
    Ye = 13,
    Oe = 32,
    He = 9,
    Qt = 123,
    yt = 125,
    Ct = 40,
    Xt = 41,
    zi = 91,
    Ki = 93,
    er = 45,
    xt = 64,
    Li = 33;
  function Se(e, r) {
    let i = r?.from ? { file: r.from, code: e } : null;
    e[0] === "\uFEFF" && (e = " " + e.slice(1));
    let t = [],
      o = [],
      s = [],
      a = null,
      d = null,
      u = "",
      c = "",
      m = 0,
      g;
    for (let p = 0; p < e.length; p++) {
      let v = e.charCodeAt(p);
      if (!(v === Ye && ((g = e.charCodeAt(p + 1)), g === le)))
        if (v === Pe) u === "" && (m = p), (u += e.slice(p, p + 2)), (p += 1);
        else if (v === We && e.charCodeAt(p + 1) === qe) {
          let k = p;
          for (let x = p + 2; x < e.length; x++)
            if (((g = e.charCodeAt(x)), g === Pe)) x += 1;
            else if (g === qe && e.charCodeAt(x + 1) === We) {
              p = x + 1;
              break;
            // =============================================
            // Author: johnfonseka
            // Project: chrome-block-sites
            // Date: 11 October 2025
            // =============================================
            }
          let w = e.slice(k, p + 1);
          if (w.charCodeAt(2) === Li) {
            let x = Ze(w.slice(2, -2));
            o.push(x), i && ((x.src = [i, k, p + 1]), (x.dst = [i, k, p + 1]));
          }
        } else if (v === Jt || v === Zt) {
          let k = tr(e, p, v);
          (u += e.slice(p, k + 1)), (p = k);
        } else {
          if (
            (v === Oe || v === le || v === He) &&
            (g = e.charCodeAt(p + 1)) &&
            (g === Oe ||
              g === le ||
              g === He ||
              (g === Ye && (g = e.charCodeAt(p + 2)) && g == le))
          )
            continue;
          if (v === le) {
            if (u.length === 0) continue;
            (g = u.charCodeAt(u.length - 1)),
              g !== Oe && g !== le && g !== He && (u += " ");
          } else if (v === er && e.charCodeAt(p + 1) === er && u.length === 0) {
            let k = "",
              w = p,
              x = -1;
            for (let C = p + 2; C < e.length; C++)
              if (((g = e.charCodeAt(C)), g === Pe)) C += 1;
              else if (g === Jt || g === Zt) C = tr(e, C, g);
              else if (g === We && e.charCodeAt(C + 1) === qe) {
                for (let y = C + 2; y < e.length; y++)
                  if (((g = e.charCodeAt(y)), g === Pe)) y += 1;
                  else if (g === qe && e.charCodeAt(y + 1) === We) {
                    C = y + 1;
                    break;
                  }
              } else if (x === -1 && g === Ui) x = u.length + C - w;
              else if (g === Ge && k.length === 0) {
                (u += e.slice(w, C)), (p = C);
                break;
              } else if (g === Ct) k += ")";
              else if (g === zi) k += "]";
              else if (g === Qt) k += "}";
              else if ((g === yt || e.length - 1 === C) && k.length === 0) {
                (p = C - 1), (u += e.slice(w, C));
                break;
              } else
                (g === Xt || g === Ki || g === yt) &&
                  k.length > 0 &&
                  e[C] === k[k.length - 1] &&
                  (k = k.slice(0, -1));
            let V = At(u, x);
            if (!V)
              throw new Error("Invalid custom property, expected a value");
            i && ((V.src = [i, w, p]), (V.dst = [i, w, p])),
              a ? a.nodes.push(V) : t.push(V),
              (u = "");
          } else if (v === Ge && u.charCodeAt(0) === xt)
            (d = _e(u)),
              i && ((d.src = [i, m, p]), (d.dst = [i, m, p])),
              a ? a.nodes.push(d) : t.push(d),
              (u = ""),
              (d = null);
          else if (v === Ge && c[c.length - 1] !== ")") {
            let k = At(u);
            if (!k) {
              if (u.length === 0) continue;
              throw new Error(`Invalid declaration: \`${u.trim()}\``);
            }
            i && ((k.src = [i, m, p]), (k.dst = [i, m, p])),
              a ? a.nodes.push(k) : t.push(k),
              (u = "");
          } else if (v === Qt && c[c.length - 1] !== ")")
            (c += "}"),
              (d = Y(u.trim())),
              i && ((d.src = [i, m, p]), (d.dst = [i, m, p])),
              a && a.nodes.push(d),
              s.push(a),
              (a = d),
              (u = ""),
              (d = null);
          else if (v === yt && c[c.length - 1] !== ")") {
            if (c === "") throw new Error("Missing opening {");
            if (((c = c.slice(0, -1)), u.length > 0))
              if (u.charCodeAt(0) === xt)
                (d = _e(u)),
                  i && ((d.src = [i, m, p]), (d.dst = [i, m, p])),
                  a ? a.nodes.push(d) : t.push(d),
                  (u = ""),
                  (d = null);
              else {
                let w = u.indexOf(":");
                if (a) {
                  let x = At(u, w);
                  if (!x)
                    throw new Error(`Invalid declaration: \`${u.trim()}\``);
                  i && ((x.src = [i, m, p]), (x.dst = [i, m, p])),
                    a.nodes.push(x);
                }
              }
            let k = s.pop() ?? null;
            k === null && a && t.push(a), (a = k), (u = ""), (d = null);
          } else if (v === Ct) (c += ")"), (u += "(");
          else if (v === Xt) {
            if (c[c.length - 1] !== ")") throw new Error("Missing opening (");
            (c = c.slice(0, -1)), (u += ")");
          } else {
            if (u.length === 0 && (v === Oe || v === le || v === He)) continue;
            u === "" && (m = p), (u += String.fromCharCode(v));
          }
        }
    }
    if (u.charCodeAt(0) === xt) {
      let p = _e(u);
      i && ((p.src = [i, m, e.length]), (p.dst = [i, m, e.length])), t.push(p);
    }
    if (c.length > 0 && a) {
      if (a.kind === "rule")
        throw new Error(`Missing closing } at ${a.selector}`);
      if (a.kind === "at-rule")
        throw new Error(`Missing closing } at ${a.name} ${a.params}`);
    }
    return o.length > 0 ? o.concat(t) : t;
  }
  function _e(e, r = []) {
    let i = e,
      t = "";
    for (let o = 5; o < e.length; o++) {
      let s = e.charCodeAt(o);
      if (s === Oe || s === Ct) {
        (i = e.slice(0, o)), (t = e.slice(o));
        break;
      }
    }
    return F(i.trim(), t.trim(), r);
  }
  function At(e, r = e.indexOf(":")) {
    if (r === -1) return null;
    let i = e.indexOf("!important", r + 1);
    return n(
      e.slice(0, r).trim(),
      e.slice(r + 1, i === -1 ? e.length : i).trim(),
      i !== -1
    );
  }
  function tr(e, r, i) {
    let t;
    for (let o = r + 1; o < e.length; o++)
      if (((t = e.charCodeAt(o)), t === Pe)) o += 1;
      else {
        if (t === i) return o;
        if (
          t === Ge &&
          (e.charCodeAt(o + 1) === le ||
            (e.charCodeAt(o + 1) === Ye && e.charCodeAt(o + 2) === le))
        )
          throw new Error(
            `Unterminated string: ${e.slice(r, o + 1) + String.fromCharCode(i)}`
          );
        if (t === le || (t === Ye && e.charCodeAt(o + 1) === le))
          throw new Error(
            `Unterminated string: ${e.slice(r, o) + String.fromCharCode(i)}`
          );
      }
    return r;
  }
  function me(e) {
    if (arguments.length === 0)
      throw new TypeError("`CSS.escape` requires an argument.");
    let r = String(e),
      i = r.length,
      t = -1,
      o,
      s = "",
      a = r.charCodeAt(0);
    if (i === 1 && a === 45) return "\\" + r;
    for (; ++t < i; ) {
      if (((o = r.charCodeAt(t)), o === 0)) {
        s += "\uFFFD";
        continue;
      }
      if (
        (o >= 1 && o <= 31) ||
        o === 127 ||
        (t === 0 && o >= 48 && o <= 57) ||
        (t === 1 && o >= 48 && o <= 57 && a === 45)
      ) {
        s += "\\" + o.toString(16) + " ";
        continue;
      }
      if (
        o >= 128 ||
        o === 45 ||
        o === 95 ||
        (o >= 48 && o <= 57) ||
        (o >= 65 && o <= 90) ||
        (o >= 97 && o <= 122)
      ) {
        s += r.charAt(t);
        continue;
      }
      s += "\\" + r.charAt(t);
    }
    return s;
  }
  function ve(e) {
    return e.replace(/\\([\dA-Fa-f]{1,6}[\t\n\f\r ]?|[\S\s])/g, (r) =>
      r.length > 2
        ? String.fromCodePoint(Number.parseInt(r.slice(1).trim(), 16))
        : r[1]
    );
  }
  var ir = new Map([
    ["--font", ["--font-weight", "--font-size"]],
    ["--inset", ["--inset-shadow", "--inset-ring"]],
    [
      "--text",
      [
        "--text-color",
        "--text-decoration-color",
        "--text-decoration-thickness",
        "--text-indent",
        "--text-shadow",
        "--text-underline-offset",
      ],
    ],
    ["--grid-column", ["--grid-column-start", "--grid-column-end"]],
    ["--grid-row", ["--grid-row-start", "--grid-row-end"]],
  ]);
  function rr(e, r) {
    return (ir.get(r) ?? []).some((i) => e === i || e.startsWith(`${i}-`));
  }
  var Je = class {
    constructor(r = new Map(), i = new Set([])) {
      this.values = r;
      this.keyframes = i;
    }
    prefix = null;
    get size() {
      return this.values.size;
    }
    add(r, i, t = 0, o) {
      if (r.endsWith("-*")) {
        if (i !== "initial")
          throw new Error(
            `Invalid theme value \`${i}\` for namespace \`${r}\``
          );
        r === "--*"
          ? this.values.clear()
          : this.clearNamespace(r.slice(0, -2), 0);
      }
      if (t & 4) {
        let s = this.values.get(r);
        if (s && !(s.options & 4)) return;
      }
      i === "initial"
        ? this.values.delete(r)
        : this.values.set(r, { value: i, options: t, src: o });
    }
    keysInNamespaces(r) {
      let i = [];
      for (let t of r) {
        let o = `${t}-`;
        for (let s of this.values.keys())
          s.startsWith(o) &&
            s.indexOf("--", 2) === -1 &&
            (rr(s, t) || i.push(s.slice(o.length)));
      }
      return i;
    }
    get(r) {
      for (let i of r) {
        let t = this.values.get(i);
        if (t) return t.value;
      }
      return null;
    }
    hasDefault(r) {
      return (this.getOptions(r) & 4) === 4;
    }
    getOptions(r) {
      return (r = ve(this.#r(r))), this.values.get(r)?.options ?? 0;
    }
    entries() {
      return this.prefix
        ? Array.from(this.values, (r) => ((r[0] = this.prefixKey(r[0])), r))
        : this.values.entries();
    }
    prefixKey(r) {
      return this.prefix ? `--${this.prefix}-${r.slice(2)}` : r;
    }
    #r(r) {
      return this.prefix ? `--${r.slice(3 + this.prefix.length)}` : r;
    }
    clearNamespace(r, i) {
      let t = ir.get(r) ?? [];
      e: for (let o of this.values.keys())
        if (o.startsWith(r)) {
          if (i !== 0 && (this.getOptions(o) & i) !== i) continue;
          for (let s of t) if (o.startsWith(s)) continue e;
          this.values.delete(o);
        }
    }
    #e(r, i) {
      for (let t of i) {
        let o = r !== null ? `${t}-${r}` : t;
        if (!this.values.has(o))
          if (r !== null && r.includes(".")) {
            if (((o = `${t}-${r.replaceAll(".", "_")}`), !this.values.has(o)))
              continue;
          } else continue;
        if (!rr(o, t)) return o;
      }
      return null;
    }
    #t(r) {
      let i = this.values.get(r);
      if (!i) return null;
      let t = null;
      return (
        i.options & 2 && (t = i.value),
        `var(${me(this.prefixKey(r))}${t ? `, ${t}` : ""})`
      );
    }
    markUsedVariable(r) {
      let i = ve(this.#r(r)),
        t = this.values.get(i);
      if (!t) return !1;
      let o = t.options & 16;
      return (t.options |= 16), !o;
    }
    resolve(r, i, t = 0) {
      let o = this.#e(r, i);
      if (!o) return null;
      let s = this.values.get(o);
      return (t | s.options) & 1 ? s.value : this.#t(o);
    }
    resolveValue(r, i) {
      let t = this.#e(r, i);
      return t ? this.values.get(t).value : null;
    }
    resolveWith(r, i, t = []) {
      let o = this.#e(r, i);
      if (!o) return null;
      let s = {};
      for (let d of t) {
        let u = `${o}${d}`,
          c = this.values.get(u);
        c && (c.options & 1 ? (s[d] = c.value) : (s[d] = this.#t(u)));
      }
      let a = this.values.get(o);
      return a.options & 1 ? [a.value, s] : [this.#t(o), s];
    }
    namespace(r) {
      let i = new Map(),
        t = `${r}-`;
      for (let [o, s] of this.values)
        o === r
          ? i.set(null, s.value)
          : o.startsWith(`${t}-`)
          ? i.set(o.slice(r.length), s.value)
          : o.startsWith(t) && i.set(o.slice(t.length), s.value);
      return i;
    }
    addKeyframes(r) {
      this.keyframes.add(r);
    }
    getKeyframes() {
      return Array.from(this.keyframes);
    }
  };
  var B = class extends Map {
    constructor(i) {
      super();
      this.factory = i;
    }
    get(i) {
      let t = super.get(i);
      return t === void 0 && ((t = this.factory(i, this)), this.set(i, t)), t;
    }
  };
  function $t(e) {
    return { kind: "word", value: e };
  }
  function Ii(e, r) {
    return { kind: "function", value: e, nodes: r };
  }
  function ji(e) {
    return { kind: "separator", value: e };
  }
  function ee(e, r, i = null) {
    for (let t = 0; t < e.length; t++) {
      let o = e[t],
        s = !1,
        a = 0,
        d =
          r(o, {
            parent: i,
            replaceWith(u) {
              s ||
                ((s = !0),
                Array.isArray(u)
                  ? u.length === 0
                    ? (e.splice(t, 1), (a = 0))
                    : u.length === 1
                    ? ((e[t] = u[0]), (a = 1))
                    : (e.splice(t, 1, ...u), (a = u.length))
                  : (e[t] = u));
            },
          }) ?? 0;
      if (s) {
        d === 0 ? t-- : (t += a - 1);
        continue;
      }
      if (d === 2) return 2;
      if (d !== 1 && o.kind === "function" && ee(o.nodes, r, o) === 2) return 2;
    }
  }
  function J(e) {
    let r = "";
    for (let i of e)
      switch (i.kind) {
        case "word":
        case "separator": {
          r += i.value;
          break;
        }
        case "function":
          r += i.value + "(" + J(i.nodes) + ")";
      }
    return r;
  }
  var or = 92,
    Fi = 41,
    nr = 58,
    lr = 44,
    Mi = 34,
    ar = 61,
    sr = 62,
    ur = 60,
    cr = 10,
    Bi = 40,
    Wi = 39,
    fr = 47,
    dr = 32,
    pr = 9;
  function G(e) {
    e = e.replaceAll(
      `\r
`,
      `
`
    );
    let r = [],
      i = [],
      t = null,
      o = "",
      s;
    for (let a = 0; a < e.length; a++) {
      let d = e.charCodeAt(a);
      switch (d) {
        case or: {
          (o += e[a] + e[a + 1]), a++;
          break;
        }
        case nr:
        case lr:
        case ar:
        case sr:
        case ur:
        case cr:
        case fr:
        case dr:
        case pr: {
          if (o.length > 0) {
            let g = $t(o);
            t ? t.nodes.push(g) : r.push(g), (o = "");
          }
          let u = a,
            c = a + 1;
          for (
            ;
            c < e.length &&
            ((s = e.charCodeAt(c)),
            !(
              s !== nr &&
              s !== lr &&
              s !== ar &&
              s !== sr &&
              s !== ur &&
              s !== cr &&
              s !== fr &&
              s !== dr &&
              s !== pr
            ));
            c++
          );
          a = c - 1;
          let m = ji(e.slice(u, c));
          t ? t.nodes.push(m) : r.push(m);
          break;
        }
        case Wi:
        case Mi: {
          let u = a;
          for (let c = a + 1; c < e.length; c++)
            if (((s = e.charCodeAt(c)), s === or)) c += 1;
            else if (s === d) {
              a = c;
              break;
            }
          o += e.slice(u, a + 1);
          break;
        }
        case Bi: {
          let u = Ii(o, []);
          (o = ""), t ? t.nodes.push(u) : r.push(u), i.push(u), (t = u);
          break;
        }
        case Fi: {
          let u = i.pop();
          if (o.length > 0) {
            let c = $t(o);
            u?.nodes.push(c), (o = "");
          }
          i.length > 0 ? (t = i[i.length - 1]) : (t = null);
          break;
        }
        default:
          o += String.fromCharCode(d);
      }
    }
    return o.length > 0 && r.push($t(o)), r;
  }
  function Qe(e) {
    let r = [];
    return (
      ee(G(e), (i) => {
        if (!(i.kind !== "function" || i.value !== "var"))
          return (
            ee(i.nodes, (t) => {
              t.kind !== "word" ||
                t.value[0] !== "-" ||
                t.value[1] !== "-" ||
                r.push(t.value);
            }),
            1
          );
      }),
      r
    );
  }
  var Hi = 64;
  function W(e, r = []) {
    return { kind: "rule", selector: e, nodes: r };
  }
  function F(e, r = "", i = []) {
    return { kind: "at-rule", name: e, params: r, nodes: i };
  }
  function Y(e, r = []) {
    return e.charCodeAt(0) === Hi ? _e(e, r) : W(e, r);
  }
  function n(e, r, i = !1) {
    return { kind: "declaration", property: e, value: r, important: i };
  }
  function Ze(e) {
    return { kind: "comment", value: e };
  }
  function ue(e, r) {
    return { kind: "context", context: e, nodes: r };
  }
  function j(e) {
    return { kind: "at-root", nodes: e };
  }
  function K(e, r, i = [], t = {}) {
    for (let o = 0; o < e.length; o++) {
      let s = e[o],
        a = i[i.length - 1] ?? null;
      if (s.kind === "context") {
        if (K(s.nodes, r, i, { ...t, ...s.context }) === 2) return 2;
        continue;
      }
      i.push(s);
      let d = !1,
        u = 0,
        c =
          r(s, {
            parent: a,
            context: t,
            path: i,
            replaceWith(m) {
              d ||
                ((d = !0),
                Array.isArray(m)
                  ? m.length === 0
                    ? (e.splice(o, 1), (u = 0))
                    : m.length === 1
                    ? ((e[o] = m[0]), (u = 1))
                    : (e.splice(o, 1, ...m), (u = m.length))
                  : ((e[o] = m), (u = 1)));
            },
          }) ?? 0;
      if ((i.pop(), d)) {
        c === 0 ? o-- : (o += u - 1);
        continue;
      }
      if (c === 2) return 2;
      if (c !== 1 && "nodes" in s) {
        i.push(s);
        let m = K(s.nodes, r, i, t);
        if ((i.pop(), m === 2)) return 2;
      }
    }
  }
  function Xe(e, r, i = [], t = {}) {
    for (let o = 0; o < e.length; o++) {
      let s = e[o],
        a = i[i.length - 1] ?? null;
      if (s.kind === "rule" || s.kind === "at-rule")
        i.push(s), Xe(s.nodes, r, i, t), i.pop();
      else if (s.kind === "context") {
        Xe(s.nodes, r, i, { ...t, ...s.context });
        continue;
      }
      i.push(s),
        r(s, {
          parent: a,
          context: t,
          path: i,
          replaceWith(d) {
            Array.isArray(d)
              ? d.length === 0
                ? e.splice(o, 1)
                : d.length === 1
                ? (e[o] = d[0])
                : e.splice(o, 1, ...d)
              : (e[o] = d),
              (o += d.length - 1);
          },
        }),
        i.pop();
    }
  }
  function be(e, r, i = 3) {
    let t = [],
      o = new Set(),
      s = new B(() => new Set()),
      a = new B(() => new Set()),
      d = new Set(),
      u = new Set(),
      c = [],
      m = [],
      g = new B(() => new Set());
    function p(k, w, x = {}, V = 0) {
      if (k.kind === "declaration") {
        if (
          k.property === "--tw-sort" ||
          k.value === void 0 ||
          k.value === null
        )
          return;
        if (x.theme && k.property[0] === "-" && k.property[1] === "-") {
          if (k.value === "initial") {
            k.value = void 0;
            return;
          }
          x.keyframes || s.get(w).add(k);
        }
        if (k.value.includes("var("))
          if (x.theme && k.property[0] === "-" && k.property[1] === "-")
            for (let C of Qe(k.value)) g.get(C).add(k.property);
          else r.trackUsedVariables(k.value);
        if (k.property === "animation") for (let C of mr(k.value)) u.add(C);
        i & 2 && k.value.includes("color-mix(") && a.get(w).add(k), w.push(k);
      } else if (k.kind === "rule") {
        let C = [];
        for (let R of k.nodes) p(R, C, x, V + 1);
        let y = {},
          _ = new Set();
        for (let R of C) {
          if (R.kind !== "declaration") continue;
          let D = `${R.property}:${R.value}:${R.important}`;
          (y[D] ??= []), y[D].push(R);
        }
        for (let R in y)
          for (let D = 0; D < y[R].length - 1; ++D) _.add(y[R][D]);
        if ((_.size > 0 && (C = C.filter((R) => !_.has(R))), C.length === 0))
          return;
        k.selector === "&" ? w.push(...C) : w.push({ ...k, nodes: C });
      } else if (k.kind === "at-rule" && k.name === "@property" && V === 0) {
        if (o.has(k.params)) return;
        if (i & 1) {
          let y = k.params,
            _ = null,
            R = !1;
          for (let U of k.nodes)
            U.kind === "declaration" &&
              (U.property === "initial-value"
                ? (_ = U.value)
                : U.property === "inherits" && (R = U.value === "true"));
          let D = n(y, _ ?? "initial");
          (D.src = k.src), R ? c.push(D) : m.push(D);
        }
        o.add(k.params);
        let C = { ...k, nodes: [] };
        for (let y of k.nodes) p(y, C.nodes, x, V + 1);
        w.push(C);
      } else if (k.kind === "at-rule") {
        k.name === "@keyframes" && (x = { ...x, keyframes: !0 });
        let C = { ...k, nodes: [] };
        for (let y of k.nodes) p(y, C.nodes, x, V + 1);
        k.name === "@keyframes" && x.theme && d.add(C),
          (C.nodes.length > 0 ||
            C.name === "@layer" ||
            C.name === "@charset" ||
            C.name === "@custom-media" ||
            C.name === "@namespace" ||
            C.name === "@import") &&
            w.push(C);
      } else if (k.kind === "at-root")
        for (let C of k.nodes) {
          let y = [];
          p(C, y, x, 0);
          for (let _ of y) t.push(_);
        }
      else if (k.kind === "context") {
        if (k.context.reference) return;
        for (let C of k.nodes) p(C, w, { ...x, ...k.context }, V);
      } else k.kind === "comment" && w.push(k);
    }
    let v = [];
    for (let k of e) p(k, v, {}, 0);
    e: for (let [k, w] of s)
      for (let x of w) {
        if (gr(x.property, r.theme, g)) {
          if (x.property.startsWith(r.theme.prefixKey("--animate-")))
            for (let y of mr(x.value)) u.add(y);
          continue;
        }
        let C = k.indexOf(x);
        if ((k.splice(C, 1), k.length === 0)) {
          let y = Gi(v, (_) => _.kind === "rule" && _.nodes === k);
          if (!y || y.length === 0) continue e;
          y.unshift({ kind: "at-root", nodes: v });
          do {
            let _ = y.pop();
            if (!_) break;
            let R = y[y.length - 1];
            if (!R || (R.kind !== "at-root" && R.kind !== "at-rule")) break;
            let D = R.nodes.indexOf(_);
            if (D === -1) break;
            R.nodes.splice(D, 1);
          } while (!0);
          continue e;
        }
      }
    for (let k of d)
      if (!u.has(k.params)) {
        let w = t.indexOf(k);
        t.splice(w, 1);
      }
    if (((v = v.concat(t)), i & 2))
      for (let [k, w] of a)
        for (let x of w) {
          let V = k.indexOf(x);
          if (V === -1 || x.value == null) continue;
          let C = G(x.value),
            y = !1;
          if (
            (ee(C, (D, { replaceWith: U }) => {
              if (D.kind !== "function" || D.value !== "color-mix") return;
              let H = !1,
                O = !1;
              if (
                (ee(D.nodes, (L, { replaceWith: q }) => {
                  if (
                    L.kind == "word" &&
                    L.value.toLowerCase() === "currentcolor"
                  ) {
                    (O = !0), (y = !0);
                    return;
                  }
                  let M = L,
                    oe = null,
                    l = new Set();
                  do {
                    if (M.kind !== "function" || M.value !== "var") return;
                    let f = M.nodes[0];
                    if (!f || f.kind !== "word") return;
                    let h = f.value;
                    if (l.has(h)) {
                      H = !0;
                      return;
                    }
                    if (
                      (l.add(h),
                      (y = !0),
                      (oe = r.theme.resolveValue(null, [f.value])),
                      !oe)
                    ) {
                      H = !0;
                      return;
                    }
                    if (oe.toLowerCase() === "currentcolor") {
                      O = !0;
                      return;
                    }
                    oe.startsWith("var(") ? (M = G(oe)[0]) : (M = null);
                  } while (M);
                  q({ kind: "word", value: oe });
                }),
                H || O)
              ) {
                let L = D.nodes.findIndex(
                  (M) => M.kind === "separator" && M.value.trim().includes(",")
                );
                if (L === -1) return;
                let q = D.nodes.length > L ? D.nodes[L + 1] : null;
                if (!q) return;
                U(q);
              } else if (y) {
                let L = D.nodes[2];
                L.kind === "word" &&
                  (L.value === "oklab" ||
                    L.value === "oklch" ||
                    L.value === "lab" ||
                    L.value === "lch") &&
                  (L.value = "srgb");
              }
            }),
            !y)
          )
            continue;
          let _ = { ...x, value: J(C) },
            R = Y("@supports (color: color-mix(in lab, red, red))", [x]);
          (R.src = x.src), k.splice(V, 1, _, R);
        }
    if (i & 1) {
      let k = [];
      if (c.length > 0) {
        let w = Y(":root, :host", c);
        (w.src = c[0].src), k.push(w);
      }
      if (m.length > 0) {
        let w = Y("*, ::before, ::after, ::backdrop", m);
        (w.src = m[0].src), k.push(w);
      }
      if (k.length > 0) {
        let w = v.findIndex(
            (C) =>
              !(
                C.kind === "comment" ||
                (C.kind === "at-rule" &&
                  (C.name === "@charset" || C.name === "@import"))
              )
          ),
          x = F("@layer", "properties", []);
        (x.src = k[0].src), v.splice(w < 0 ? v.length : w, 0, x);
        let V = Y("@layer properties", [
          F(
            "@supports",
            "((-webkit-hyphens: none) and (not (margin-trim: inline))) or ((-moz-orient: inline) and (not (color:rgb(from red r g b))))",
            k
          ),
        ]);
        (V.src = k[0].src), (V.nodes[0].src = k[0].src), v.push(V);
      }
    }
    return v;
  }
  function ne(e, r) {
    let i = 0,
      t = { file: null, code: "" };
    function o(a, d = 0) {
      let u = "",
        c = "  ".repeat(d);
      if (a.kind === "declaration") {
        if (
          ((u += `${c}${a.property}: ${a.value}${
            a.important ? " !important" : ""
          };
`),
          r)
        ) {
          i += c.length;
          let m = i;
          (i += a.property.length),
            (i += 2),
            (i += a.value?.length ?? 0),
            a.important && (i += 11);
          let g = i;
          (i += 2), (a.dst = [t, m, g]);
        }
      } else if (a.kind === "rule") {
        if (
          ((u += `${c}${a.selector} {
`),
          r)
        ) {
          i += c.length;
          let m = i;
          (i += a.selector.length), (i += 1);
          let g = i;
          (a.dst = [t, m, g]), (i += 2);
        }
        for (let m of a.nodes) u += o(m, d + 1);
        (u += `${c}}
`),
          r && ((i += c.length), (i += 2));
      } else if (a.kind === "at-rule") {
        if (a.nodes.length === 0) {
          let m = `${c}${a.name} ${a.params};
`;
          if (r) {
            i += c.length;
            let g = i;
            (i += a.name.length), (i += 1), (i += a.params.length);
            let p = i;
            (i += 2), (a.dst = [t, g, p]);
          }
          return m;
        }
        if (
          ((u += `${c}${a.name}${a.params ? ` ${a.params} ` : " "}{
`),
          r)
        ) {
          i += c.length;
          let m = i;
          (i += a.name.length),
            a.params && ((i += 1), (i += a.params.length)),
            (i += 1);
          let g = i;
          (a.dst = [t, m, g]), (i += 2);
        }
        for (let m of a.nodes) u += o(m, d + 1);
        (u += `${c}}
`),
          r && ((i += c.length), (i += 2));
      } else if (a.kind === "comment") {
        if (
          ((u += `${c}/*${a.value}*/
`),
          r)
        ) {
          i += c.length;
          let m = i;
          i += 2 + a.value.length + 2;
          let g = i;
          (a.dst = [t, m, g]), (i += 1);
        }
      } else if (a.kind === "context" || a.kind === "at-root") return "";
      return u;
    }
    let s = "";
    for (let a of e) s += o(a, 0);
    return (t.code = s), s;
  }
  function Gi(e, r) {
    let i = [];
    return (
      K(e, (t, { path: o }) => {
        if (r(t)) return (i = [...o]), 2;
      }),
      i
    );
  }
  function gr(e, r, i, t = new Set()) {
    if (t.has(e) || (t.add(e), r.getOptions(e) & 24)) return !0;
    {
      let s = i.get(e) ?? [];
      for (let a of s) if (gr(a, r, i, t)) return !0;
    }
    return !1;
  }
  function mr(e) {
    return e.split(/[\s,]+/);
  }
  var Nt = [
    "calc",
    "min",
    "max",
    "clamp",
    "mod",
    "rem",
    "sin",
    "cos",
    "tan",
    "asin",
    "acos",
    "atan",
    "atan2",
    "pow",
    "sqrt",
    "hypot",
    "log",
    "exp",
    "round",
  ];
  function De(e) {
    return e.indexOf("(") !== -1 && Nt.some((r) => e.includes(`${r}(`));
  }
  function hr(e) {
    if (!Nt.some((s) => e.includes(s))) return e;
    let r = "",
      i = [],
      t = null,
      o = null;
    for (let s = 0; s < e.length; s++) {
      let a = e.charCodeAt(s);
      if (
        ((a >= 48 && a <= 57) ||
        (t !== null &&
          (a === 37 || (a >= 97 && a <= 122) || (a >= 65 && a <= 90)))
          ? (t = s)
          : ((o = t), (t = null)),
        a === 40)
      ) {
        r += e[s];
        let d = s;
        for (let c = s - 1; c >= 0; c--) {
          let m = e.charCodeAt(c);
          if (m >= 48 && m <= 57) d = c;
          else if (m >= 97 && m <= 122) d = c;
          else break;
        }
        let u = e.slice(d, s);
        if (Nt.includes(u)) {
          i.unshift(!0);
          continue;
        } else if (i[0] && u === "") {
          i.unshift(!0);
          continue;
        }
        i.unshift(!1);
        continue;
      } else if (a === 41) (r += e[s]), i.shift();
      else if (a === 44 && i[0]) {
        r += ", ";
        continue;
      } else {
        if (a === 32 && i[0] && r.charCodeAt(r.length - 1) === 32) continue;
        if ((a === 43 || a === 42 || a === 47 || a === 45) && i[0]) {
          let d = r.trimEnd(),
            u = d.charCodeAt(d.length - 1),
            c = d.charCodeAt(d.length - 2),
            m = e.charCodeAt(s + 1);
          if ((u === 101 || u === 69) && c >= 48 && c <= 57) {
            r += e[s];
            continue;
          } else if (u === 43 || u === 42 || u === 47 || u === 45) {
            r += e[s];
            continue;
          } else if (u === 40 || u === 44) {
            r += e[s];
            continue;
          } else
            e.charCodeAt(s - 1) === 32
              ? (r += `${e[s]} `)
              : (u >= 48 && u <= 57) ||
                (m >= 48 && m <= 57) ||
                u === 41 ||
                m === 40 ||
                m === 43 ||
                m === 42 ||
                m === 47 ||
                m === 45 ||
                (o !== null && o === s - 1)
              ? (r += ` ${e[s]} `)
              : (r += e[s]);
        } else r += e[s];
      }
    }
    return r;
  }
  function ge(e) {
    if (e.indexOf("(") === -1) return $e(e);
    let r = G(e);
    return Vt(r), (e = J(r)), (e = hr(e)), e;
  }
  function $e(e, r = !1) {
    let i = "";
    for (let t = 0; t < e.length; t++) {
      let o = e[t];
      o === "\\" && e[t + 1] === "_"
        ? ((i += "_"), (t += 1))
        : o === "_" && !r
        ? (i += " ")
        : (i += o);
    }
    return i;
  }
  function Vt(e) {
    for (let r of e)
      switch (r.kind) {
        case "function": {
          if (r.value === "url" || r.value.endsWith("_url")) {
            r.value = $e(r.value);
            break;
          }
          if (
            r.value === "var" ||
            r.value.endsWith("_var") ||
            r.value === "theme" ||
            r.value.endsWith("_theme")
          ) {
            r.value = $e(r.value);
            for (let i = 0; i < r.nodes.length; i++) {
              if (i == 0 && r.nodes[i].kind === "word") {
                r.nodes[i].value = $e(r.nodes[i].value, !0);
                continue;
              }
              Vt([r.nodes[i]]);
            }
            break;
          }
          (r.value = $e(r.value)), Vt(r.nodes);
          break;
        }
        case "separator":
        case "word": {
          r.value = $e(r.value);
          break;
        }
        default:
          Zi(r);
      }
  }
  function Zi(e) {
    throw new Error(`Unexpected value: ${e}`);
  }
  var Et = new Uint8Array(256);
  function fe(e) {
    let r = 0,
      i = e.length;
    for (let t = 0; t < i; t++) {
      let o = e.charCodeAt(t);
      switch (o) {
        case 92:
          t += 1;
          break;
        case 39:
        case 34:
          for (; ++t < i; ) {
            let s = e.charCodeAt(t);
            if (s === 92) {
              t += 1;
              continue;
            }
            if (s === o) break;
          }
          break;
        case 40:
          (Et[r] = 41), r++;
          break;
        case 91:
          (Et[r] = 93), r++;
          break;
        case 123:
          break;
        case 93:
        case 125:
        case 41:
          if (r === 0) return !1;
          r > 0 && o === Et[r - 1] && r--;
          break;
        case 59:
          if (r === 0) return !1;
          break;
      }
    }
    return !0;
  }
  var tt = new Uint8Array(256);
  function z(e, r) {
    let i = 0,
      t = [],
      o = 0,
      s = e.length,
      a = r.charCodeAt(0);
    for (let d = 0; d < s; d++) {
      let u = e.charCodeAt(d);
      if (i === 0 && u === a) {
        t.push(e.slice(o, d)), (o = d + 1);
        continue;
      }
      switch (u) {
        case 92:
          d += 1;
          break;
        case 39:
        case 34:
          for (; ++d < s; ) {
            let c = e.charCodeAt(d);
            if (c === 92) {
              d += 1;
              continue;
            }
            if (c === u) break;
          }
          break;
        case 40:
          (tt[i] = 41), i++;
          break;
        case 91:
          (tt[i] = 93), i++;
          break;
        case 123:
          (tt[i] = 125), i++;
          break;
        case 93:
        case 125:
        case 41:
          i > 0 && u === tt[i - 1] && i--;
          break;
      }
    }
    return t.push(e.slice(o)), t;
  }
  var Ji = 58,
    kr = 45,
    vr = 97,
    wr = 122;
  function* br(e, r) {
    let i = z(e, ":");
    if (r.theme.prefix) {
      if (i.length === 1 || i[0] !== r.theme.prefix) return null;
      i.shift();
    }
    let t = i.pop(),
      o = [];
    for (let g = i.length - 1; g >= 0; --g) {
      let p = r.parseVariant(i[g]);
      if (p === null) return;
      o.push(p);
    }
    let s = !1;
    t[t.length - 1] === "!"
      ? ((s = !0), (t = t.slice(0, -1)))
      : t[0] === "!" && ((s = !0), (t = t.slice(1))),
      r.utilities.has(t, "static") &&
        !t.includes("[") &&
        (yield { kind: "static", root: t, variants: o, important: s, raw: e });
    let [a, d = null, u] = z(t, "/");
    if (u) return;
    let c = d === null ? null : Tt(d);
    if (d !== null && c === null) return;
    if (a[0] === "[") {
      if (a[a.length - 1] !== "]") return;
      let g = a.charCodeAt(1);
      if (g !== kr && !(g >= vr && g <= wr)) return;
      a = a.slice(1, -1);
      let p = a.indexOf(":");
      if (p === -1 || p === 0 || p === a.length - 1) return;
      let v = a.slice(0, p),
        k = ge(a.slice(p + 1));
      if (!fe(k)) return;
      yield {
        kind: "arbitrary",
        property: v,
        value: k,
        modifier: c,
        variants: o,
        important: s,
        raw: e,
      };
      return;
    }
    let m;
    if (a[a.length - 1] === "]") {
      let g = a.indexOf("-[");
      if (g === -1) return;
      let p = a.slice(0, g);
      if (!r.utilities.has(p, "functional")) return;
      let v = a.slice(g + 1);
      m = [[p, v]];
    } else if (a[a.length - 1] === ")") {
      let g = a.indexOf("-(");
      if (g === -1) return;
      let p = a.slice(0, g);
      if (!r.utilities.has(p, "functional")) return;
      let v = a.slice(g + 2, -1),
        k = z(v, ":"),
        w = null;
      if (
        (k.length === 2 && ((w = k[0]), (v = k[1])),
        v[0] !== "-" || v[1] !== "-" || !fe(v))
      )
        return;
      m = [[p, w === null ? `[var(${v})]` : `[${w}:var(${v})]`]];
    } else m = xr(a, (g) => r.utilities.has(g, "functional"));
    for (let [g, p] of m) {
      let v = {
        kind: "functional",
        root: g,
        modifier: c,
        value: null,
        variants: o,
        important: s,
        raw: e,
      };
      if (p === null) {
        yield v;
        continue;
      }
      {
        let k = p.indexOf("[");
        if (k !== -1) {
          if (p[p.length - 1] !== "]") return;
          let x = ge(p.slice(k + 1, -1));
          if (!fe(x)) continue;
          let V = "";
          for (let C = 0; C < x.length; C++) {
            let y = x.charCodeAt(C);
            if (y === Ji) {
              (V = x.slice(0, C)), (x = x.slice(C + 1));
              break;
            }
            if (!(y === kr || (y >= vr && y <= wr))) break;
          }
          if (x.length === 0 || x.trim().length === 0) continue;
          v.value = { kind: "arbitrary", dataType: V || null, value: x };
        } else {
          let x =
            d === null || v.modifier?.kind === "arbitrary" ? null : `${p}/${d}`;
          v.value = { kind: "named", value: p, fraction: x };
        }
      }
      yield v;
    }
  }
  function Tt(e) {
    if (e[0] === "[" && e[e.length - 1] === "]") {
      let r = ge(e.slice(1, -1));
      return !fe(r) || r.length === 0 || r.trim().length === 0
        ? null
        : { kind: "arbitrary", value: r };
    }
    return e[0] === "(" && e[e.length - 1] === ")"
      ? ((e = e.slice(1, -1)),
        e[0] !== "-" || e[1] !== "-" || !fe(e)
          ? null
          : ((e = `var(${e})`), { kind: "arbitrary", value: ge(e) }))
      : { kind: "named", value: e };
  }
  function yr(e, r) {
    if (e[0] === "[" && e[e.length - 1] === "]") {
      if (e[1] === "@" && e.includes("&")) return null;
      let i = ge(e.slice(1, -1));
      if (!fe(i) || i.length === 0 || i.trim().length === 0) return null;
      let t = i[0] === ">" || i[0] === "+" || i[0] === "~";
      return (
        !t && i[0] !== "@" && !i.includes("&") && (i = `&:is(${i})`),
        { kind: "arbitrary", selector: i, relative: t }
      );
    }
    {
      let [i, t = null, o] = z(e, "/");
      if (o) return null;
      let s = xr(i, (a) => r.variants.has(a));
      for (let [a, d] of s)
        switch (r.variants.kind(a)) {
          case "static":
            return d !== null || t !== null
              ? null
              : { kind: "static", root: a };
          case "functional": {
            let u = t === null ? null : Tt(t);
            if (t !== null && u === null) return null;
            if (d === null)
              return { kind: "functional", root: a, modifier: u, value: null };
            if (d[d.length - 1] === "]") {
              if (d[0] !== "[") continue;
              let c = ge(d.slice(1, -1));
              return !fe(c) || c.length === 0 || c.trim().length === 0
                ? null
                : {
                    kind: "functional",
                    root: a,
                    modifier: u,
                    value: { kind: "arbitrary", value: c },
                  };
            }
            if (d[d.length - 1] === ")") {
              if (d[0] !== "(") continue;
              let c = ge(d.slice(1, -1));
              return !fe(c) ||
                c.length === 0 ||
                c.trim().length === 0 ||
                c[0] !== "-" ||
                c[1] !== "-"
                ? null
                : {
                    kind: "functional",
                    root: a,
                    modifier: u,
                    value: { kind: "arbitrary", value: `var(${c})` },
                  };
            }
            return {
              kind: "functional",
              root: a,
              modifier: u,
              value: { kind: "named", value: d },
            };
          }
          case "compound": {
            if (d === null) return null;
            let u = r.parseVariant(d);
            if (u === null || !r.variants.compoundsWith(a, u)) return null;
            let c = t === null ? null : Tt(t);
            return t !== null && c === null
              ? null
              : { kind: "compound", root: a, modifier: c, variant: u };
          }
        }
    }
    return null;
  }
  function* xr(e, r) {
    r(e) && (yield [e, null]);
    let i = e.lastIndexOf("-");
    for (; i > 0; ) {
      let t = e.slice(0, i);
      if (r(t)) {
        let o = [t, e.slice(i + 1)];
        if (o[1] === "" || (o[0] === "@" && r("@") && e[i] === "-")) break;
        yield o;
      }
      i = e.lastIndexOf("-", i - 1);
    }
    e[0] === "@" && r("@") && (yield ["@", e.slice(1)]);
  }
  function Ar(e, r) {
    let i = [];
    for (let o of r.variants) i.unshift(rt(o));
    e.theme.prefix && i.unshift(e.theme.prefix);
    let t = "";
    if (
      (r.kind === "static" && (t += r.root),
      r.kind === "functional" && ((t += r.root), r.value))
    )
      if (r.value.kind === "arbitrary") {
        if (r.value !== null) {
          let o = Pt(r.value.value),
            s = o ? r.value.value.slice(4, -1) : r.value.value,
            [a, d] = o ? ["(", ")"] : ["[", "]"];
          r.value.dataType
            ? (t += `-${a}${r.value.dataType}:${Ne(s)}${d}`)
            : (t += `-${a}${Ne(s)}${d}`);
        }
      } else r.value.kind === "named" && (t += `-${r.value.value}`);
    return (
      r.kind === "arbitrary" && (t += `[${r.property}:${Ne(r.value)}]`),
      (r.kind === "arbitrary" || r.kind === "functional") &&
        (t += Cr(r.modifier)),
      r.important && (t += "!"),
      i.push(t),
      i.join(":")
    );
  }
  function Cr(e) {
    if (e === null) return "";
    let r = Pt(e.value),
      i = r ? e.value.slice(4, -1) : e.value,
      [t, o] = r ? ["(", ")"] : ["[", "]"];
    return e.kind === "arbitrary"
      ? `/${t}${Ne(i)}${o}`
      : e.kind === "named"
      ? `/${e.value}`
      : "";
  }
  function rt(e) {
    if (e.kind === "static") return e.root;
    if (e.kind === "arbitrary") return `[${Ne(eo(e.selector))}]`;
    let r = "";
    if (e.kind === "functional") {
      r += e.root;
      let i = e.root !== "@";
      if (e.value)
        if (e.value.kind === "arbitrary") {
          let t = Pt(e.value.value),
            o = t ? e.value.value.slice(4, -1) : e.value.value,
            [s, a] = t ? ["(", ")"] : ["[", "]"];
          r += `${i ? "-" : ""}${s}${Ne(o)}${a}`;
        } else
          e.value.kind === "named" && (r += `${i ? "-" : ""}${e.value.value}`);
    }
    return (
      e.kind === "compound" &&
        ((r += e.root), (r += "-"), (r += rt(e.variant))),
      (e.kind === "functional" || e.kind === "compound") &&
        (r += Cr(e.modifier)),
      r
    );
  }
  var Qi = new B((e) => {
    let r = G(e),
      i = new Set();
    return (
      ee(r, (t, { parent: o }) => {
        let s = o === null ? r : o.nodes ?? [];
        if (
          t.kind === "word" &&
          (t.value === "+" ||
            t.value === "-" ||
            t.value === "*" ||
            t.value === "/")
        ) {
          let a = s.indexOf(t) ?? -1;
          if (a === -1) return;
          let d = s[a - 1];
          if (d?.kind !== "separator" || d.value !== " ") return;
          let u = s[a + 1];
          if (u?.kind !== "separator" || u.value !== " ") return;
          i.add(d), i.add(u);
        } else
          t.kind === "separator" && t.value.trim() === "/"
            ? (t.value = "/")
            : t.kind === "separator" &&
              t.value.length > 0 &&
              t.value.trim() === ""
            ? (s[0] === t || s[s.length - 1] === t) && i.add(t)
            : t.kind === "separator" &&
              t.value.trim() === "," &&
              (t.value = ",");
      }),
      i.size > 0 &&
        ee(r, (t, { replaceWith: o }) => {
          i.has(t) && (i.delete(t), o([]));
        }),
      Rt(r),
      J(r)
    );
  });
  function Ne(e) {
    return Qi.get(e);
  }
  var Xi = new B((e) => {
    let r = G(e);
    return r.length === 3 &&
      r[0].kind === "word" &&
      r[0].value === "&" &&
      r[1].kind === "separator" &&
      r[1].value === ":" &&
      r[2].kind === "function" &&
      r[2].value === "is"
      ? J(r[2].nodes)
      : e;
  });
  function eo(e) {
    return Xi.get(e);
  }
  function Rt(e) {
    for (let r of e)
      switch (r.kind) {
        case "function": {
          if (r.value === "url" || r.value.endsWith("_url")) {
            r.value = Ue(r.value);
            break;
          }
          if (
            r.value === "var" ||
            r.value.endsWith("_var") ||
            r.value === "theme" ||
            r.value.endsWith("_theme")
          ) {
            r.value = Ue(r.value);
            for (let i = 0; i < r.nodes.length; i++) Rt([r.nodes[i]]);
            break;
          }
          (r.value = Ue(r.value)), Rt(r.nodes);
          break;
        }
        case "separator":
          r.value = Ue(r.value);
          break;
        case "word": {
          (r.value[0] !== "-" || r.value[1] !== "-") && (r.value = Ue(r.value));
          break;
        }
        default:
          ro(r);
      }
  }
  var to = new B((e) => {
    let r = G(e);
    return r.length === 1 && r[0].kind === "function" && r[0].value === "var";
  });
  function Pt(e) {
    return to.get(e);
  }
  function ro(e) {
    throw new Error(`Unexpected value: ${e}`);
  }
  function Ue(e) {
    return e.replaceAll("_", String.raw`\_`).replaceAll(" ", "_");
  }
  function ye(e, r, i) {
    if (e === r) return 0;
    let t = e.indexOf("("),
      o = r.indexOf("("),
      s = t === -1 ? e.replace(/[\d.]+/g, "") : e.slice(0, t),
      a = o === -1 ? r.replace(/[\d.]+/g, "") : r.slice(0, o),
      d =
        (s === a ? 0 : s < a ? -1 : 1) ||
        (i === "asc" ? parseInt(e) - parseInt(r) : parseInt(r) - parseInt(e));
    return Number.isNaN(d) ? (e < r ? -1 : 1) : d;
  }
  var io = new Set([
      "black",
      "silver",
      "gray",
      "white",
      "maroon",
      "red",
      "purple",
      "fuchsia",
      "green",
      "lime",
      "olive",
      "yellow",
      "navy",
      "blue",
      "teal",
      "aqua",
      "aliceblue",
      "antiquewhite",
      "aqua",
      "aquamarine",
      "azure",
      "beige",
      "bisque",
      "black",
      "blanchedalmond",
      "blue",
      "blueviolet",
      "brown",
      "burlywood",
      "cadetblue",
      "chartreuse",
      "chocolate",
      "coral",
      "cornflowerblue",
      "cornsilk",
      "crimson",
      "cyan",
      "darkblue",
      "darkcyan",
      "darkgoldenrod",
      "darkgray",
      "darkgreen",
      "darkgrey",
      "darkkhaki",
      "darkmagenta",
      "darkolivegreen",
      "darkorange",
      "darkorchid",
      "darkred",
      "darksalmon",
      "darkseagreen",
      "darkslateblue",
      "darkslategray",
      "darkslategrey",
      "darkturquoise",
      "darkviolet",
      "deeppink",
      "deepskyblue",
      "dimgray",
      "dimgrey",
      "dodgerblue",
      "firebrick",
      "floralwhite",
      "forestgreen",
      "fuchsia",
      "gainsboro",
      "ghostwhite",
      "gold",
      "goldenrod",
      "gray",
      "green",
      "greenyellow",
      "grey",
      "honeydew",
      "hotpink",
      "indianred",
      "indigo",
      "ivory",
      "khaki",
      "lavender",
      "lavenderblush",
      "lawngreen",
      "lemonchiffon",
      "lightblue",
      "lightcoral",
      "lightcyan",
      "lightgoldenrodyellow",
      "lightgray",
      "lightgreen",
      "lightgrey",
      "lightpink",
      "lightsalmon",
      "lightseagreen",
      "lightskyblue",
      "lightslategray",
      "lightslategrey",
      "lightsteelblue",
      "lightyellow",
      "lime",
      "limegreen",
      "linen",
      "magenta",
      "maroon",
      "mediumaquamarine",
      "mediumblue",
      "mediumorchid",
      "mediumpurple",
      "mediumseagreen",
      "mediumslateblue",
      "mediumspringgreen",
      "mediumturquoise",
      "mediumvioletred",
      "midnightblue",
      "mintcream",
      "mistyrose",
      "moccasin",
      "navajowhite",
      "navy",
      "oldlace",
      "olive",
      "olivedrab",
      "orange",
      "orangered",
      "orchid",
      "palegoldenrod",
      "palegreen",
      "paleturquoise",
      "palevioletred",
      "papayawhip",
      "peachpuff",
      "peru",
      "pink",
      "plum",
      "powderblue",
      "purple",
      "rebeccapurple",
      "red",
      "rosybrown",
      "royalblue",
      "saddlebrown",
      "salmon",
      "sandybrown",
      "seagreen",
      "seashell",
      "sienna",
      "silver",
      "skyblue",
      "slateblue",
      "slategray",
      "slategrey",
      "snow",
      "springgreen",
      "steelblue",
      "tan",
      "teal",
      "thistle",
      "tomato",
      "turquoise",
      "violet",
      "wheat",
      "white",
      "whitesmoke",
      "yellow",
      "yellowgreen",
      "transparent",
      "currentcolor",
      "canvas",
      "canvastext",
      "linktext",
      "visitedtext",
      "activetext",
      "buttonface",
      "buttontext",
      "buttonborder",
      "field",
      "fieldtext",
      "highlight",
      "highlighttext",
      "selecteditem",
      "selecteditemtext",
      "mark",
      "marktext",
      "graytext",
      "accentcolor",
      "accentcolortext",
    ]),
    oo = /^(rgba?|hsla?|hwb|color|(ok)?(lab|lch)|light-dark|color-mix)\(/i;
  function Sr(e) {
    return e.charCodeAt(0) === 35 || oo.test(e) || io.has(e.toLowerCase());
  }
  var no = {
    color: Sr,
    length: it,
    percentage: Ot,
    ratio: wo,
    number: Nr,
    integer: T,
    url: $r,
    position: xo,
    "bg-size": Ao,
    "line-width": ao,
    image: co,
    "family-name": po,
    "generic-name": fo,
    "absolute-size": mo,
    "relative-size": go,
    angle: $o,
    vector: Vo,
  };
  function Z(e, r) {
    if (e.startsWith("var(")) return null;
    for (let i of r) if (no[i]?.(e)) return i;
    return null;
  }
  var lo = /^url\(.*\)$/;
  function $r(e) {
    return lo.test(e);
  }
  function ao(e) {
    return z(e, " ").every(
      (r) => it(r) || Nr(r) || r === "thin" || r === "medium" || r === "thick"
    );
  }
  var so = /^(?:element|image|cross-fade|image-set)\(/,
    uo = /^(repeating-)?(conic|linear|radial)-gradient\(/;
  function co(e) {
    let r = 0;
    for (let i of z(e, ","))
      if (!i.startsWith("var(")) {
        if ($r(i)) {
          r += 1;
          continue;
        }
        if (uo.test(i)) {
          r += 1;
          continue;
        }
        if (so.test(i)) {
          r += 1;
          continue;
        }
        return !1;
      }
    return r > 0;
  }
  function fo(e) {
    return (
      e === "serif" ||
      e === "sans-serif" ||
      e === "monospace" ||
      e === "cursive" ||
      e === "fantasy" ||
      e === "system-ui" ||
      e === "ui-serif" ||
      e === "ui-sans-serif" ||
      e === "ui-monospace" ||
      e === "ui-rounded" ||
      e === "math" ||
      e === "emoji" ||
      e === "fangsong"
    );
  }
  function po(e) {
    let r = 0;
    for (let i of z(e, ",")) {
      let t = i.charCodeAt(0);
      if (t >= 48 && t <= 57) return !1;
      i.startsWith("var(") || (r += 1);
    }
    return r > 0;
  }
  function mo(e) {
    return (
      e === "xx-small" ||
      e === "x-small" ||
      e === "small" ||
      e === "medium" ||
      e === "large" ||
      e === "x-large" ||
      e === "xx-large" ||
      e === "xxx-large"
    );
  }
  function go(e) {
    return e === "larger" || e === "smaller";
  }
  var de = /[+-]?\d*\.?\d+(?:[eE][+-]?\d+)?/,
    ho = new RegExp(`^${de.source}$`);
  function Nr(e) {
    return ho.test(e) || De(e);
  }
  var ko = new RegExp(`^${de.source}%$`);
  function Ot(e) {
    return ko.test(e) || De(e);
  }
  var vo = new RegExp(`^${de.source}s*/s*${de.source}$`);
  function wo(e) {
    return vo.test(e) || De(e);
  }
  var bo = [
      "cm",
      "mm",
      "Q",
      "in",
      "pc",
      "pt",
      "px",
      "em",
      "ex",
      "ch",
      "rem",
      "lh",
      "rlh",
      "vw",
      "vh",
      "vmin",
      "vmax",
      "vb",
      "vi",
      "svw",
      "svh",
      "lvw",
      "lvh",
      "dvw",
      "dvh",
      "cqw",
      "cqh",
      "cqi",
      "cqb",
      "cqmin",
      "cqmax",
    ],
    yo = new RegExp(`^${de.source}(${bo.join("|")})$`);
  function it(e) {
    return yo.test(e) || De(e);
  }
  function xo(e) {
    let r = 0;
    for (let i of z(e, " ")) {
      if (
        i === "center" ||
        i === "top" ||
        i === "right" ||
        i === "bottom" ||
        i === "left"
      ) {
        r += 1;
        continue;
      }
      if (!i.startsWith("var(")) {
        if (it(i) || Ot(i)) {
          r += 1;
          continue;
        }
        return !1;
      }
    }
    return r > 0;
  }
  function Ao(e) {
    let r = 0;
    for (let i of z(e, ",")) {
      if (i === "cover" || i === "contain") {
        r += 1;
        continue;
      }
      let t = z(i, " ");
      if (t.length !== 1 && t.length !== 2) return !1;
      if (t.every((o) => o === "auto" || it(o) || Ot(o))) {
        r += 1;
        continue;
      }
    }
    return r > 0;
  }
  var Co = ["deg", "rad", "grad", "turn"],
    So = new RegExp(`^${de.source}(${Co.join("|")})$`);
  function $o(e) {
    return So.test(e);
  }
  var No = new RegExp(`^${de.source} +${de.source} +${de.source}$`);
  function Vo(e) {
    return No.test(e);
  }
  function T(e) {
    let r = Number(e);
    return Number.isInteger(r) && r >= 0 && String(r) === String(e);
  }
  function _t(e) {
    let r = Number(e);
    return Number.isInteger(r) && r > 0 && String(r) === String(e);
  }
  function xe(e) {
    return Vr(e, 0.25);
  }
  function ot(e) {
    return Vr(e, 0.25);
  }
  function Vr(e, r) {
    let i = Number(e);
    return i >= 0 && i % r === 0 && String(i) === String(e);
  }
  var Eo = new Set(["inset", "inherit", "initial", "revert", "unset"]),
    Er = /^-?(\d+|\.\d+)(.*?)$/g;
  function ze(e, r) {
    return z(e, ",")
      .map((t) => {
        t = t.trim();
        let o = z(t, " ").filter((c) => c.trim() !== ""),
          s = null,
          a = null,
          d = null;
        for (let c of o)
          Eo.has(c) ||
            (Er.test(c)
              ? (a === null ? (a = c) : d === null && (d = c),
                (Er.lastIndex = 0))
              : s === null && (s = c));
        if (a === null || d === null) return t;
        let u = r(s ?? "currentcolor");
        return s !== null ? t.replace(s, u) : `${t} ${u}`;
      })
      .join(", ");
  }
  var Ro = /^-?[a-z][a-zA-Z0-9/%._-]*$/,
    Po = /^-?[a-z][a-zA-Z0-9/%._-]*-\*$/,
    lt = [
      "0",
      "0.5",
      "1",
      "1.5",
      "2",
      "2.5",
      "3",
      "3.5",
      "4",
      "5",
      "6",
      "7",
      "8",
      "9",
      "10",
      "11",
      "12",
      "14",
      "16",
      "20",
      "24",
      "28",
      "32",
      "36",
      "40",
      "44",
      "48",
      "52",
      "56",
      "60",
      "64",
      "72",
      "80",
      "96",
    ],
    Dt = class {
      utilities = new B(() => []);
      completions = new Map();
      static(r, i) {
        this.utilities.get(r).push({ kind: "static", compileFn: i });
      }
      functional(r, i, t) {
        this.utilities
          .get(r)
          .push({ kind: "functional", compileFn: i, options: t });
      }
      has(r, i) {
        return (
          this.utilities.has(r) &&
          this.utilities.get(r).some((t) => t.kind === i)
        );
      }
      get(r) {
        return this.utilities.has(r) ? this.utilities.get(r) : [];
      }
      getCompletions(r) {
        return this.completions.get(r)?.() ?? [];
      }
      suggest(r, i) {
        let t = this.completions.get(r);
        t
          ? this.completions.set(r, () => [...t?.(), ...i?.()])
          : this.completions.set(r, i);
      }
      keys(r) {
        let i = [];
        for (let [t, o] of this.utilities.entries())
          for (let s of o)
            if (s.kind === r) {
              i.push(t);
              break;
            }
        return i;
      }
    };
  function S(e, r, i) {
    return F("@property", e, [
      n("syntax", i ? `"${i}"` : '"*"'),
      n("inherits", "false"),
      ...(r ? [n("initial-value", r)] : []),
    ]);
  }
  function Q(e, r) {
    if (r === null) return e;
    let i = Number(r);
    return (
      Number.isNaN(i) || (r = `${i * 100}%`),
      r === "100%" ? e : `color-mix(in oklab, ${e} ${r}, transparent)`
    );
  }
  function Rr(e, r) {
    let i = Number(r);
    return (
      Number.isNaN(i) || (r = `${i * 100}%`), `oklab(from ${e} l a b / ${r})`
    );
  }
  function X(e, r, i) {
    if (!r) return e;
    if (r.kind === "arbitrary") return Q(e, r.value);
    let t = i.resolve(r.value, ["--opacity"]);
    return t ? Q(e, t) : ot(r.value) ? Q(e, `${r.value}%`) : null;
  }
  function te(e, r, i) {
    let t = null;
    switch (e.value.value) {
      case "inherit": {
        t = "inherit";
        break;
      }
      case "transparent": {
        t = "transparent";
        break;
      }
      case "current": {
        t = "currentcolor";
        break;
      }
      default: {
        t = r.resolve(e.value.value, i);
        break;
      }
    }
    return t ? X(t, e.modifier, r) : null;
  }
  var Pr = /(\d+)_(\d+)/g;
  function Or(e) {
    let r = new Dt();
    function i(l, f) {
      function* h(b) {
        for (let $ of e.keysInNamespaces(b))
          yield $.replace(Pr, (P, N, E) => `${N}.${E}`);
      }
      let A = [
        "1/2",
        "1/3",
        "2/3",
        "1/4",
        "2/4",
        "3/4",
        "1/5",
        "2/5",
        "3/5",
        "4/5",
        "1/6",
        "2/6",
        "3/6",
        "4/6",
        "5/6",
        "1/12",
        "2/12",
        "3/12",
        "4/12",
        "5/12",
        "6/12",
        "7/12",
        "8/12",
        "9/12",
        "10/12",
        "11/12",
      ];
      r.suggest(l, () => {
        let b = [];
        for (let $ of f()) {
          if (typeof $ == "string") {
            b.push({ values: [$], modifiers: [] });
            continue;
          }
          let P = [...($.values ?? []), ...h($.valueThemeKeys ?? [])],
            N = [...($.modifiers ?? []), ...h($.modifierThemeKeys ?? [])];
          $.supportsFractions && P.push(...A),
            $.hasDefaultValue && P.unshift(null),
            b.push({
              supportsNegative: $.supportsNegative,
              values: P,
              modifiers: N,
            });
        }
        return b;
      });
    }
    function t(l, f) {
      r.static(l, () =>
        f.map((h) => (typeof h == "function" ? h() : n(h[0], h[1])))
      );
    }
    function o(l, f) {
      function h({ negative: A }) {
        return (b) => {
          let $ = null,
            P = null;
          if (b.value)
            if (b.value.kind === "arbitrary") {
              if (b.modifier) return;
              ($ = b.value.value), (P = b.value.dataType);
            } else {
              if (
                (($ = e.resolve(
                  b.value.fraction ?? b.value.value,
                  f.themeKeys ?? []
                )),
                $ === null && f.supportsFractions && b.value.fraction)
              ) {
                let [N, E] = z(b.value.fraction, "/");
                if (!T(N) || !T(E)) return;
                $ = `calc(${b.value.fraction} * 100%)`;
              }
              if ($ === null && A && f.handleNegativeBareValue) {
                if (
                  (($ = f.handleNegativeBareValue(b.value)),
                  !$?.includes("/") && b.modifier)
                )
                  return;
                if ($ !== null) return f.handle($, null);
              }
              if (
                $ === null &&
                f.handleBareValue &&
                (($ = f.handleBareValue(b.value)),
                !$?.includes("/") && b.modifier)
              )
                return;
              if ($ === null && !A && f.staticValues && !b.modifier) {
                let N = f.staticValues[b.value.value];
                if (N) return N;
              }
            }
          else {
            if (b.modifier) return;
            $ =
              f.defaultValue !== void 0
                ? f.defaultValue
                : e.resolve(null, f.themeKeys ?? []);
          }
          if ($ !== null) return f.handle(A ? `calc(${$} * -1)` : $, P);
        };
      }
      if (
        (f.supportsNegative && r.functional(`-${l}`, h({ negative: !0 })),
        r.functional(l, h({ negative: !1 })),
        i(l, () => [
          {
            supportsNegative: f.supportsNegative,
            valueThemeKeys: f.themeKeys ?? [],
            hasDefaultValue:
              f.defaultValue !== void 0 && f.defaultValue !== null,
            supportsFractions: f.supportsFractions,
          },
        ]),
        f.staticValues && Object.keys(f.staticValues).length > 0)
      ) {
        let A = Object.keys(f.staticValues);
        i(l, () => [{ values: A }]);
      }
    }
    function s(l, f) {
      r.functional(l, (h) => {
        if (!h.value) return;
        let A = null;
        if (
          (h.value.kind === "arbitrary"
            ? ((A = h.value.value), (A = X(A, h.modifier, e)))
            : (A = te(h, e, f.themeKeys)),
          A !== null)
        )
          return f.handle(A);
      }),
        i(l, () => [
          {
            values: ["current", "inherit", "transparent"],
            valueThemeKeys: f.themeKeys,
            modifiers: Array.from({ length: 21 }, (h, A) => `${A * 5}`),
          },
        ]);
    }
    function a(
      l,
      f,
      h,
      {
        supportsNegative: A = !1,
        supportsFractions: b = !1,
        staticValues: $,
      } = {}
    ) {
      A && r.static(`-${l}-px`, () => h("-1px")),
        r.static(`${l}-px`, () => h("1px")),
        o(l, {
          themeKeys: f,
          supportsFractions: b,
          supportsNegative: A,
          defaultValue: null,
          handleBareValue: ({ value: P }) => {
            let N = e.resolve(null, ["--spacing"]);
            return !N || !xe(P) ? null : `calc(${N} * ${P})`;
          },
          handleNegativeBareValue: ({ value: P }) => {
            let N = e.resolve(null, ["--spacing"]);
            return !N || !xe(P) ? null : `calc(${N} * -${P})`;
          },
          handle: h,
          staticValues: $,
        }),
        i(l, () => [
          {
            values: e.get(["--spacing"]) ? lt : [],
            supportsNegative: A,
            supportsFractions: b,
            valueThemeKeys: f,
          },
        ]);
    }
    t("sr-only", [
      ["position", "absolute"],
      ["width", "1px"],
      ["height", "1px"],
      ["padding", "0"],
      ["margin", "-1px"],
      ["overflow", "hidden"],
      ["clip-path", "inset(50%)"],
      ["white-space", "nowrap"],
      ["border-width", "0"],
    ]),
      t("not-sr-only", [
        ["position", "static"],
        ["width", "auto"],
        ["height", "auto"],
        ["padding", "0"],
        ["margin", "0"],
        ["overflow", "visible"],
        ["clip-path", "none"],
        ["white-space", "normal"],
      ]),
      t("pointer-events-none", [["pointer-events", "none"]]),
      t("pointer-events-auto", [["pointer-events", "auto"]]),
      t("visible", [["visibility", "visible"]]),
      t("invisible", [["visibility", "hidden"]]),
      t("collapse", [["visibility", "collapse"]]),
      t("static", [["position", "static"]]),
      t("fixed", [["position", "fixed"]]),
      t("absolute", [["position", "absolute"]]),
      t("relative", [["position", "relative"]]),
      t("sticky", [["position", "sticky"]]);
    for (let [l, f] of [
      ["inset", "inset"],
      ["inset-x", "inset-inline"],
      ["inset-y", "inset-block"],
      ["start", "inset-inline-start"],
      ["end", "inset-inline-end"],
      ["top", "top"],
      ["right", "right"],
      ["bottom", "bottom"],
      ["left", "left"],
    ])
      t(`${l}-auto`, [[f, "auto"]]),
        t(`${l}-full`, [[f, "100%"]]),
        t(`-${l}-full`, [[f, "-100%"]]),
        a(l, ["--inset", "--spacing"], (h) => [n(f, h)], {
          supportsNegative: !0,
          supportsFractions: !0,
        });
    t("isolate", [["isolation", "isolate"]]),
      t("isolation-auto", [["isolation", "auto"]]),
      o("z", {
        supportsNegative: !0,
        handleBareValue: ({ value: l }) => (T(l) ? l : null),
        themeKeys: ["--z-index"],
        handle: (l) => [n("z-index", l)],
        staticValues: { auto: [n("z-index", "auto")] },
      }),
      i("z", () => [
        {
          supportsNegative: !0,
          values: ["0", "10", "20", "30", "40", "50"],
          valueThemeKeys: ["--z-index"],
        },
      ]),
      o("order", {
        supportsNegative: !0,
        handleBareValue: ({ value: l }) => (T(l) ? l : null),
        themeKeys: ["--order"],
        handle: (l) => [n("order", l)],
        staticValues: {
          first: [n("order", "-9999")],
          last: [n("order", "9999")],
        },
      }),
      i("order", () => [
        {
          supportsNegative: !0,
          values: Array.from({ length: 12 }, (l, f) => `${f + 1}`),
          valueThemeKeys: ["--order"],
        },
      ]),
      o("col", {
        supportsNegative: !0,
        handleBareValue: ({ value: l }) => (T(l) ? l : null),
        themeKeys: ["--grid-column"],
        handle: (l) => [n("grid-column", l)],
        staticValues: { auto: [n("grid-column", "auto")] },
      }),
      o("col-span", {
        handleBareValue: ({ value: l }) => (T(l) ? l : null),
        handle: (l) => [n("grid-column", `span ${l} / span ${l}`)],
        staticValues: { full: [n("grid-column", "1 / -1")] },
      }),
      o("col-start", {
        supportsNegative: !0,
        handleBareValue: ({ value: l }) => (T(l) ? l : null),
        themeKeys: ["--grid-column-start"],
        handle: (l) => [n("grid-column-start", l)],
        staticValues: { auto: [n("grid-column-start", "auto")] },
      }),
      o("col-end", {
        supportsNegative: !0,
        handleBareValue: ({ value: l }) => (T(l) ? l : null),
        themeKeys: ["--grid-column-end"],
        handle: (l) => [n("grid-column-end", l)],
        staticValues: { auto: [n("grid-column-end", "auto")] },
      }),
      i("col-span", () => [
        {
          values: Array.from({ length: 12 }, (l, f) => `${f + 1}`),
          valueThemeKeys: [],
        },
      ]),
      i("col-start", () => [
        {
          supportsNegative: !0,
          values: Array.from({ length: 13 }, (l, f) => `${f + 1}`),
          valueThemeKeys: ["--grid-column-start"],
        },
      ]),
      i("col-end", () => [
        {
          supportsNegative: !0,
          values: Array.from({ length: 13 }, (l, f) => `${f + 1}`),
          valueThemeKeys: ["--grid-column-end"],
        },
      ]),
      o("row", {
        supportsNegative: !0,
        handleBareValue: ({ value: l }) => (T(l) ? l : null),
        themeKeys: ["--grid-row"],
        handle: (l) => [n("grid-row", l)],
        staticValues: { auto: [n("grid-row", "auto")] },
      }),
      o("row-span", {
        themeKeys: [],
        handleBareValue: ({ value: l }) => (T(l) ? l : null),
        handle: (l) => [n("grid-row", `span ${l} / span ${l}`)],
        staticValues: { full: [n("grid-row", "1 / -1")] },
      }),
      o("row-start", {
        supportsNegative: !0,
        handleBareValue: ({ value: l }) => (T(l) ? l : null),
        themeKeys: ["--grid-row-start"],
        handle: (l) => [n("grid-row-start", l)],
        staticValues: { auto: [n("grid-row-start", "auto")] },
      }),
      o("row-end", {
        supportsNegative: !0,
        handleBareValue: ({ value: l }) => (T(l) ? l : null),
        themeKeys: ["--grid-row-end"],
        handle: (l) => [n("grid-row-end", l)],
        staticValues: { auto: [n("grid-row-end", "auto")] },
      }),
      i("row-span", () => [
        {
          values: Array.from({ length: 12 }, (l, f) => `${f + 1}`),
          valueThemeKeys: [],
        },
      ]),
      i("row-start", () => [
        {
          supportsNegative: !0,
          values: Array.from({ length: 13 }, (l, f) => `${f + 1}`),
          valueThemeKeys: ["--grid-row-start"],
        },
      ]),
      i("row-end", () => [
        {
          supportsNegative: !0,
          values: Array.from({ length: 13 }, (l, f) => `${f + 1}`),
          valueThemeKeys: ["--grid-row-end"],
        },
      ]),
      t("float-start", [["float", "inline-start"]]),
      t("float-end", [["float", "inline-end"]]),
      t("float-right", [["float", "right"]]),
      t("float-left", [["float", "left"]]),
      t("float-none", [["float", "none"]]),
      t("clear-start", [["clear", "inline-start"]]),
      t("clear-end", [["clear", "inline-end"]]),
      t("clear-right", [["clear", "right"]]),
      t("clear-left", [["clear", "left"]]),
      t("clear-both", [["clear", "both"]]),
      t("clear-none", [["clear", "none"]]);
    for (let [l, f] of [
      ["m", "margin"],
      ["mx", "margin-inline"],
      ["my", "margin-block"],
      ["ms", "margin-inline-start"],
      ["me", "margin-inline-end"],
      ["mt", "margin-top"],
      ["mr", "margin-right"],
      ["mb", "margin-bottom"],
      ["ml", "margin-left"],
    ])
      t(`${l}-auto`, [[f, "auto"]]),
        a(l, ["--margin", "--spacing"], (h) => [n(f, h)], {
          supportsNegative: !0,
        });
    t("box-border", [["box-sizing", "border-box"]]),
      t("box-content", [["box-sizing", "content-box"]]),
      o("line-clamp", {
        themeKeys: ["--line-clamp"],
        handleBareValue: ({ value: l }) => (T(l) ? l : null),
        handle: (l) => [
          n("overflow", "hidden"),
          n("display", "-webkit-box"),
          n("-webkit-box-orient", "vertical"),
          n("-webkit-line-clamp", l),
        ],
        staticValues: {
          none: [
            n("overflow", "visible"),
            n("display", "block"),
            n("-webkit-box-orient", "horizontal"),
            n("-webkit-line-clamp", "unset"),
          ],
        },
      }),
      i("line-clamp", () => [
        {
          values: ["1", "2", "3", "4", "5", "6"],
          valueThemeKeys: ["--line-clamp"],
        },
      ]),
      t("block", [["display", "block"]]),
      t("inline-block", [["display", "inline-block"]]),
      t("inline", [["display", "inline"]]),
      t("hidden", [["display", "none"]]),
      t("inline-flex", [["display", "inline-flex"]]),
      t("table", [["display", "table"]]),
      t("inline-table", [["display", "inline-table"]]),
      t("table-caption", [["display", "table-caption"]]),
      t("table-cell", [["display", "table-cell"]]),
      t("table-column", [["display", "table-column"]]),
      t("table-column-group", [["display", "table-column-group"]]),
      t("table-footer-group", [["display", "table-footer-group"]]),
      t("table-header-group", [["display", "table-header-group"]]),
      t("table-row-group", [["display", "table-row-group"]]),
      t("table-row", [["display", "table-row"]]),
      t("flow-root", [["display", "flow-root"]]),
      t("flex", [["display", "flex"]]),
      t("grid", [["display", "grid"]]),
      t("inline-grid", [["display", "inline-grid"]]),
      t("contents", [["display", "contents"]]),
      t("list-item", [["display", "list-item"]]),
      t("field-sizing-content", [["field-sizing", "content"]]),
      t("field-sizing-fixed", [["field-sizing", "fixed"]]),
      o("aspect", {
        themeKeys: ["--aspect"],
        handleBareValue: ({ fraction: l }) => {
          if (l === null) return null;
          let [f, h] = z(l, "/");
          return !T(f) || !T(h) ? null : l;
        },
        handle: (l) => [n("aspect-ratio", l)],
        staticValues: {
          auto: [n("aspect-ratio", "auto")],
          square: [n("aspect-ratio", "1 / 1")],
        },
      });
    for (let [l, f] of [
      ["full", "100%"],
      ["svw", "100svw"],
      ["lvw", "100lvw"],
      ["dvw", "100dvw"],
      ["svh", "100svh"],
      ["lvh", "100lvh"],
      ["dvh", "100dvh"],
      ["min", "min-content"],
      ["max", "max-content"],
      ["fit", "fit-content"],
    ])
      t(`size-${l}`, [
        ["--tw-sort", "size"],
        ["width", f],
        ["height", f],
      ]),
        t(`w-${l}`, [["width", f]]),
        t(`h-${l}`, [["height", f]]),
        t(`min-w-${l}`, [["min-width", f]]),
        t(`min-h-${l}`, [["min-height", f]]),
        t(`max-w-${l}`, [["max-width", f]]),
        t(`max-h-${l}`, [["max-height", f]]);
    t("size-auto", [
      ["--tw-sort", "size"],
      ["width", "auto"],
      ["height", "auto"],
    ]),
      t("w-auto", [["width", "auto"]]),
      t("h-auto", [["height", "auto"]]),
      t("min-w-auto", [["min-width", "auto"]]),
      t("min-h-auto", [["min-height", "auto"]]),
      t("h-lh", [["height", "1lh"]]),
      t("min-h-lh", [["min-height", "1lh"]]),
      t("max-h-lh", [["max-height", "1lh"]]),
      t("w-screen", [["width", "100vw"]]),
      t("min-w-screen", [["min-width", "100vw"]]),
      t("max-w-screen", [["max-width", "100vw"]]),
      t("h-screen", [["height", "100vh"]]),
      t("min-h-screen", [["min-height", "100vh"]]),
      t("max-h-screen", [["max-height", "100vh"]]),
      t("max-w-none", [["max-width", "none"]]),
      t("max-h-none", [["max-height", "none"]]),
      a(
        "size",
        ["--size", "--spacing"],
        (l) => [n("--tw-sort", "size"), n("width", l), n("height", l)],
        { supportsFractions: !0 }
      );
    for (let [l, f, h] of [
      ["w", ["--width", "--spacing", "--container"], "width"],
      ["min-w", ["--min-width", "--spacing", "--container"], "min-width"],
      ["max-w", ["--max-width", "--spacing", "--container"], "max-width"],
      ["h", ["--height", "--spacing"], "height"],
      ["min-h", ["--min-height", "--height", "--spacing"], "min-height"],
      ["max-h", ["--max-height", "--height", "--spacing"], "max-height"],
    ])
      a(l, f, (A) => [n(h, A)], { supportsFractions: !0 });
    r.static("container", () => {
      let l = [...e.namespace("--breakpoint").values()];
      l.sort((h, A) => ye(h, A, "asc"));
      let f = [n("--tw-sort", "--tw-container-component"), n("width", "100%")];
      for (let h of l)
        f.push(F("@media", `(width >= ${h})`, [n("max-width", h)]));
      return f;
    }),
      t("flex-auto", [["flex", "auto"]]),
      t("flex-initial", [["flex", "0 auto"]]),
      t("flex-none", [["flex", "none"]]),
      r.functional("flex", (l) => {
        if (l.value) {
          if (l.value.kind === "arbitrary")
            return l.modifier ? void 0 : [n("flex", l.value.value)];
          if (l.value.fraction) {
            let [f, h] = z(l.value.fraction, "/");
            return !T(f) || !T(h)
              ? void 0
              : [n("flex", `calc(${l.value.fraction} * 100%)`)];
          }
          if (T(l.value.value))
            return l.modifier ? void 0 : [n("flex", l.value.value)];
        }
      }),
      i("flex", () => [
        { supportsFractions: !0 },
        { values: Array.from({ length: 12 }, (l, f) => `${f + 1}`) },
      ]),
      o("shrink", {
        defaultValue: "1",
        handleBareValue: ({ value: l }) => (T(l) ? l : null),
        handle: (l) => [n("flex-shrink", l)],
      }),
      o("grow", {
        defaultValue: "1",
        handleBareValue: ({ value: l }) => (T(l) ? l : null),
        handle: (l) => [n("flex-grow", l)],
      }),
      i("shrink", () => [
        { values: ["0"], valueThemeKeys: [], hasDefaultValue: !0 },
      ]),
      i("grow", () => [
        { values: ["0"], valueThemeKeys: [], hasDefaultValue: !0 },
      ]),
      t("basis-auto", [["flex-basis", "auto"]]),
      t("basis-full", [["flex-basis", "100%"]]),
      a(
        "basis",
        ["--flex-basis", "--spacing", "--container"],
        (l) => [n("flex-basis", l)],
        { supportsFractions: !0 }
      ),
      t("table-auto", [["table-layout", "auto"]]),
      t("table-fixed", [["table-layout", "fixed"]]),
      t("caption-top", [["caption-side", "top"]]),
      t("caption-bottom", [["caption-side", "bottom"]]),
      t("border-collapse", [["border-collapse", "collapse"]]),
      t("border-separate", [["border-collapse", "separate"]]);
    let d = () =>
      j([
        S("--tw-border-spacing-x", "0", "<length>"),
        S("--tw-border-spacing-y", "0", "<length>"),
      ]);
    a("border-spacing", ["--border-spacing", "--spacing"], (l) => [
      d(),
      n("--tw-border-spacing-x", l),
      n("--tw-border-spacing-y", l),
      n(
        "border-spacing",
        "var(--tw-border-spacing-x) var(--tw-border-spacing-y)"
      ),
    ]),
      a("border-spacing-x", ["--border-spacing", "--spacing"], (l) => [
        d(),
        n("--tw-border-spacing-x", l),
        n(
          "border-spacing",
          "var(--tw-border-spacing-x) var(--tw-border-spacing-y)"
        ),
      ]),
      a("border-spacing-y", ["--border-spacing", "--spacing"], (l) => [
        d(),
        n("--tw-border-spacing-y", l),
        n(
          "border-spacing",
          "var(--tw-border-spacing-x) var(--tw-border-spacing-y)"
        ),
      ]),
      o("origin", {
        themeKeys: ["--transform-origin"],
        handle: (l) => [n("transform-origin", l)],
        staticValues: {
          center: [n("transform-origin", "center")],
          top: [n("transform-origin", "top")],
          "top-right": [n("transform-origin", "100% 0")],
          right: [n("transform-origin", "100%")],
          "bottom-right": [n("transform-origin", "100% 100%")],
          bottom: [n("transform-origin", "bottom")],
          "bottom-left": [n("transform-origin", "0 100%")],
          left: [n("transform-origin", "0")],
          "top-left": [n("transform-origin", "0 0")],
        },
      }),
      o("perspective-origin", {
        themeKeys: ["--perspective-origin"],
        handle: (l) => [n("perspective-origin", l)],
        staticValues: {
          center: [n("perspective-origin", "center")],
          top: [n("perspective-origin", "top")],
          "top-right": [n("perspective-origin", "100% 0")],
          right: [n("perspective-origin", "100%")],
          "bottom-right": [n("perspective-origin", "100% 100%")],
          bottom: [n("perspective-origin", "bottom")],
          "bottom-left": [n("perspective-origin", "0 100%")],
          left: [n("perspective-origin", "0")],
          "top-left": [n("perspective-origin", "0 0")],
        },
      }),
      o("perspective", {
        themeKeys: ["--perspective"],
        handle: (l) => [n("perspective", l)],
        staticValues: { none: [n("perspective", "none")] },
      });
    let u = () =>
      j([
        S("--tw-translate-x", "0"),
        S("--tw-translate-y", "0"),
        S("--tw-translate-z", "0"),
      ]);
    t("translate-none", [["translate", "none"]]),
      t("-translate-full", [
        u,
        ["--tw-translate-x", "-100%"],
        ["--tw-translate-y", "-100%"],
        ["translate", "var(--tw-translate-x) var(--tw-translate-y)"],
      ]),
      t("translate-full", [
        u,
        ["--tw-translate-x", "100%"],
        ["--tw-translate-y", "100%"],
        ["translate", "var(--tw-translate-x) var(--tw-translate-y)"],
      ]),
      a(
        "translate",
        ["--translate", "--spacing"],
        (l) => [
          u(),
          n("--tw-translate-x", l),
          n("--tw-translate-y", l),
          n("translate", "var(--tw-translate-x) var(--tw-translate-y)"),
        ],
        { supportsNegative: !0, supportsFractions: !0 }
      );
    for (let l of ["x", "y"])
      t(`-translate-${l}-full`, [
        u,
        [`--tw-translate-${l}`, "-100%"],
        ["translate", "var(--tw-translate-x) var(--tw-translate-y)"],
      ]),
        t(`translate-${l}-full`, [
          u,
          [`--tw-translate-${l}`, "100%"],
          ["translate", "var(--tw-translate-x) var(--tw-translate-y)"],
        ]),
        a(
          `translate-${l}`,
          ["--translate", "--spacing"],
          (f) => [
            u(),
            n(`--tw-translate-${l}`, f),
            n("translate", "var(--tw-translate-x) var(--tw-translate-y)"),
          ],
          { supportsNegative: !0, supportsFractions: !0 }
        );
    a(
      "translate-z",
      ["--translate", "--spacing"],
      (l) => [
        u(),
        n("--tw-translate-z", l),
        n(
          "translate",
          "var(--tw-translate-x) var(--tw-translate-y) var(--tw-translate-z)"
        ),
      ],
      { supportsNegative: !0 }
    ),
      t("translate-3d", [
        u,
        [
          "translate",
          "var(--tw-translate-x) var(--tw-translate-y) var(--tw-translate-z)",
        ],
      ]);
    let c = () =>
      j([
        S("--tw-scale-x", "1"),
        S("--tw-scale-y", "1"),
        S("--tw-scale-z", "1"),
      ]);
    t("scale-none", [["scale", "none"]]);
    function m({ negative: l }) {
      return (f) => {
        if (!f.value || f.modifier) return;
        let h;
        return f.value.kind === "arbitrary"
          ? ((h = f.value.value),
            (h = l ? `calc(${h} * -1)` : h),
            [n("scale", h)])
          : ((h = e.resolve(f.value.value, ["--scale"])),
            !h && T(f.value.value) && (h = `${f.value.value}%`),
            h
              ? ((h = l ? `calc(${h} * -1)` : h),
                [
                  c(),
                  n("--tw-scale-x", h),
                  n("--tw-scale-y", h),
                  n("--tw-scale-z", h),
                  n("scale", "var(--tw-scale-x) var(--tw-scale-y)"),
                ])
              : void 0);
      };
    }
    r.functional("-scale", m({ negative: !0 })),
      r.functional("scale", m({ negative: !1 })),
      i("scale", () => [
        {
          supportsNegative: !0,
          values: [
            "0",
            "50",
            "75",
            "90",
            "95",
            "100",
            "105",
            "110",
            "125",
            "150",
            "200",
          ],
          valueThemeKeys: ["--scale"],
        },
      ]);
    for (let l of ["x", "y", "z"])
      o(`scale-${l}`, {
        supportsNegative: !0,
        themeKeys: ["--scale"],
        handleBareValue: ({ value: f }) => (T(f) ? `${f}%` : null),
        handle: (f) => [
          c(),
          n(`--tw-scale-${l}`, f),
          n(
            "scale",
            `var(--tw-scale-x) var(--tw-scale-y)${
              l === "z" ? " var(--tw-scale-z)" : ""
            }`
          ),
        ],
      }),
        i(`scale-${l}`, () => [
          {
            supportsNegative: !0,
            values: [
              "0",
              "50",
              "75",
              "90",
              "95",
              "100",
              "105",
              "110",
              "125",
              "150",
              "200",
            ],
            valueThemeKeys: ["--scale"],
          },
        ]);
    t("scale-3d", [
      c,
      ["scale", "var(--tw-scale-x) var(--tw-scale-y) var(--tw-scale-z)"],
    ]),
      t("rotate-none", [["rotate", "none"]]);
    function g({ negative: l }) {
      return (f) => {
        if (!f.value || f.modifier) return;
        let h;
        if (f.value.kind === "arbitrary") {
          h = f.value.value;
          let A = f.value.dataType ?? Z(h, ["angle", "vector"]);
          if (A === "vector") return [n("rotate", `${h} var(--tw-rotate)`)];
          if (A !== "angle") return [n("rotate", l ? `calc(${h} * -1)` : h)];
        } else if (
          ((h = e.resolve(f.value.value, ["--rotate"])),
          !h && T(f.value.value) && (h = `${f.value.value}deg`),
          !h)
        )
          return;
        return [n("rotate", l ? `calc(${h} * -1)` : h)];
      };
    }
    r.functional("-rotate", g({ negative: !0 })),
      r.functional("rotate", g({ negative: !1 })),
      i("rotate", () => [
        {
          supportsNegative: !0,
          values: ["0", "1", "2", "3", "6", "12", "45", "90", "180"],
          valueThemeKeys: ["--rotate"],
        },
      ]);
    {
      let l = [
          "var(--tw-rotate-x,)",
          "var(--tw-rotate-y,)",
          "var(--tw-rotate-z,)",
          "var(--tw-skew-x,)",
          "var(--tw-skew-y,)",
        ].join(" "),
        f = () =>
          j([
            S("--tw-rotate-x"),
            S("--tw-rotate-y"),
            S("--tw-rotate-z"),
            S("--tw-skew-x"),
            S("--tw-skew-y"),
          ]);
      for (let h of ["x", "y", "z"])
        o(`rotate-${h}`, {
          supportsNegative: !0,
          themeKeys: ["--rotate"],
          handleBareValue: ({ value: A }) => (T(A) ? `${A}deg` : null),
          handle: (A) => [
            f(),
            n(`--tw-rotate-${h}`, `rotate${h.toUpperCase()}(${A})`),
            n("transform", l),
          ],
        }),
          i(`rotate-${h}`, () => [
            {
              supportsNegative: !0,
              values: ["0", "1", "2", "3", "6", "12", "45", "90", "180"],
              valueThemeKeys: ["--rotate"],
            },
          ]);
      o("skew", {
        supportsNegative: !0,
        themeKeys: ["--skew"],
        handleBareValue: ({ value: h }) => (T(h) ? `${h}deg` : null),
        handle: (h) => [
          f(),
          n("--tw-skew-x", `skewX(${h})`),
          n("--tw-skew-y", `skewY(${h})`),
          n("transform", l),
        ],
      }),
        o("skew-x", {
          supportsNegative: !0,
          themeKeys: ["--skew"],
          handleBareValue: ({ value: h }) => (T(h) ? `${h}deg` : null),
          handle: (h) => [
            f(),
            n("--tw-skew-x", `skewX(${h})`),
            n("transform", l),
          ],
        }),
        o("skew-y", {
          supportsNegative: !0,
          themeKeys: ["--skew"],
          handleBareValue: ({ value: h }) => (T(h) ? `${h}deg` : null),
          handle: (h) => [
            f(),
            n("--tw-skew-y", `skewY(${h})`),
            n("transform", l),
          ],
        }),
        i("skew", () => [
          {
            supportsNegative: !0,
            values: ["0", "1", "2", "3", "6", "12"],
            valueThemeKeys: ["--skew"],
          },
        ]),
        i("skew-x", () => [
          {
            supportsNegative: !0,
            values: ["0", "1", "2", "3", "6", "12"],
            valueThemeKeys: ["--skew"],
          },
        ]),
        i("skew-y", () => [
          {
            supportsNegative: !0,
            values: ["0", "1", "2", "3", "6", "12"],
            valueThemeKeys: ["--skew"],
          },
        ]),
        r.functional("transform", (h) => {
          if (h.modifier) return;
          let A = null;
          if (
            (h.value
              ? h.value.kind === "arbitrary" && (A = h.value.value)
              : (A = l),
            A !== null)
          )
            return [f(), n("transform", A)];
        }),
        i("transform", () => [{ hasDefaultValue: !0 }]),
        t("transform-cpu", [["transform", l]]),
        t("transform-gpu", [["transform", `translateZ(0) ${l}`]]),
        t("transform-none", [["transform", "none"]]);
    }
    t("transform-flat", [["transform-style", "flat"]]),
      t("transform-3d", [["transform-style", "preserve-3d"]]),
      t("transform-content", [["transform-box", "content-box"]]),
      t("transform-border", [["transform-box", "border-box"]]),
      t("transform-fill", [["transform-box", "fill-box"]]),
      t("transform-stroke", [["transform-box", "stroke-box"]]),
      t("transform-view", [["transform-box", "view-box"]]),
      t("backface-visible", [["backface-visibility", "visible"]]),
      t("backface-hidden", [["backface-visibility", "hidden"]]);
    for (let l of [
      "auto",
      "default",
      "pointer",
      "wait",
      "text",
      "move",
      "help",
      "not-allowed",
      "none",
      "context-menu",
      "progress",
      "cell",
      "crosshair",
      "vertical-text",
      "alias",
      "copy",
      "no-drop",
      "grab",
      "grabbing",
      "all-scroll",
      "col-resize",
      "row-resize",
      "n-resize",
      "e-resize",
      "s-resize",
      "w-resize",
      "ne-resize",
      "nw-resize",
      "se-resize",
      "sw-resize",
      "ew-resize",
      "ns-resize",
      "nesw-resize",
      "nwse-resize",
      "zoom-in",
      "zoom-out",
    ])
      t(`cursor-${l}`, [["cursor", l]]);
    o("cursor", { themeKeys: ["--cursor"], handle: (l) => [n("cursor", l)] });
    for (let l of ["auto", "none", "manipulation"])
      t(`touch-${l}`, [["touch-action", l]]);
    let p = () => j([S("--tw-pan-x"), S("--tw-pan-y"), S("--tw-pinch-zoom")]);
    for (let l of ["x", "left", "right"])
      t(`touch-pan-${l}`, [
        p,
        ["--tw-pan-x", `pan-${l}`],
        [
          "touch-action",
          "var(--tw-pan-x,) var(--tw-pan-y,) var(--tw-pinch-zoom,)",
        ],
      ]);
    for (let l of ["y", "up", "down"])
      t(`touch-pan-${l}`, [
        p,
        ["--tw-pan-y", `pan-${l}`],
        [
          "touch-action",
          "var(--tw-pan-x,) var(--tw-pan-y,) var(--tw-pinch-zoom,)",
        ],
      ]);
    t("touch-pinch-zoom", [
      p,
      ["--tw-pinch-zoom", "pinch-zoom"],
      [
        "touch-action",
        "var(--tw-pan-x,) var(--tw-pan-y,) var(--tw-pinch-zoom,)",
      ],
    ]);
    for (let l of ["none", "text", "all", "auto"])
      t(`select-${l}`, [
        ["-webkit-user-select", l],
        ["user-select", l],
      ]);
    t("resize-none", [["resize", "none"]]),
      t("resize-x", [["resize", "horizontal"]]),
      t("resize-y", [["resize", "vertical"]]),
      t("resize", [["resize", "both"]]),
      t("snap-none", [["scroll-snap-type", "none"]]);
    let v = () => j([S("--tw-scroll-snap-strictness", "proximity", "*")]);
    for (let l of ["x", "y", "both"])
      t(`snap-${l}`, [
        v,
        ["scroll-snap-type", `${l} var(--tw-scroll-snap-strictness)`],
      ]);
    t("snap-mandatory", [v, ["--tw-scroll-snap-strictness", "mandatory"]]),
      t("snap-proximity", [v, ["--tw-scroll-snap-strictness", "proximity"]]),
      t("snap-align-none", [["scroll-snap-align", "none"]]),
      t("snap-start", [["scroll-snap-align", "start"]]),
      t("snap-end", [["scroll-snap-align", "end"]]),
      t("snap-center", [["scroll-snap-align", "center"]]),
      t("snap-normal", [["scroll-snap-stop", "normal"]]),
      t("snap-always", [["scroll-snap-stop", "always"]]);
    for (let [l, f] of [
      ["scroll-m", "scroll-margin"],
      ["scroll-mx", "scroll-margin-inline"],
      ["scroll-my", "scroll-margin-block"],
      ["scroll-ms", "scroll-margin-inline-start"],
      ["scroll-me", "scroll-margin-inline-end"],
      ["scroll-mt", "scroll-margin-top"],
      ["scroll-mr", "scroll-margin-right"],
      ["scroll-mb", "scroll-margin-bottom"],
      ["scroll-ml", "scroll-margin-left"],
    ])
      a(l, ["--scroll-margin", "--spacing"], (h) => [n(f, h)], {
        supportsNegative: !0,
      });
    for (let [l, f] of [
      ["scroll-p", "scroll-padding"],
      ["scroll-px", "scroll-padding-inline"],
      ["scroll-py", "scroll-padding-block"],
      ["scroll-ps", "scroll-padding-inline-start"],
      ["scroll-pe", "scroll-padding-inline-end"],
      ["scroll-pt", "scroll-padding-top"],
      ["scroll-pr", "scroll-padding-right"],
      ["scroll-pb", "scroll-padding-bottom"],
      ["scroll-pl", "scroll-padding-left"],
    ])
      a(l, ["--scroll-padding", "--spacing"], (h) => [n(f, h)]);
    t("list-inside", [["list-style-position", "inside"]]),
      t("list-outside", [["list-style-position", "outside"]]),
      o("list", {
        themeKeys: ["--list-style-type"],
        handle: (l) => [n("list-style-type", l)],
        staticValues: {
          none: [n("list-style-type", "none")],
          disc: [n("list-style-type", "disc")],
          decimal: [n("list-style-type", "decimal")],
        },
      }),
      o("list-image", {
        themeKeys: ["--list-style-image"],
        handle: (l) => [n("list-style-image", l)],
        staticValues: { none: [n("list-style-image", "none")] },
      }),
      t("appearance-none", [["appearance", "none"]]),
      t("appearance-auto", [["appearance", "auto"]]),
      t("scheme-normal", [["color-scheme", "normal"]]),
      t("scheme-dark", [["color-scheme", "dark"]]),
      t("scheme-light", [["color-scheme", "light"]]),
      t("scheme-light-dark", [["color-scheme", "light dark"]]),
      t("scheme-only-dark", [["color-scheme", "only dark"]]),
      t("scheme-only-light", [["color-scheme", "only light"]]),
      o("columns", {
        themeKeys: ["--columns", "--container"],
        handleBareValue: ({ value: l }) => (T(l) ? l : null),
        handle: (l) => [n("columns", l)],
        staticValues: { auto: [n("columns", "auto")] },
      }),
      i("columns", () => [
        {
          values: Array.from({ length: 12 }, (l, f) => `${f + 1}`),
          valueThemeKeys: ["--columns", "--container"],
        },
      ]);
    for (let l of [
      "auto",
      "avoid",
      "all",
      "avoid-page",
      "page",
      "left",
      "right",
      "column",
    ])
      t(`break-before-${l}`, [["break-before", l]]);
    for (let l of ["auto", "avoid", "avoid-page", "avoid-column"])
      t(`break-inside-${l}`, [["break-inside", l]]);
    for (let l of [
      "auto",
      "avoid",
      "all",
      "avoid-page",
      "page",
      "left",
      "right",
      "column",
    ])
      t(`break-after-${l}`, [["break-after", l]]);
    t("grid-flow-row", [["grid-auto-flow", "row"]]),
      t("grid-flow-col", [["grid-auto-flow", "column"]]),
      t("grid-flow-dense", [["grid-auto-flow", "dense"]]),
      t("grid-flow-row-dense", [["grid-auto-flow", "row dense"]]),
      t("grid-flow-col-dense", [["grid-auto-flow", "column dense"]]),
      o("auto-cols", {
        themeKeys: ["--grid-auto-columns"],
        handle: (l) => [n("grid-auto-columns", l)],
        staticValues: {
          auto: [n("grid-auto-columns", "auto")],
          min: [n("grid-auto-columns", "min-content")],
          max: [n("grid-auto-columns", "max-content")],
          fr: [n("grid-auto-columns", "minmax(0, 1fr)")],
        },
      }),
      o("auto-rows", {
        themeKeys: ["--grid-auto-rows"],
        handle: (l) => [n("grid-auto-rows", l)],
        staticValues: {
          auto: [n("grid-auto-rows", "auto")],
          min: [n("grid-auto-rows", "min-content")],
          max: [n("grid-auto-rows", "max-content")],
          fr: [n("grid-auto-rows", "minmax(0, 1fr)")],
        },
      }),
      o("grid-cols", {
        themeKeys: ["--grid-template-columns"],
        handleBareValue: ({ value: l }) =>
          _t(l) ? `repeat(${l}, minmax(0, 1fr))` : null,
        handle: (l) => [n("grid-template-columns", l)],
        staticValues: {
          none: [n("grid-template-columns", "none")],
          subgrid: [n("grid-template-columns", "subgrid")],
        },
      }),
      o("grid-rows", {
        themeKeys: ["--grid-template-rows"],
        handleBareValue: ({ value: l }) =>
          _t(l) ? `repeat(${l}, minmax(0, 1fr))` : null,
        handle: (l) => [n("grid-template-rows", l)],
        staticValues: {
          none: [n("grid-template-rows", "none")],
          subgrid: [n("grid-template-rows", "subgrid")],
        },
      }),
      i("grid-cols", () => [
        {
          values: Array.from({ length: 12 }, (l, f) => `${f + 1}`),
          valueThemeKeys: ["--grid-template-columns"],
        },
      ]),
      i("grid-rows", () => [
        {
          values: Array.from({ length: 12 }, (l, f) => `${f + 1}`),
          valueThemeKeys: ["--grid-template-rows"],
        },
      ]),
      t("flex-row", [["flex-direction", "row"]]),
      t("flex-row-reverse", [["flex-direction", "row-reverse"]]),
      t("flex-col", [["flex-direction", "column"]]),
      t("flex-col-reverse", [["flex-direction", "column-reverse"]]),
      t("flex-wrap", [["flex-wrap", "wrap"]]),
      t("flex-nowrap", [["flex-wrap", "nowrap"]]),
      t("flex-wrap-reverse", [["flex-wrap", "wrap-reverse"]]),
      t("place-content-center", [["place-content", "center"]]),
      t("place-content-start", [["place-content", "start"]]),
      t("place-content-end", [["place-content", "end"]]),
      t("place-content-center-safe", [["place-content", "safe center"]]),
      t("place-content-end-safe", [["place-content", "safe end"]]),
      t("place-content-between", [["place-content", "space-between"]]),
      t("place-content-around", [["place-content", "space-around"]]),
      t("place-content-evenly", [["place-content", "space-evenly"]]),
      t("place-content-baseline", [["place-content", "baseline"]]),
      t("place-content-stretch", [["place-content", "stretch"]]),
      t("place-items-center", [["place-items", "center"]]),
      t("place-items-start", [["place-items", "start"]]),
      t("place-items-end", [["place-items", "end"]]),
      t("place-items-center-safe", [["place-items", "safe center"]]),
      t("place-items-end-safe", [["place-items", "safe end"]]),
      t("place-items-baseline", [["place-items", "baseline"]]),
      t("place-items-stretch", [["place-items", "stretch"]]),
      t("content-normal", [["align-content", "normal"]]),
      t("content-center", [["align-content", "center"]]),
      t("content-start", [["align-content", "flex-start"]]),
      t("content-end", [["align-content", "flex-end"]]),
      t("content-center-safe", [["align-content", "safe center"]]),
      t("content-end-safe", [["align-content", "safe flex-end"]]),
      t("content-between", [["align-content", "space-between"]]),
      t("content-around", [["align-content", "space-around"]]),
      t("content-evenly", [["align-content", "space-evenly"]]),
      t("content-baseline", [["align-content", "baseline"]]),
      t("content-stretch", [["align-content", "stretch"]]),
      t("items-center", [["align-items", "center"]]),
      t("items-start", [["align-items", "flex-start"]]),
      t("items-end", [["align-items", "flex-end"]]),
      t("items-center-safe", [["align-items", "safe center"]]),
      t("items-end-safe", [["align-items", "safe flex-end"]]),
      t("items-baseline", [["align-items", "baseline"]]),
      t("items-baseline-last", [["align-items", "last baseline"]]),
      t("items-stretch", [["align-items", "stretch"]]),
      t("justify-normal", [["justify-content", "normal"]]),
      t("justify-center", [["justify-content", "center"]]),
      t("justify-start", [["justify-content", "flex-start"]]),
      t("justify-end", [["justify-content", "flex-end"]]),
      t("justify-center-safe", [["justify-content", "safe center"]]),
      t("justify-end-safe", [["justify-content", "safe flex-end"]]),
      t("justify-between", [["justify-content", "space-between"]]),
      t("justify-around", [["justify-content", "space-around"]]),
      t("justify-evenly", [["justify-content", "space-evenly"]]),
      t("justify-baseline", [["justify-content", "baseline"]]),
      t("justify-stretch", [["justify-content", "stretch"]]),
      t("justify-items-normal", [["justify-items", "normal"]]),
      t("justify-items-center", [["justify-items", "center"]]),
      t("justify-items-start", [["justify-items", "start"]]),
      t("justify-items-end", [["justify-items", "end"]]),
      t("justify-items-center-safe", [["justify-items", "safe center"]]),
      t("justify-items-end-safe", [["justify-items", "safe end"]]),
      t("justify-items-stretch", [["justify-items", "stretch"]]),
      a("gap", ["--gap", "--spacing"], (l) => [n("gap", l)]),
      a("gap-x", ["--gap", "--spacing"], (l) => [n("column-gap", l)]),
      a("gap-y", ["--gap", "--spacing"], (l) => [n("row-gap", l)]),
      a(
        "space-x",
        ["--space", "--spacing"],
        (l) => [
          j([S("--tw-space-x-reverse", "0")]),
          W(":where(& > :not(:last-child))", [
            n("--tw-sort", "row-gap"),
            n("--tw-space-x-reverse", "0"),
            n("margin-inline-start", `calc(${l} * var(--tw-space-x-reverse))`),
            n(
              "margin-inline-end",
              `calc(${l} * calc(1 - var(--tw-space-x-reverse)))`
            ),
          ]),
        ],
        { supportsNegative: !0 }
      ),
      a(
        "space-y",
        ["--space", "--spacing"],
        (l) => [
          j([S("--tw-space-y-reverse", "0")]),
          W(":where(& > :not(:last-child))", [
            n("--tw-sort", "column-gap"),
            n("--tw-space-y-reverse", "0"),
            n("margin-block-start", `calc(${l} * var(--tw-space-y-reverse))`),
            n(
              "margin-block-end",
              `calc(${l} * calc(1 - var(--tw-space-y-reverse)))`
            ),
          ]),
        ],
        { supportsNegative: !0 }
      ),
      t("space-x-reverse", [
        () => j([S("--tw-space-x-reverse", "0")]),
        () =>
          W(":where(& > :not(:last-child))", [
            n("--tw-sort", "row-gap"),
            n("--tw-space-x-reverse", "1"),
          ]),
      ]),
      t("space-y-reverse", [
        () => j([S("--tw-space-y-reverse", "0")]),
        () =>
          W(":where(& > :not(:last-child))", [
            n("--tw-sort", "column-gap"),
            n("--tw-space-y-reverse", "1"),
          ]),
      ]),
      t("accent-auto", [["accent-color", "auto"]]),
      s("accent", {
        themeKeys: ["--accent-color", "--color"],
        handle: (l) => [n("accent-color", l)],
      }),
      s("caret", {
        themeKeys: ["--caret-color", "--color"],
        handle: (l) => [n("caret-color", l)],
      }),
      s("divide", {
        themeKeys: ["--divide-color", "--border-color", "--color"],
        handle: (l) => [
          W(":where(& > :not(:last-child))", [
            n("--tw-sort", "divide-color"),
            n("border-color", l),
          ]),
        ],
      }),
      t("place-self-auto", [["place-self", "auto"]]),
      t("place-self-start", [["place-self", "start"]]),
      t("place-self-end", [["place-self", "end"]]),
      t("place-self-center", [["place-self", "center"]]),
      t("place-self-end-safe", [["place-self", "safe end"]]),
      t("place-self-center-safe", [["place-self", "safe center"]]),
      t("place-self-stretch", [["place-self", "stretch"]]),
      t("self-auto", [["align-self", "auto"]]),
      t("self-start", [["align-self", "flex-start"]]),
      t("self-end", [["align-self", "flex-end"]]),
      t("self-center", [["align-self", "center"]]),
      t("self-end-safe", [["align-self", "safe flex-end"]]),
      t("self-center-safe", [["align-self", "safe center"]]),
      t("self-stretch", [["align-self", "stretch"]]),
      t("self-baseline", [["align-self", "baseline"]]),
      t("self-baseline-last", [["align-self", "last baseline"]]),
      t("justify-self-auto", [["justify-self", "auto"]]),
      t("justify-self-start", [["justify-self", "flex-start"]]),
      t("justify-self-end", [["justify-self", "flex-end"]]),
      t("justify-self-center", [["justify-self", "center"]]),
      t("justify-self-end-safe", [["justify-self", "safe flex-end"]]),
      t("justify-self-center-safe", [["justify-self", "safe center"]]),
      t("justify-self-stretch", [["justify-self", "stretch"]]);
    for (let l of ["auto", "hidden", "clip", "visible", "scroll"])
      t(`overflow-${l}`, [["overflow", l]]),
        t(`overflow-x-${l}`, [["overflow-x", l]]),
        t(`overflow-y-${l}`, [["overflow-y", l]]);
    for (let l of ["auto", "contain", "none"])
      t(`overscroll-${l}`, [["overscroll-behavior", l]]),
        t(`overscroll-x-${l}`, [["overscroll-behavior-x", l]]),
        t(`overscroll-y-${l}`, [["overscroll-behavior-y", l]]);
    t("scroll-auto", [["scroll-behavior", "auto"]]),
      t("scroll-smooth", [["scroll-behavior", "smooth"]]),
      t("truncate", [
        ["overflow", "hidden"],
        ["text-overflow", "ellipsis"],
        ["white-space", "nowrap"],
      ]),
      t("text-ellipsis", [["text-overflow", "ellipsis"]]),
      t("text-clip", [["text-overflow", "clip"]]),
      t("hyphens-none", [
        ["-webkit-hyphens", "none"],
        ["hyphens", "none"],
      ]),
      t("hyphens-manual", [
        ["-webkit-hyphens", "manual"],
        ["hyphens", "manual"],
      ]),
      t("hyphens-auto", [
        ["-webkit-hyphens", "auto"],
        ["hyphens", "auto"],
      ]),
      t("whitespace-normal", [["white-space", "normal"]]),
      t("whitespace-nowrap", [["white-space", "nowrap"]]),
      t("whitespace-pre", [["white-space", "pre"]]),
      t("whitespace-pre-line", [["white-space", "pre-line"]]),
      t("whitespace-pre-wrap", [["white-space", "pre-wrap"]]),
      t("whitespace-break-spaces", [["white-space", "break-spaces"]]),
      t("text-wrap", [["text-wrap", "wrap"]]),
      t("text-nowrap", [["text-wrap", "nowrap"]]),
      t("text-balance", [["text-wrap", "balance"]]),
      t("text-pretty", [["text-wrap", "pretty"]]),
      t("break-normal", [
        ["overflow-wrap", "normal"],
        ["word-break", "normal"],
      ]),
      t("break-words", [["overflow-wrap", "break-word"]]),
      t("break-all", [["word-break", "break-all"]]),
      t("break-keep", [["word-break", "keep-all"]]),
      t("wrap-anywhere", [["overflow-wrap", "anywhere"]]),
      t("wrap-break-word", [["overflow-wrap", "break-word"]]),
      t("wrap-normal", [["overflow-wrap", "normal"]]);
    for (let [l, f] of [
      ["rounded", ["border-radius"]],
      ["rounded-s", ["border-start-start-radius", "border-end-start-radius"]],
      ["rounded-e", ["border-start-end-radius", "border-end-end-radius"]],
      ["rounded-t", ["border-top-left-radius", "border-top-right-radius"]],
      ["rounded-r", ["border-top-right-radius", "border-bottom-right-radius"]],
      [
        "rounded-b",
        ["border-bottom-right-radius", "border-bottom-left-radius"],
      ],
      ["rounded-l", ["border-top-left-radius", "border-bottom-left-radius"]],
      ["rounded-ss", ["border-start-start-radius"]],
      ["rounded-se", ["border-start-end-radius"]],
      ["rounded-ee", ["border-end-end-radius"]],
      ["rounded-es", ["border-end-start-radius"]],
      ["rounded-tl", ["border-top-left-radius"]],
      ["rounded-tr", ["border-top-right-radius"]],
      ["rounded-br", ["border-bottom-right-radius"]],
      ["rounded-bl", ["border-bottom-left-radius"]],
    ])
      o(l, {
        themeKeys: ["--radius"],
        handle: (h) => f.map((A) => n(A, h)),
        staticValues: {
          none: f.map((h) => n(h, "0")),
          full: f.map((h) => n(h, "calc(infinity * 1px)")),
        },
      });
    t("border-solid", [
      ["--tw-border-style", "solid"],
      ["border-style", "solid"],
    ]),
      t("border-dashed", [
        ["--tw-border-style", "dashed"],
        ["border-style", "dashed"],
      ]),
      t("border-dotted", [
        ["--tw-border-style", "dotted"],
        ["border-style", "dotted"],
      ]),
      t("border-double", [
        ["--tw-border-style", "double"],
        ["border-style", "double"],
      ]),
      t("border-hidden", [
        ["--tw-border-style", "hidden"],
        ["border-style", "hidden"],
      ]),
      t("border-none", [
        ["--tw-border-style", "none"],
        ["border-style", "none"],
      ]);
    {
      let f = function (h, A) {
        r.functional(h, (b) => {
          if (!b.value) {
            if (b.modifier) return;
            let $ = e.get(["--default-border-width"]) ?? "1px",
              P = A.width($);
            return P ? [l(), ...P] : void 0;
          }
          if (b.value.kind === "arbitrary") {
            let $ = b.value.value;
            switch (
              b.value.dataType ??
              Z($, ["color", "line-width", "length"])
            ) {
              case "line-width":
              case "length": {
                if (b.modifier) return;
                let N = A.width($);
                return N ? [l(), ...N] : void 0;
              }
              default:
                return (
                  ($ = X($, b.modifier, e)), $ === null ? void 0 : A.color($)
                );
            }
          }
          {
            let $ = te(b, e, ["--border-color", "--color"]);
            if ($) return A.color($);
          }
          {
            if (b.modifier) return;
            let $ = e.resolve(b.value.value, ["--border-width"]);
            if ($) {
              let P = A.width($);
              return P ? [l(), ...P] : void 0;
            }
            if (T(b.value.value)) {
              let P = A.width(`${b.value.value}px`);
              return P ? [l(), ...P] : void 0;
            }
          }
        }),
          i(h, () => [
            {
              values: ["current", "inherit", "transparent"],
              valueThemeKeys: ["--border-color", "--color"],
              modifiers: Array.from({ length: 21 }, (b, $) => `${$ * 5}`),
              hasDefaultValue: !0,
            },
            {
              values: ["0", "2", "4", "8"],
              valueThemeKeys: ["--border-width"],
            },
          ]);
      };
      var H = f;
      let l = () => j([S("--tw-border-style", "solid")]);
      f("border", {
        width: (h) => [
          n("border-style", "var(--tw-border-style)"),
          n("border-width", h),
        ],
        color: (h) => [n("border-color", h)],
      }),
        f("border-x", {
          width: (h) => [
            n("border-inline-style", "var(--tw-border-style)"),
            n("border-inline-width", h),
          ],
          color: (h) => [n("border-inline-color", h)],
        }),
        f("border-y", {
          width: (h) => [
            n("border-block-style", "var(--tw-border-style)"),
            n("border-block-width", h),
          ],
          color: (h) => [n("border-block-color", h)],
        }),
        f("border-s", {
          width: (h) => [
            n("border-inline-start-style", "var(--tw-border-style)"),
            n("border-inline-start-width", h),
          ],
          color: (h) => [n("border-inline-start-color", h)],
        }),
        f("border-e", {
          width: (h) => [
            n("border-inline-end-style", "var(--tw-border-style)"),
            n("border-inline-end-width", h),
          ],
          color: (h) => [n("border-inline-end-color", h)],
        }),
        f("border-t", {
          width: (h) => [
            n("border-top-style", "var(--tw-border-style)"),
            n("border-top-width", h),
          ],
          color: (h) => [n("border-top-color", h)],
        }),
        f("border-r", {
          width: (h) => [
            n("border-right-style", "var(--tw-border-style)"),
            n("border-right-width", h),
          ],
          color: (h) => [n("border-right-color", h)],
        }),
        f("border-b", {
          width: (h) => [
            n("border-bottom-style", "var(--tw-border-style)"),
            n("border-bottom-width", h),
          ],
          color: (h) => [n("border-bottom-color", h)],
        }),
        f("border-l", {
          width: (h) => [
            n("border-left-style", "var(--tw-border-style)"),
            n("border-left-width", h),
          ],
          color: (h) => [n("border-left-color", h)],
        }),
        o("divide-x", {
          defaultValue: e.get(["--default-border-width"]) ?? "1px",
          themeKeys: ["--divide-width", "--border-width"],
          handleBareValue: ({ value: h }) => (T(h) ? `${h}px` : null),
          handle: (h) => [
            j([S("--tw-divide-x-reverse", "0")]),
            W(":where(& > :not(:last-child))", [
              n("--tw-sort", "divide-x-width"),
              l(),
              n("--tw-divide-x-reverse", "0"),
              n("border-inline-style", "var(--tw-border-style)"),
              n(
                "border-inline-start-width",
                `calc(${h} * var(--tw-divide-x-reverse))`
              ),
              n(
                "border-inline-end-width",
                `calc(${h} * calc(1 - var(--tw-divide-x-reverse)))`
              ),
            ]),
          ],
        }),
        o("divide-y", {
          defaultValue: e.get(["--default-border-width"]) ?? "1px",
          themeKeys: ["--divide-width", "--border-width"],
          handleBareValue: ({ value: h }) => (T(h) ? `${h}px` : null),
          handle: (h) => [
            j([S("--tw-divide-y-reverse", "0")]),
            W(":where(& > :not(:last-child))", [
              n("--tw-sort", "divide-y-width"),
              l(),
              n("--tw-divide-y-reverse", "0"),
              n("border-bottom-style", "var(--tw-border-style)"),
              n("border-top-style", "var(--tw-border-style)"),
              n("border-top-width", `calc(${h} * var(--tw-divide-y-reverse))`),
              n(
                "border-bottom-width",
                `calc(${h} * calc(1 - var(--tw-divide-y-reverse)))`
              ),
            ]),
          ],
        }),
        i("divide-x", () => [
          {
            values: ["0", "2", "4", "8"],
            valueThemeKeys: ["--divide-width", "--border-width"],
            hasDefaultValue: !0,
          },
        ]),
        i("divide-y", () => [
          {
            values: ["0", "2", "4", "8"],
            valueThemeKeys: ["--divide-width", "--border-width"],
            hasDefaultValue: !0,
          },
        ]),
        t("divide-x-reverse", [
          () => j([S("--tw-divide-x-reverse", "0")]),
          () =>
            W(":where(& > :not(:last-child))", [
              n("--tw-divide-x-reverse", "1"),
            ]),
        ]),
        t("divide-y-reverse", [
          () => j([S("--tw-divide-y-reverse", "0")]),
          () =>
            W(":where(& > :not(:last-child))", [
              n("--tw-divide-y-reverse", "1"),
            ]),
        ]);
      for (let h of ["solid", "dashed", "dotted", "double", "none"])
        t(`divide-${h}`, [
          () =>
            W(":where(& > :not(:last-child))", [
              n("--tw-sort", "divide-style"),
              n("--tw-border-style", h),
              n("border-style", h),
            ]),
        ]);
    }
    t("bg-auto", [["background-size", "auto"]]),
      t("bg-cover", [["background-size", "cover"]]),
      t("bg-contain", [["background-size", "contain"]]),
      o("bg-size", {
        handle(l) {
          if (l) return [n("background-size", l)];
        },
      }),
      t("bg-fixed", [["background-attachment", "fixed"]]),
      t("bg-local", [["background-attachment", "local"]]),
      t("bg-scroll", [["background-attachment", "scroll"]]),
      t("bg-top", [["background-position", "top"]]),
      t("bg-top-left", [["background-position", "left top"]]),
      t("bg-top-right", [["background-position", "right top"]]),
      t("bg-bottom", [["background-position", "bottom"]]),
      t("bg-bottom-left", [["background-position", "left bottom"]]),
      t("bg-bottom-right", [["background-position", "right bottom"]]),
      t("bg-left", [["background-position", "left"]]),
      t("bg-right", [["background-position", "right"]]),
      t("bg-center", [["background-position", "center"]]),
      o("bg-position", {
        handle(l) {
          if (l) return [n("background-position", l)];
        },
      }),
      t("bg-repeat", [["background-repeat", "repeat"]]),
      t("bg-no-repeat", [["background-repeat", "no-repeat"]]),
      t("bg-repeat-x", [["background-repeat", "repeat-x"]]),
      t("bg-repeat-y", [["background-repeat", "repeat-y"]]),
      t("bg-repeat-round", [["background-repeat", "round"]]),
      t("bg-repeat-space", [["background-repeat", "space"]]),
      t("bg-none", [["background-image", "none"]]);
    {
      let h = function ($) {
          let P = "in oklab";
          if ($?.kind === "named")
            switch ($.value) {
              case "longer":
              case "shorter":
              case "increasing":
              case "decreasing":
                P = `in oklch ${$.value} hue`;
                break;
              default:
                P = `in ${$.value}`;
            }
          else $?.kind === "arbitrary" && (P = $.value);
          return P;
        },
        A = function ({ negative: $ }) {
          return (P) => {
            if (!P.value) return;
            if (P.value.kind === "arbitrary") {
              if (P.modifier) return;
              let I = P.value.value;
              switch (P.value.dataType ?? Z(I, ["angle"])) {
                case "angle":
                  return (
                    (I = $ ? `calc(${I} * -1)` : `${I}`),
                    [
                      n("--tw-gradient-position", I),
                      n(
                        "background-image",
                        `linear-gradient(var(--tw-gradient-stops,${I}))`
                      ),
                    ]
                  );
                default:
                  return $
                    ? void 0
                    : [
                        n("--tw-gradient-position", I),
                        n(
                          "background-image",
                          `linear-gradient(var(--tw-gradient-stops,${I}))`
                        ),
                      ];
              }
            }
            let N = P.value.value;
            if (!$ && f.has(N)) N = f.get(N);
            else if (T(N)) N = $ ? `calc(${N}deg * -1)` : `${N}deg`;
            else return;
            let E = h(P.modifier);
            return [
              n("--tw-gradient-position", `${N}`),
              Y(
                "@supports (background-image: linear-gradient(in lab, red, red))",
                [n("--tw-gradient-position", `${N} ${E}`)]
              ),
              n(
                "background-image",
                "linear-gradient(var(--tw-gradient-stops))"
              ),
            ];
          };
        },
        b = function ({ negative: $ }) {
          return (P) => {
            if (P.value?.kind === "arbitrary") {
              if (P.modifier) return;
              let I = P.value.value;
              return [
                n("--tw-gradient-position", I),
                n(
                  "background-image",
                  `conic-gradient(var(--tw-gradient-stops,${I}))`
                ),
              ];
            }
            let N = h(P.modifier);
            if (!P.value)
              return [
                n("--tw-gradient-position", N),
                n(
                  "background-image",
                  "conic-gradient(var(--tw-gradient-stops))"
                ),
              ];
            let E = P.value.value;
            if (T(E))
              return (
                (E = $ ? `calc(${E}deg * -1)` : `${E}deg`),
                [
                  n("--tw-gradient-position", `from ${E} ${N}`),
                  n(
                    "background-image",
                    "conic-gradient(var(--tw-gradient-stops))"
                  ),
                ]
              );
          };
        };
      var O = h,
        L = A,
        q = b;
      let l = [
          "oklab",
          "oklch",
          "srgb",
          "hsl",
          "longer",
          "shorter",
          "increasing",
          "decreasing",
        ],
        f = new Map([
          ["to-t", "to top"],
          ["to-tr", "to top right"],
          ["to-r", "to right"],
          ["to-br", "to bottom right"],
          ["to-b", "to bottom"],
          ["to-bl", "to bottom left"],
          ["to-l", "to left"],
          ["to-tl", "to top left"],
        ]);
      r.functional("-bg-linear", A({ negative: !0 })),
        r.functional("bg-linear", A({ negative: !1 })),
        i("bg-linear", () => [
          { values: [...f.keys()], modifiers: l },
          {
            values: [
              "0",
              "30",
              "60",
              "90",
              "120",
              "150",
              "180",
              "210",
              "240",
              "270",
              "300",
              "330",
            ],
            supportsNegative: !0,
            modifiers: l,
          },
        ]),
        r.functional("-bg-conic", b({ negative: !0 })),
        r.functional("bg-conic", b({ negative: !1 })),
        i("bg-conic", () => [
          { hasDefaultValue: !0, modifiers: l },
          {
            values: [
              "0",
              "30",
              "60",
              "90",
              "120",
              "150",
              "180",
              "210",
              "240",
              "270",
              "300",
              "330",
            ],
            supportsNegative: !0,
            modifiers: l,
          },
        ]),
        r.functional("bg-radial", ($) => {
          if (!$.value) {
            let P = h($.modifier);
            return [
              n("--tw-gradient-position", P),
              n(
                "background-image",
                "radial-gradient(var(--tw-gradient-stops))"
              ),
            ];
          }
          if ($.value.kind === "arbitrary") {
            if ($.modifier) return;
            let P = $.value.value;
            return [
              n("--tw-gradient-position", P),
              n(
                "background-image",
                `radial-gradient(var(--tw-gradient-stops,${P}))`
              ),
            ];
          }
        }),
        i("bg-radial", () => [{ hasDefaultValue: !0, modifiers: l }]);
    }
    r.functional("bg", (l) => {
      if (l.value) {
        if (l.value.kind === "arbitrary") {
          let f = l.value.value;
          switch (
            l.value.dataType ??
            Z(f, [
              "image",
              "color",
              "percentage",
              "position",
              "bg-size",
              "length",
              "url",
            ])
          ) {
            case "percentage":
            case "position":
              return l.modifier ? void 0 : [n("background-position", f)];
            case "bg-size":
            case "length":
            case "size":
              return l.modifier ? void 0 : [n("background-size", f)];
            case "image":
            case "url":
              return l.modifier ? void 0 : [n("background-image", f)];
            default:
              return (
                (f = X(f, l.modifier, e)),
                f === null ? void 0 : [n("background-color", f)]
              );
          }
        }
        {
          let f = te(l, e, ["--background-color", "--color"]);
          if (f) return [n("background-color", f)];
        }
        {
          if (l.modifier) return;
          let f = e.resolve(l.value.value, ["--background-image"]);
          if (f) return [n("background-image", f)];
        }
      }
    }),
      i("bg", () => [
        {
          values: ["current", "inherit", "transparent"],
          valueThemeKeys: ["--background-color", "--color"],
          modifiers: Array.from({ length: 21 }, (l, f) => `${f * 5}`),
        },
        { values: [], valueThemeKeys: ["--background-image"] },
      ]);
    let k = () =>
      j([
        S("--tw-gradient-position"),
        S("--tw-gradient-from", "#0000", "<color>"),
        S("--tw-gradient-via", "#0000", "<color>"),
        S("--tw-gradient-to", "#0000", "<color>"),
        S("--tw-gradient-stops"),
        S("--tw-gradient-via-stops"),
        S("--tw-gradient-from-position", "0%", "<length-percentage>"),
        S("--tw-gradient-via-position", "50%", "<length-percentage>"),
        S("--tw-gradient-to-position", "100%", "<length-percentage>"),
      ]);
    function w(l, f) {
      r.functional(l, (h) => {
        if (h.value) {
          if (h.value.kind === "arbitrary") {
            let A = h.value.value;
            switch (
              h.value.dataType ??
              Z(A, ["color", "length", "percentage"])
            ) {
              case "length":
              case "percentage":
                return h.modifier ? void 0 : f.position(A);
              default:
                return (
                  (A = X(A, h.modifier, e)), A === null ? void 0 : f.color(A)
                );
            }
          }
          {
            let A = te(h, e, ["--background-color", "--color"]);
            if (A) return f.color(A);
          }
          {
            if (h.modifier) return;
            let A = e.resolve(h.value.value, [
              "--gradient-color-stop-positions",
            ]);
            if (A) return f.position(A);
            if (
              h.value.value[h.value.value.length - 1] === "%" &&
              T(h.value.value.slice(0, -1))
            )
              return f.position(h.value.value);
          }
        }
      }),
        i(l, () => [
          {
            values: ["current", "inherit", "transparent"],
            valueThemeKeys: ["--background-color", "--color"],
            modifiers: Array.from({ length: 21 }, (h, A) => `${A * 5}`),
          },
          {
            values: Array.from({ length: 21 }, (h, A) => `${A * 5}%`),
            valueThemeKeys: ["--gradient-color-stop-positions"],
          },
        ]);
    }
    w("from", {
      color: (l) => [
        k(),
        n("--tw-sort", "--tw-gradient-from"),
        n("--tw-gradient-from", l),
        n(
          "--tw-gradient-stops",
          "var(--tw-gradient-via-stops, var(--tw-gradient-position), var(--tw-gradient-from) var(--tw-gradient-from-position), var(--tw-gradient-to) var(--tw-gradient-to-position))"
        ),
      ],
      position: (l) => [k(), n("--tw-gradient-from-position", l)],
    }),
      t("via-none", [["--tw-gradient-via-stops", "initial"]]),
      w("via", {
        color: (l) => [
          k(),
          n("--tw-sort", "--tw-gradient-via"),
          n("--tw-gradient-via", l),
          n(
            "--tw-gradient-via-stops",
            "var(--tw-gradient-position), var(--tw-gradient-from) var(--tw-gradient-from-position), var(--tw-gradient-via) var(--tw-gradient-via-position), var(--tw-gradient-to) var(--tw-gradient-to-position)"
          ),
          n("--tw-gradient-stops", "var(--tw-gradient-via-stops)"),
        ],
        position: (l) => [k(), n("--tw-gradient-via-position", l)],
      }),
      w("to", {
        color: (l) => [
          k(),
          n("--tw-sort", "--tw-gradient-to"),
          n("--tw-gradient-to", l),
          n(
            "--tw-gradient-stops",
            "var(--tw-gradient-via-stops, var(--tw-gradient-position), var(--tw-gradient-from) var(--tw-gradient-from-position), var(--tw-gradient-to) var(--tw-gradient-to-position))"
          ),
        ],
        position: (l) => [k(), n("--tw-gradient-to-position", l)],
      }),
      t("mask-none", [["mask-image", "none"]]),
      r.functional("mask", (l) => {
        if (!l.value || l.modifier || l.value.kind !== "arbitrary") return;
        let f = l.value.value;
        switch (
          l.value.dataType ??
          Z(f, ["image", "percentage", "position", "bg-size", "length", "url"])
        ) {
          case "percentage":
          case "position":
            return l.modifier ? void 0 : [n("mask-position", f)];
          case "bg-size":
          case "length":
          case "size":
            return [n("mask-size", f)];
          case "image":
          case "url":
          default:
            return [n("mask-image", f)];
        }
      }),
      t("mask-add", [["mask-composite", "add"]]),
      t("mask-subtract", [["mask-composite", "subtract"]]),
      t("mask-intersect", [["mask-composite", "intersect"]]),
      t("mask-exclude", [["mask-composite", "exclude"]]),
      t("mask-alpha", [["mask-mode", "alpha"]]),
      t("mask-luminance", [["mask-mode", "luminance"]]),
      t("mask-match", [["mask-mode", "match-source"]]),
      t("mask-type-alpha", [["mask-type", "alpha"]]),
      t("mask-type-luminance", [["mask-type", "luminance"]]),
      t("mask-auto", [["mask-size", "auto"]]),
      t("mask-cover", [["mask-size", "cover"]]),
      t("mask-contain", [["mask-size", "contain"]]),
      o("mask-size", {
        handle(l) {
          if (l) return [n("mask-size", l)];
        },
      }),
      t("mask-top", [["mask-position", "top"]]),
      t("mask-top-left", [["mask-position", "left top"]]),
      t("mask-top-right", [["mask-position", "right top"]]),
      t("mask-bottom", [["mask-position", "bottom"]]),
      t("mask-bottom-left", [["mask-position", "left bottom"]]),
      t("mask-bottom-right", [["mask-position", "right bottom"]]),
      t("mask-left", [["mask-position", "left"]]),
      t("mask-right", [["mask-position", "right"]]),
      t("mask-center", [["mask-position", "center"]]),
      o("mask-position", {
        handle(l) {
          if (l) return [n("mask-position", l)];
        },
      }),
      t("mask-repeat", [["mask-repeat", "repeat"]]),
      t("mask-no-repeat", [["mask-repeat", "no-repeat"]]),
      t("mask-repeat-x", [["mask-repeat", "repeat-x"]]),
      t("mask-repeat-y", [["mask-repeat", "repeat-y"]]),
      t("mask-repeat-round", [["mask-repeat", "round"]]),
      t("mask-repeat-space", [["mask-repeat", "space"]]),
      t("mask-clip-border", [["mask-clip", "border-box"]]),
      t("mask-clip-padding", [["mask-clip", "padding-box"]]),
      t("mask-clip-content", [["mask-clip", "content-box"]]),
      t("mask-clip-fill", [["mask-clip", "fill-box"]]),
      t("mask-clip-stroke", [["mask-clip", "stroke-box"]]),
      t("mask-clip-view", [["mask-clip", "view-box"]]),
      t("mask-no-clip", [["mask-clip", "no-clip"]]),
      t("mask-origin-border", [["mask-origin", "border-box"]]),
      t("mask-origin-padding", [["mask-origin", "padding-box"]]),
      t("mask-origin-content", [["mask-origin", "content-box"]]),
      t("mask-origin-fill", [["mask-origin", "fill-box"]]),
      t("mask-origin-stroke", [["mask-origin", "stroke-box"]]),
      t("mask-origin-view", [["mask-origin", "view-box"]]);
    let x = () =>
      j([
        S("--tw-mask-linear", "linear-gradient(#fff, #fff)"),
        S("--tw-mask-radial", "linear-gradient(#fff, #fff)"),
        S("--tw-mask-conic", "linear-gradient(#fff, #fff)"),
      ]);
    function V(l, f) {
      r.functional(l, (h) => {
        if (h.value) {
          if (h.value.kind === "arbitrary") {
            let A = h.value.value;
            switch (
              h.value.dataType ??
              Z(A, ["length", "percentage", "color"])
            ) {
              case "color":
                return (
                  (A = X(A, h.modifier, e)), A === null ? void 0 : f.color(A)
                );
              case "percentage":
                return h.modifier || !T(A.slice(0, -1))
                  ? void 0
                  : f.position(A);
              default:
                return h.modifier ? void 0 : f.position(A);
            }
          }
          {
            let A = te(h, e, ["--background-color", "--color"]);
            if (A) return f.color(A);
          }
          {
            if (h.modifier) return;
            let A = Z(h.value.value, ["number", "percentage"]);
            if (!A) return;
            switch (A) {
              case "number": {
                let b = e.resolve(null, ["--spacing"]);
                return !b || !xe(h.value.value)
                  ? void 0
                  : f.position(`calc(${b} * ${h.value.value})`);
              }
              case "percentage":
                return T(h.value.value.slice(0, -1))
                  ? f.position(h.value.value)
                  : void 0;
              default:
                return;
            }
          }
        }
      }),
        i(l, () => [
          {
            values: ["current", "inherit", "transparent"],
            valueThemeKeys: ["--background-color", "--color"],
            modifiers: Array.from({ length: 21 }, (h, A) => `${A * 5}`),
          },
          {
            values: Array.from({ length: 21 }, (h, A) => `${A * 5}%`),
            valueThemeKeys: ["--gradient-color-stop-positions"],
          },
        ]),
        i(l, () => [
          { values: Array.from({ length: 21 }, (h, A) => `${A * 5}%`) },
          { values: e.get(["--spacing"]) ? lt : [] },
          {
            values: ["current", "inherit", "transparent"],
            valueThemeKeys: ["--background-color", "--color"],
            modifiers: Array.from({ length: 21 }, (h, A) => `${A * 5}`),
          },
        ]);
    }
    let C = () =>
      j([
        S("--tw-mask-left", "linear-gradient(#fff, #fff)"),
        S("--tw-mask-right", "linear-gradient(#fff, #fff)"),
        S("--tw-mask-bottom", "linear-gradient(#fff, #fff)"),
        S("--tw-mask-top", "linear-gradient(#fff, #fff)"),
      ]);
    function y(l, f, h) {
      V(l, {
        color(A) {
          let b = [
            x(),
            C(),
            n(
              "mask-image",
              "var(--tw-mask-linear), var(--tw-mask-radial), var(--tw-mask-conic)"
            ),
            n("mask-composite", "intersect"),
            n(
              "--tw-mask-linear",
              "var(--tw-mask-left), var(--tw-mask-right), var(--tw-mask-bottom), var(--tw-mask-top)"
            ),
          ];
          for (let $ of ["top", "right", "bottom", "left"])
            h[$] &&
              (b.push(
                n(
                  `--tw-mask-${$}`,
                  `linear-gradient(to ${$}, var(--tw-mask-${$}-from-color) var(--tw-mask-${$}-from-position), var(--tw-mask-${$}-to-color) var(--tw-mask-${$}-to-position))`
                )
              ),
              b.push(
                j([
                  S(`--tw-mask-${$}-from-position`, "0%"),
                  S(`--tw-mask-${$}-to-position`, "100%"),
                  S(`--tw-mask-${$}-from-color`, "black"),
                  S(`--tw-mask-${$}-to-color`, "transparent"),
                ])
              ),
              b.push(n(`--tw-mask-${$}-${f}-color`, A)));
          return b;
        },
        position(A) {
          let b = [
            x(),
            C(),
            n(
              "mask-image",
              "var(--tw-mask-linear), var(--tw-mask-radial), var(--tw-mask-conic)"
            ),
            n("mask-composite", "intersect"),
            n(
              "--tw-mask-linear",
              "var(--tw-mask-left), var(--tw-mask-right), var(--tw-mask-bottom), var(--tw-mask-top)"
            ),
          ];
          for (let $ of ["top", "right", "bottom", "left"])
            h[$] &&
              (b.push(
                n(
                  `--tw-mask-${$}`,
                  `linear-gradient(to ${$}, var(--tw-mask-${$}-from-color) var(--tw-mask-${$}-from-position), var(--tw-mask-${$}-to-color) var(--tw-mask-${$}-to-position))`
                )
              ),
              b.push(
                j([
                  S(`--tw-mask-${$}-from-position`, "0%"),
                  S(`--tw-mask-${$}-to-position`, "100%"),
                  S(`--tw-mask-${$}-from-color`, "black"),
                  S(`--tw-mask-${$}-to-color`, "transparent"),
                ])
              ),
              b.push(n(`--tw-mask-${$}-${f}-position`, A)));
          return b;
        },
      });
    }
    y("mask-x-from", "from", { top: !1, right: !0, bottom: !1, left: !0 }),
      y("mask-x-to", "to", { top: !1, right: !0, bottom: !1, left: !0 }),
      y("mask-y-from", "from", { top: !0, right: !1, bottom: !0, left: !1 }),
      y("mask-y-to", "to", { top: !0, right: !1, bottom: !0, left: !1 }),
      y("mask-t-from", "from", { top: !0, right: !1, bottom: !1, left: !1 }),
      y("mask-t-to", "to", { top: !0, right: !1, bottom: !1, left: !1 }),
      y("mask-r-from", "from", { top: !1, right: !0, bottom: !1, left: !1 }),
      y("mask-r-to", "to", { top: !1, right: !0, bottom: !1, left: !1 }),
      y("mask-b-from", "from", { top: !1, right: !1, bottom: !0, left: !1 }),
      y("mask-b-to", "to", { top: !1, right: !1, bottom: !0, left: !1 }),
      y("mask-l-from", "from", { top: !1, right: !1, bottom: !1, left: !0 }),
      y("mask-l-to", "to", { top: !1, right: !1, bottom: !1, left: !0 });
    let _ = () =>
      j([
        S("--tw-mask-linear-position", "0deg"),
        S("--tw-mask-linear-from-position", "0%"),
        S("--tw-mask-linear-to-position", "100%"),
        S("--tw-mask-linear-from-color", "black"),
        S("--tw-mask-linear-to-color", "transparent"),
      ]);
    o("mask-linear", {
      defaultValue: null,
      supportsNegative: !0,
      supportsFractions: !1,
      handleBareValue(l) {
        return T(l.value) ? `calc(1deg * ${l.value})` : null;
      },
      handleNegativeBareValue(l) {
        return T(l.value) ? `calc(1deg * -${l.value})` : null;
      },
      handle: (l) => [
        x(),
        _(),
        n(
          "mask-image",
          "var(--tw-mask-linear), var(--tw-mask-radial), var(--tw-mask-conic)"
        ),
        n("mask-composite", "intersect"),
        n(
          "--tw-mask-linear",
          "linear-gradient(var(--tw-mask-linear-stops, var(--tw-mask-linear-position)))"
        ),
        n("--tw-mask-linear-position", l),
      ],
    }),
      i("mask-linear", () => [
        {
          supportsNegative: !0,
          values: ["0", "1", "2", "3", "6", "12", "45", "90", "180"],
        },
      ]),
      V("mask-linear-from", {
        color: (l) => [
          x(),
          _(),
          n(
            "mask-image",
            "var(--tw-mask-linear), var(--tw-mask-radial), var(--tw-mask-conic)"
          ),
          n("mask-composite", "intersect"),
          n(
            "--tw-mask-linear-stops",
            "var(--tw-mask-linear-position), var(--tw-mask-linear-from-color) var(--tw-mask-linear-from-position), var(--tw-mask-linear-to-color) var(--tw-mask-linear-to-position)"
          ),
          n("--tw-mask-linear", "linear-gradient(var(--tw-mask-linear-stops))"),
          n("--tw-mask-linear-from-color", l),
        ],
        position: (l) => [
          x(),
          _(),
          n(
            "mask-image",
            "var(--tw-mask-linear), var(--tw-mask-radial), var(--tw-mask-conic)"
          ),
          n("mask-composite", "intersect"),
          n(
            "--tw-mask-linear-stops",
            "var(--tw-mask-linear-position), var(--tw-mask-linear-from-color) var(--tw-mask-linear-from-position), var(--tw-mask-linear-to-color) var(--tw-mask-linear-to-position)"
          ),
          n("--tw-mask-linear", "linear-gradient(var(--tw-mask-linear-stops))"),
          n("--tw-mask-linear-from-position", l),
        ],
      }),
      V("mask-linear-to", {
        color: (l) => [
          x(),
          _(),
          n(
            "mask-image",
            "var(--tw-mask-linear), var(--tw-mask-radial), var(--tw-mask-conic)"
          ),
          n("mask-composite", "intersect"),
          n(
            "--tw-mask-linear-stops",
            "var(--tw-mask-linear-position), var(--tw-mask-linear-from-color) var(--tw-mask-linear-from-position), var(--tw-mask-linear-to-color) var(--tw-mask-linear-to-position)"
          ),
          n("--tw-mask-linear", "linear-gradient(var(--tw-mask-linear-stops))"),
          n("--tw-mask-linear-to-color", l),
        ],
        position: (l) => [
          x(),
          _(),
          n(
            "mask-image",
            "var(--tw-mask-linear), var(--tw-mask-radial), var(--tw-mask-conic)"
          ),
          n("mask-composite", "intersect"),
          n(
            "--tw-mask-linear-stops",
            "var(--tw-mask-linear-position), var(--tw-mask-linear-from-color) var(--tw-mask-linear-from-position), var(--tw-mask-linear-to-color) var(--tw-mask-linear-to-position)"
          ),
          n("--tw-mask-linear", "linear-gradient(var(--tw-mask-linear-stops))"),
          n("--tw-mask-linear-to-position", l),
        ],
      });
    let R = () =>
      j([
        S("--tw-mask-radial-from-position", "0%"),
        S("--tw-mask-radial-to-position", "100%"),
        S("--tw-mask-radial-from-color", "black"),
        S("--tw-mask-radial-to-color", "transparent"),
        S("--tw-mask-radial-shape", "ellipse"),
        S("--tw-mask-radial-size", "farthest-corner"),
        S("--tw-mask-radial-position", "center"),
      ]);
    t("mask-circle", [["--tw-mask-radial-shape", "circle"]]),
      t("mask-ellipse", [["--tw-mask-radial-shape", "ellipse"]]),
      t("mask-radial-closest-side", [
        ["--tw-mask-radial-size", "closest-side"],
      ]),
      t("mask-radial-farthest-side", [
        ["--tw-mask-radial-size", "farthest-side"],
      ]),
      t("mask-radial-closest-corner", [
        ["--tw-mask-radial-size", "closest-corner"],
      ]),
      t("mask-radial-farthest-corner", [
        ["--tw-mask-radial-size", "farthest-corner"],
      ]),
      t("mask-radial-at-top", [["--tw-mask-radial-position", "top"]]),
      t("mask-radial-at-top-left", [["--tw-mask-radial-position", "top left"]]),
      t("mask-radial-at-top-right", [
        ["--tw-mask-radial-position", "top right"],
      ]),
      t("mask-radial-at-bottom", [["--tw-mask-radial-position", "bottom"]]),
      t("mask-radial-at-bottom-left", [
        ["--tw-mask-radial-position", "bottom left"],
      ]),
      t("mask-radial-at-bottom-right", [
        ["--tw-mask-radial-position", "bottom right"],
      ]),
      t("mask-radial-at-left", [["--tw-mask-radial-position", "left"]]),
      t("mask-radial-at-right", [["--tw-mask-radial-position", "right"]]),
      t("mask-radial-at-center", [["--tw-mask-radial-position", "center"]]),
      o("mask-radial-at", {
        defaultValue: null,
        supportsNegative: !1,
        supportsFractions: !1,
        handle: (l) => [n("--tw-mask-radial-position", l)],
      }),
      o("mask-radial", {
        defaultValue: null,
        supportsNegative: !1,
        supportsFractions: !1,
        handle: (l) => [
          x(),
          R(),
          n(
            "mask-image",
            "var(--tw-mask-linear), var(--tw-mask-radial), var(--tw-mask-conic)"
          ),
          n("mask-composite", "intersect"),
          n(
            "--tw-mask-radial",
            "radial-gradient(var(--tw-mask-radial-stops, var(--tw-mask-radial-size)))"
          ),
          n("--tw-mask-radial-size", l),
        ],
      }),
      V("mask-radial-from", {
        color: (l) => [
          x(),
          R(),
          n(
            "mask-image",
            "var(--tw-mask-linear), var(--tw-mask-radial), var(--tw-mask-conic)"
          ),
          n("mask-composite", "intersect"),
          n(
            "--tw-mask-radial-stops",
            "var(--tw-mask-radial-shape) var(--tw-mask-radial-size) at var(--tw-mask-radial-position), var(--tw-mask-radial-from-color) var(--tw-mask-radial-from-position), var(--tw-mask-radial-to-color) var(--tw-mask-radial-to-position)"
          ),
          n("--tw-mask-radial", "radial-gradient(var(--tw-mask-radial-stops))"),
          n("--tw-mask-radial-from-color", l),
        ],
        position: (l) => [
          x(),
          R(),
          n(
            "mask-image",
            "var(--tw-mask-linear), var(--tw-mask-radial), var(--tw-mask-conic)"
          ),
          n("mask-composite", "intersect"),
          n(
            "--tw-mask-radial-stops",
            "var(--tw-mask-radial-shape) var(--tw-mask-radial-size) at var(--tw-mask-radial-position), var(--tw-mask-radial-from-color) var(--tw-mask-radial-from-position), var(--tw-mask-radial-to-color) var(--tw-mask-radial-to-position)"
          ),
          n("--tw-mask-radial", "radial-gradient(var(--tw-mask-radial-stops))"),
          n("--tw-mask-radial-from-position", l),
        ],
      }),
      V("mask-radial-to", {
        color: (l) => [
          x(),
          R(),
          n(
            "mask-image",
            "var(--tw-mask-linear), var(--tw-mask-radial), var(--tw-mask-conic)"
          ),
          n("mask-composite", "intersect"),
          n(
            "--tw-mask-radial-stops",
            "var(--tw-mask-radial-shape) var(--tw-mask-radial-size) at var(--tw-mask-radial-position), var(--tw-mask-radial-from-color) var(--tw-mask-radial-from-position), var(--tw-mask-radial-to-color) var(--tw-mask-radial-to-position)"
          ),
          n("--tw-mask-radial", "radial-gradient(var(--tw-mask-radial-stops))"),
          n("--tw-mask-radial-to-color", l),
        ],
        position: (l) => [
          x(),
          R(),
          n(
            "mask-image",
            "var(--tw-mask-linear), var(--tw-mask-radial), var(--tw-mask-conic)"
          ),
          n("mask-composite", "intersect"),
          n(
            "--tw-mask-radial-stops",
            "var(--tw-mask-radial-shape) var(--tw-mask-radial-size) at var(--tw-mask-radial-position), var(--tw-mask-radial-from-color) var(--tw-mask-radial-from-position), var(--tw-mask-radial-to-color) var(--tw-mask-radial-to-position)"
          ),
          n("--tw-mask-radial", "radial-gradient(var(--tw-mask-radial-stops))"),
          n("--tw-mask-radial-to-position", l),
        ],
      });
    let D = () =>
      j([
        S("--tw-mask-conic-position", "0deg"),
        S("--tw-mask-conic-from-position", "0%"),
        S("--tw-mask-conic-to-position", "100%"),
        S("--tw-mask-conic-from-color", "black"),
        S("--tw-mask-conic-to-color", "transparent"),
      ]);
    o("mask-conic", {
      defaultValue: null,
      supportsNegative: !0,
      supportsFractions: !1,
      handleBareValue(l) {
        return T(l.value) ? `calc(1deg * ${l.value})` : null;
      },
      handleNegativeBareValue(l) {
        return T(l.value) ? `calc(1deg * -${l.value})` : null;
      },
      handle: (l) => [
        x(),
        D(),
        n(
          "mask-image",
          "var(--tw-mask-linear), var(--tw-mask-radial), var(--tw-mask-conic)"
        ),
        n("mask-composite", "intersect"),
        n(
          "--tw-mask-conic",
          "conic-gradient(var(--tw-mask-conic-stops, var(--tw-mask-conic-position)))"
        ),
        n("--tw-mask-conic-position", l),
      ],
    }),
      i("mask-conic", () => [
        {
          supportsNegative: !0,
          values: ["0", "1", "2", "3", "6", "12", "45", "90", "180"],
        },
      ]),
      V("mask-conic-from", {
        color: (l) => [
          x(),
          D(),
          n(
            "mask-image",
            "var(--tw-mask-linear), var(--tw-mask-radial), var(--tw-mask-conic)"
          ),
          n("mask-composite", "intersect"),
          n(
            "--tw-mask-conic-stops",
            "from var(--tw-mask-conic-position), var(--tw-mask-conic-from-color) var(--tw-mask-conic-from-position), var(--tw-mask-conic-to-color) var(--tw-mask-conic-to-position)"
          ),
          n("--tw-mask-conic", "conic-gradient(var(--tw-mask-conic-stops))"),
          n("--tw-mask-conic-from-color", l),
        ],
        position: (l) => [
          x(),
          D(),
          n(
            "mask-image",
            "var(--tw-mask-linear), var(--tw-mask-radial), var(--tw-mask-conic)"
          ),
          n("mask-composite", "intersect"),
          n(
            "--tw-mask-conic-stops",
            "from var(--tw-mask-conic-position), var(--tw-mask-conic-from-color) var(--tw-mask-conic-from-position), var(--tw-mask-conic-to-color) var(--tw-mask-conic-to-position)"
          ),
          n("--tw-mask-conic", "conic-gradient(var(--tw-mask-conic-stops))"),
          n("--tw-mask-conic-from-position", l),
        ],
      }),
      V("mask-conic-to", {
        color: (l) => [
          x(),
          D(),
          n(
            "mask-image",
            "var(--tw-mask-linear), var(--tw-mask-radial), var(--tw-mask-conic)"
          ),
          n("mask-composite", "intersect"),
          n(
            "--tw-mask-conic-stops",
            "from var(--tw-mask-conic-position), var(--tw-mask-conic-from-color) var(--tw-mask-conic-from-position), var(--tw-mask-conic-to-color) var(--tw-mask-conic-to-position)"
          ),
          n("--tw-mask-conic", "conic-gradient(var(--tw-mask-conic-stops))"),
          n("--tw-mask-conic-to-color", l),
        ],
        position: (l) => [
          x(),
          D(),
          n(
            "mask-image",
            "var(--tw-mask-linear), var(--tw-mask-radial), var(--tw-mask-conic)"
          ),
          n("mask-composite", "intersect"),
          n(
            "--tw-mask-conic-stops",
            "from var(--tw-mask-conic-position), var(--tw-mask-conic-from-color) var(--tw-mask-conic-from-position), var(--tw-mask-conic-to-color) var(--tw-mask-conic-to-position)"
          ),
          n("--tw-mask-conic", "conic-gradient(var(--tw-mask-conic-stops))"),
          n("--tw-mask-conic-to-position", l),
        ],
      }),
      t("box-decoration-slice", [
        ["-webkit-box-decoration-break", "slice"],
        ["box-decoration-break", "slice"],
      ]),
      t("box-decoration-clone", [
        ["-webkit-box-decoration-break", "clone"],
        ["box-decoration-break", "clone"],
      ]),
      t("bg-clip-text", [["background-clip", "text"]]),
      t("bg-clip-border", [["background-clip", "border-box"]]),
      t("bg-clip-padding", [["background-clip", "padding-box"]]),
      t("bg-clip-content", [["background-clip", "content-box"]]),
      t("bg-origin-border", [["background-origin", "border-box"]]),
      t("bg-origin-padding", [["background-origin", "padding-box"]]),
      t("bg-origin-content", [["background-origin", "content-box"]]);
    for (let l of [
      "normal",
      "multiply",
      "screen",
      "overlay",
      "darken",
      "lighten",
      "color-dodge",
      "color-burn",
      "hard-light",
      "soft-light",
      "difference",
      "exclusion",
      "hue",
      "saturation",
      "color",
      "luminosity",
    ])
      t(`bg-blend-${l}`, [["background-blend-mode", l]]),
        t(`mix-blend-${l}`, [["mix-blend-mode", l]]);
    t("mix-blend-plus-darker", [["mix-blend-mode", "plus-darker"]]),
      t("mix-blend-plus-lighter", [["mix-blend-mode", "plus-lighter"]]),
      t("fill-none", [["fill", "none"]]),
      r.functional("fill", (l) => {
        if (!l.value) return;
        if (l.value.kind === "arbitrary") {
          let h = X(l.value.value, l.modifier, e);
          return h === null ? void 0 : [n("fill", h)];
        }
        let f = te(l, e, ["--fill", "--color"]);
        if (f) return [n("fill", f)];
      }),
      i("fill", () => [
        {
          values: ["current", "inherit", "transparent"],
          valueThemeKeys: ["--fill", "--color"],
          modifiers: Array.from({ length: 21 }, (l, f) => `${f * 5}`),
        },
      ]),
      t("stroke-none", [["stroke", "none"]]),
      r.functional("stroke", (l) => {
        if (l.value) {
          if (l.value.kind === "arbitrary") {
            let f = l.value.value;
            switch (
              l.value.dataType ??
              Z(f, ["color", "number", "length", "percentage"])
            ) {
              case "number":
              case "length":
              case "percentage":
                return l.modifier ? void 0 : [n("stroke-width", f)];
              default:
                return (
                  (f = X(l.value.value, l.modifier, e)),
                  f === null ? void 0 : [n("stroke", f)]
                );
            }
          }
          {
            let f = te(l, e, ["--stroke", "--color"]);
            if (f) return [n("stroke", f)];
          }
          {
            let f = e.resolve(l.value.value, ["--stroke-width"]);
            if (f) return [n("stroke-width", f)];
            if (T(l.value.value)) return [n("stroke-width", l.value.value)];
          }
        }
      }),
      i("stroke", () => [
        {
          values: ["current", "inherit", "transparent"],
          valueThemeKeys: ["--stroke", "--color"],
          modifiers: Array.from({ length: 21 }, (l, f) => `${f * 5}`),
        },
        { values: ["0", "1", "2", "3"], valueThemeKeys: ["--stroke-width"] },
      ]),
      t("object-contain", [["object-fit", "contain"]]),
      t("object-cover", [["object-fit", "cover"]]),
      t("object-fill", [["object-fit", "fill"]]),
      t("object-none", [["object-fit", "none"]]),
      t("object-scale-down", [["object-fit", "scale-down"]]),
      o("object", {
        themeKeys: ["--object-position"],
        handle: (l) => [n("object-position", l)],
        staticValues: {
          top: [n("object-position", "top")],
          "top-left": [n("object-position", "left top")],
          "top-right": [n("object-position", "right top")],
          bottom: [n("object-position", "bottom")],
          "bottom-left": [n("object-position", "left bottom")],
          "bottom-right": [n("object-position", "right bottom")],
          left: [n("object-position", "left")],
          right: [n("object-position", "right")],
          center: [n("object-position", "center")],
        },
      });
    for (let [l, f] of [
      ["p", "padding"],
      ["px", "padding-inline"],
      ["py", "padding-block"],
      ["ps", "padding-inline-start"],
      ["pe", "padding-inline-end"],
      ["pt", "padding-top"],
      ["pr", "padding-right"],
      ["pb", "padding-bottom"],
      ["pl", "padding-left"],
    ])
      a(l, ["--padding", "--spacing"], (h) => [n(f, h)]);
    t("text-left", [["text-align", "left"]]),
      t("text-center", [["text-align", "center"]]),
      t("text-right", [["text-align", "right"]]),
      t("text-justify", [["text-align", "justify"]]),
      t("text-start", [["text-align", "start"]]),
      t("text-end", [["text-align", "end"]]),
      a(
        "indent",
        ["--text-indent", "--spacing"],
        (l) => [n("text-indent", l)],
        { supportsNegative: !0 }
      ),
      t("align-baseline", [["vertical-align", "baseline"]]),
      t("align-top", [["vertical-align", "top"]]),
      t("align-middle", [["vertical-align", "middle"]]),
      t("align-bottom", [["vertical-align", "bottom"]]),
      t("align-text-top", [["vertical-align", "text-top"]]),
      t("align-text-bottom", [["vertical-align", "text-bottom"]]),
      t("align-sub", [["vertical-align", "sub"]]),
      t("align-super", [["vertical-align", "super"]]),
      o("align", { themeKeys: [], handle: (l) => [n("vertical-align", l)] }),
      r.functional("font", (l) => {
        if (!(!l.value || l.modifier)) {
          if (l.value.kind === "arbitrary") {
            let f = l.value.value;
            switch (
              l.value.dataType ??
              Z(f, ["number", "generic-name", "family-name"])
            ) {
              case "generic-name":
              case "family-name":
                return [n("font-family", f)];
              default:
                return [
                  j([S("--tw-font-weight")]),
                  n("--tw-font-weight", f),
                  n("font-weight", f),
                ];
            }
          }
          {
            let f = e.resolveWith(
              l.value.value,
              ["--font"],
              ["--font-feature-settings", "--font-variation-settings"]
            );
            if (f) {
              let [h, A = {}] = f;
              return [
                n("font-family", h),
                n("font-feature-settings", A["--font-feature-settings"]),
                n("font-variation-settings", A["--font-variation-settings"]),
              ];
            }
          }
          {
            let f = e.resolve(l.value.value, ["--font-weight"]);
            if (f)
              return [
                j([S("--tw-font-weight")]),
                n("--tw-font-weight", f),
                n("font-weight", f),
              ];
          }
        }
      }),
      i("font", () => [
        { values: [], valueThemeKeys: ["--font"] },
        { values: [], valueThemeKeys: ["--font-weight"] },
      ]),
      t("uppercase", [["text-transform", "uppercase"]]),
      t("lowercase", [["text-transform", "lowercase"]]),
      t("capitalize", [["text-transform", "capitalize"]]),
      t("normal-case", [["text-transform", "none"]]),
      t("italic", [["font-style", "italic"]]),
      t("not-italic", [["font-style", "normal"]]),
      t("underline", [["text-decoration-line", "underline"]]),
      t("overline", [["text-decoration-line", "overline"]]),
      t("line-through", [["text-decoration-line", "line-through"]]),
      t("no-underline", [["text-decoration-line", "none"]]),
      t("font-stretch-normal", [["font-stretch", "normal"]]),
      t("font-stretch-ultra-condensed", [["font-stretch", "ultra-condensed"]]),
      t("font-stretch-extra-condensed", [["font-stretch", "extra-condensed"]]),
      t("font-stretch-condensed", [["font-stretch", "condensed"]]),
      t("font-stretch-semi-condensed", [["font-stretch", "semi-condensed"]]),
      t("font-stretch-semi-expanded", [["font-stretch", "semi-expanded"]]),
      t("font-stretch-expanded", [["font-stretch", "expanded"]]),
      t("font-stretch-extra-expanded", [["font-stretch", "extra-expanded"]]),
      t("font-stretch-ultra-expanded", [["font-stretch", "ultra-expanded"]]),
      o("font-stretch", {
        handleBareValue: ({ value: l }) => {
          if (!l.endsWith("%")) return null;
          let f = Number(l.slice(0, -1));
          return !T(f) || Number.isNaN(f) || f < 50 || f > 200 ? null : l;
        },
        handle: (l) => [n("font-stretch", l)],
      }),
      i("font-stretch", () => [
        {
          values: [
            "50%",
            "75%",
            "90%",
            "95%",
            "100%",
            "105%",
            "110%",
            "125%",
            "150%",
            "200%",
          ],
        },
      ]),
      s("placeholder", {
        themeKeys: ["--background-color", "--color"],
        handle: (l) => [
          W("&::placeholder", [
            n("--tw-sort", "placeholder-color"),
            n("color", l),
          ]),
        ],
      }),
      t("decoration-solid", [["text-decoration-style", "solid"]]),
      t("decoration-double", [["text-decoration-style", "double"]]),
      t("decoration-dotted", [["text-decoration-style", "dotted"]]),
      t("decoration-dashed", [["text-decoration-style", "dashed"]]),
      t("decoration-wavy", [["text-decoration-style", "wavy"]]),
      t("decoration-auto", [["text-decoration-thickness", "auto"]]),
      t("decoration-from-font", [["text-decoration-thickness", "from-font"]]),
      r.functional("decoration", (l) => {
        if (l.value) {
          if (l.value.kind === "arbitrary") {
            let f = l.value.value;
            switch (
              l.value.dataType ??
              Z(f, ["color", "length", "percentage"])
            ) {
              case "length":
              case "percentage":
                return l.modifier
                  ? void 0
                  : [n("text-decoration-thickness", f)];
              default:
                return (
                  (f = X(f, l.modifier, e)),
                  f === null ? void 0 : [n("text-decoration-color", f)]
                );
            }
          }
          {
            let f = e.resolve(l.value.value, ["--text-decoration-thickness"]);
            if (f)
              return l.modifier ? void 0 : [n("text-decoration-thickness", f)];
            if (T(l.value.value))
              return l.modifier
                ? void 0
                : [n("text-decoration-thickness", `${l.value.value}px`)];
          }
          {
            let f = te(l, e, ["--text-decoration-color", "--color"]);
            if (f) return [n("text-decoration-color", f)];
          }
        }
      }),
      i("decoration", () => [
        {
          values: ["current", "inherit", "transparent"],
          valueThemeKeys: ["--text-decoration-color", "--color"],
          modifiers: Array.from({ length: 21 }, (l, f) => `${f * 5}`),
        },
        {
          values: ["0", "1", "2"],
          valueThemeKeys: ["--text-decoration-thickness"],
        },
      ]),
      o("animate", {
        themeKeys: ["--animate"],
        handle: (l) => [n("animation", l)],
        staticValues: { none: [n("animation", "none")] },
      });
    {
      let l = [
          "var(--tw-blur,)",
          "var(--tw-brightness,)",
          "var(--tw-contrast,)",
          "var(--tw-grayscale,)",
          "var(--tw-hue-rotate,)",
          "var(--tw-invert,)",
          "var(--tw-saturate,)",
          "var(--tw-sepia,)",
          "var(--tw-drop-shadow,)",
        ].join(" "),
        f = [
          "var(--tw-backdrop-blur,)",
          "var(--tw-backdrop-brightness,)",
          "var(--tw-backdrop-contrast,)",
          "var(--tw-backdrop-grayscale,)",
          "var(--tw-backdrop-hue-rotate,)",
          "var(--tw-backdrop-invert,)",
          "var(--tw-backdrop-opacity,)",
          "var(--tw-backdrop-saturate,)",
          "var(--tw-backdrop-sepia,)",
        ].join(" "),
        h = () =>
          j([
            S("--tw-blur"),
            S("--tw-brightness"),
            S("--tw-contrast"),
            S("--tw-grayscale"),
            S("--tw-hue-rotate"),
            S("--tw-invert"),
            S("--tw-opacity"),
            S("--tw-saturate"),
            S("--tw-sepia"),
            S("--tw-drop-shadow"),
            S("--tw-drop-shadow-color"),
            S("--tw-drop-shadow-alpha", "100%", "<percentage>"),
            S("--tw-drop-shadow-size"),
          ]),
        A = () =>
          j([
            S("--tw-backdrop-blur"),
            S("--tw-backdrop-brightness"),
            S("--tw-backdrop-contrast"),
            S("--tw-backdrop-grayscale"),
            S("--tw-backdrop-hue-rotate"),
            S("--tw-backdrop-invert"),
            S("--tw-backdrop-opacity"),
            S("--tw-backdrop-saturate"),
            S("--tw-backdrop-sepia"),
          ]);
      r.functional("filter", (b) => {
        if (!b.modifier) {
          if (b.value === null) return [h(), n("filter", l)];
          if (b.value.kind === "arbitrary") return [n("filter", b.value.value)];
          switch (b.value.value) {
            case "none":
              return [n("filter", "none")];
          }
        }
      }),
        r.functional("backdrop-filter", (b) => {
          if (!b.modifier) {
            if (b.value === null)
              return [
                A(),
                n("-webkit-backdrop-filter", f),
                n("backdrop-filter", f),
              ];
            if (b.value.kind === "arbitrary")
              return [
                n("-webkit-backdrop-filter", b.value.value),
                n("backdrop-filter", b.value.value),
              ];
            switch (b.value.value) {
              case "none":
                return [
                  n("-webkit-backdrop-filter", "none"),
                  n("backdrop-filter", "none"),
                ];
            }
          }
        }),
        o("blur", {
          themeKeys: ["--blur"],
          handle: (b) => [h(), n("--tw-blur", `blur(${b})`), n("filter", l)],
          staticValues: { none: [h(), n("--tw-blur", " "), n("filter", l)] },
        }),
        o("backdrop-blur", {
          themeKeys: ["--backdrop-blur", "--blur"],
          handle: (b) => [
            A(),
            n("--tw-backdrop-blur", `blur(${b})`),
            n("-webkit-backdrop-filter", f),
            n("backdrop-filter", f),
          ],
          staticValues: {
            none: [
              A(),
              n("--tw-backdrop-blur", " "),
              n("-webkit-backdrop-filter", f),
              n("backdrop-filter", f),
            ],
          },
        }),
        o("brightness", {
          themeKeys: ["--brightness"],
          handleBareValue: ({ value: b }) => (T(b) ? `${b}%` : null),
          handle: (b) => [
            h(),
            n("--tw-brightness", `brightness(${b})`),
            n("filter", l),
          ],
        }),
        o("backdrop-brightness", {
          themeKeys: ["--backdrop-brightness", "--brightness"],
          handleBareValue: ({ value: b }) => (T(b) ? `${b}%` : null),
          handle: (b) => [
            A(),
            n("--tw-backdrop-brightness", `brightness(${b})`),
            n("-webkit-backdrop-filter", f),
            n("backdrop-filter", f),
          ],
        }),
        i("brightness", () => [
          {
            values: [
              "0",
              "50",
              "75",
              "90",
              "95",
              "100",
              "105",
              "110",
              "125",
              "150",
              "200",
            ],
            valueThemeKeys: ["--brightness"],
          },
        ]),
        i("backdrop-brightness", () => [
          {
            values: [
              "0",
              "50",
              "75",
              "90",
              "95",
              "100",
              "105",
              "110",
              "125",
              "150",
              "200",
            ],
            valueThemeKeys: ["--backdrop-brightness", "--brightness"],
          },
        ]),
        o("contrast", {
          themeKeys: ["--contrast"],
          handleBareValue: ({ value: b }) => (T(b) ? `${b}%` : null),
          handle: (b) => [
            h(),
            n("--tw-contrast", `contrast(${b})`),
            n("filter", l),
          ],
        }),
        o("backdrop-contrast", {
          themeKeys: ["--backdrop-contrast", "--contrast"],
          handleBareValue: ({ value: b }) => (T(b) ? `${b}%` : null),
          handle: (b) => [
            A(),
            n("--tw-backdrop-contrast", `contrast(${b})`),
            n("-webkit-backdrop-filter", f),
            n("backdrop-filter", f),
          ],
        }),
        i("contrast", () => [
          {
            values: ["0", "50", "75", "100", "125", "150", "200"],
            valueThemeKeys: ["--contrast"],
          },
        ]),
        i("backdrop-contrast", () => [
          {
            values: ["0", "50", "75", "100", "125", "150", "200"],
            valueThemeKeys: ["--backdrop-contrast", "--contrast"],
          },
        ]),
        o("grayscale", {
          themeKeys: ["--grayscale"],
          handleBareValue: ({ value: b }) => (T(b) ? `${b}%` : null),
          defaultValue: "100%",
          handle: (b) => [
            h(),
            n("--tw-grayscale", `grayscale(${b})`),
            n("filter", l),
          ],
        }),
        o("backdrop-grayscale", {
          themeKeys: ["--backdrop-grayscale", "--grayscale"],
          handleBareValue: ({ value: b }) => (T(b) ? `${b}%` : null),
          defaultValue: "100%",
          handle: (b) => [
            A(),
            n("--tw-backdrop-grayscale", `grayscale(${b})`),
            n("-webkit-backdrop-filter", f),
            n("backdrop-filter", f),
          ],
        }),
        i("grayscale", () => [
          {
            values: ["0", "25", "50", "75", "100"],
            valueThemeKeys: ["--grayscale"],
            hasDefaultValue: !0,
          },
        ]),
        i("backdrop-grayscale", () => [
          {
            values: ["0", "25", "50", "75", "100"],
            valueThemeKeys: ["--backdrop-grayscale", "--grayscale"],
            hasDefaultValue: !0,
          },
        ]),
        o("hue-rotate", {
          supportsNegative: !0,
          themeKeys: ["--hue-rotate"],
          handleBareValue: ({ value: b }) => (T(b) ? `${b}deg` : null),
          handle: (b) => [
            h(),
            n("--tw-hue-rotate", `hue-rotate(${b})`),
            n("filter", l),
          ],
        }),
        o("backdrop-hue-rotate", {
          supportsNegative: !0,
          themeKeys: ["--backdrop-hue-rotate", "--hue-rotate"],
          handleBareValue: ({ value: b }) => (T(b) ? `${b}deg` : null),
          handle: (b) => [
            A(),
            n("--tw-backdrop-hue-rotate", `hue-rotate(${b})`),
            n("-webkit-backdrop-filter", f),
            n("backdrop-filter", f),
          ],
        }),
        i("hue-rotate", () => [
          {
            values: ["0", "15", "30", "60", "90", "180"],
            valueThemeKeys: ["--hue-rotate"],
          },
        ]),
        i("backdrop-hue-rotate", () => [
          {
            values: ["0", "15", "30", "60", "90", "180"],
            valueThemeKeys: ["--backdrop-hue-rotate", "--hue-rotate"],
          },
        ]),
        o("invert", {
          themeKeys: ["--invert"],
          handleBareValue: ({ value: b }) => (T(b) ? `${b}%` : null),
          defaultValue: "100%",
          handle: (b) => [
            h(),
            n("--tw-invert", `invert(${b})`),
            n("filter", l),
          ],
        }),
        o("backdrop-invert", {
          themeKeys: ["--backdrop-invert", "--invert"],
          handleBareValue: ({ value: b }) => (T(b) ? `${b}%` : null),
          defaultValue: "100%",
          handle: (b) => [
            A(),
            n("--tw-backdrop-invert", `invert(${b})`),
            n("-webkit-backdrop-filter", f),
            n("backdrop-filter", f),
          ],
        }),
        i("invert", () => [
          {
            values: ["0", "25", "50", "75", "100"],
            valueThemeKeys: ["--invert"],
            hasDefaultValue: !0,
          },
        ]),
        i("backdrop-invert", () => [
          {
            values: ["0", "25", "50", "75", "100"],
            valueThemeKeys: ["--backdrop-invert", "--invert"],
            hasDefaultValue: !0,
          },
        ]),
        o("saturate", {
          themeKeys: ["--saturate"],
          handleBareValue: ({ value: b }) => (T(b) ? `${b}%` : null),
          handle: (b) => [
            h(),
            n("--tw-saturate", `saturate(${b})`),
            n("filter", l),
          ],
        }),
        o("backdrop-saturate", {
          themeKeys: ["--backdrop-saturate", "--saturate"],
          handleBareValue: ({ value: b }) => (T(b) ? `${b}%` : null),
          handle: (b) => [
            A(),
            n("--tw-backdrop-saturate", `saturate(${b})`),
            n("-webkit-backdrop-filter", f),
            n("backdrop-filter", f),
          ],
        }),
        i("saturate", () => [
          {
            values: ["0", "50", "100", "150", "200"],
            valueThemeKeys: ["--saturate"],
          },
        ]),
        i("backdrop-saturate", () => [
          {
            values: ["0", "50", "100", "150", "200"],
            valueThemeKeys: ["--backdrop-saturate", "--saturate"],
          },
        ]),
        o("sepia", {
          themeKeys: ["--sepia"],
          handleBareValue: ({ value: b }) => (T(b) ? `${b}%` : null),
          defaultValue: "100%",
          handle: (b) => [h(), n("--tw-sepia", `sepia(${b})`), n("filter", l)],
        }),
        o("backdrop-sepia", {
          themeKeys: ["--backdrop-sepia", "--sepia"],
          handleBareValue: ({ value: b }) => (T(b) ? `${b}%` : null),
          defaultValue: "100%",
          handle: (b) => [
            A(),
            n("--tw-backdrop-sepia", `sepia(${b})`),
            n("-webkit-backdrop-filter", f),
            n("backdrop-filter", f),
          ],
        }),
        i("sepia", () => [
          {
            values: ["0", "50", "100"],
            valueThemeKeys: ["--sepia"],
            hasDefaultValue: !0,
          },
        ]),
        i("backdrop-sepia", () => [
          {
            values: ["0", "50", "100"],
            valueThemeKeys: ["--backdrop-sepia", "--sepia"],
            hasDefaultValue: !0,
          },
        ]),
        t("drop-shadow-none", [h, ["--tw-drop-shadow", " "], ["filter", l]]),
        r.functional("drop-shadow", (b) => {
          let $;
          if (
            (b.modifier &&
              (b.modifier.kind === "arbitrary"
                ? ($ = b.modifier.value)
                : T(b.modifier.value) && ($ = `${b.modifier.value}%`)),
            !b.value)
          ) {
            let P = e.get(["--drop-shadow"]),
              N = e.resolve(null, ["--drop-shadow"]);
            return P === null || N === null
              ? void 0
              : [
                  h(),
                  n("--tw-drop-shadow-alpha", $),
                  ...nt(
                    "--tw-drop-shadow-size",
                    P,
                    $,
                    (E) => `var(--tw-drop-shadow-color, ${E})`
                  ),
                  n(
                    "--tw-drop-shadow",
                    z(N, ",")
                      .map((E) => `drop-shadow(${E})`)
                      .join(" ")
                  ),
                  n("filter", l),
                ];
          }
          if (b.value.kind === "arbitrary") {
            let P = b.value.value;
            switch (b.value.dataType ?? Z(P, ["color"])) {
              case "color":
                return (
                  (P = X(P, b.modifier, e)),
                  P === null
                    ? void 0
                    : [
                        h(),
                        n(
                          "--tw-drop-shadow-color",
                          Q(P, "var(--tw-drop-shadow-alpha)")
                        ),
                        n("--tw-drop-shadow", "var(--tw-drop-shadow-size)"),
                      ]
                );
              default:
                return b.modifier && !$
                  ? void 0
                  : [
                      h(),
                      n("--tw-drop-shadow-alpha", $),
                      ...nt(
                        "--tw-drop-shadow-size",
                        P,
                        $,
                        (E) => `var(--tw-drop-shadow-color, ${E})`
                      ),
                      n("--tw-drop-shadow", "var(--tw-drop-shadow-size)"),
                      n("filter", l),
                    ];
            }
          }
          {
            let P = e.get([`--drop-shadow-${b.value.value}`]),
              N = e.resolve(b.value.value, ["--drop-shadow"]);
            if (P && N)
              return b.modifier && !$
                ? void 0
                : $
                ? [
                    h(),
                    n("--tw-drop-shadow-alpha", $),
                    ...nt(
                      "--tw-drop-shadow-size",
                      P,
                      $,
                      (E) => `var(--tw-drop-shadow-color, ${E})`
                    ),
                    n("--tw-drop-shadow", "var(--tw-drop-shadow-size)"),
                    n("filter", l),
                  ]
                : [
                    h(),
                    n("--tw-drop-shadow-alpha", $),
                    ...nt(
                      "--tw-drop-shadow-size",
                      P,
                      $,
                      (E) => `var(--tw-drop-shadow-color, ${E})`
                    ),
                    n(
                      "--tw-drop-shadow",
                      z(N, ",")
                        .map((E) => `drop-shadow(${E})`)
                        .join(" ")
                    ),
                    n("filter", l),
                  ];
          }
          {
            let P = te(b, e, ["--drop-shadow-color", "--color"]);
            if (P)
              return P === "inherit"
                ? [
                    h(),
                    n("--tw-drop-shadow-color", "inherit"),
                    n("--tw-drop-shadow", "var(--tw-drop-shadow-size)"),
                  ]
                : [
                    h(),
                    n(
                      "--tw-drop-shadow-color",
                      Q(P, "var(--tw-drop-shadow-alpha)")
                    ),
                    n("--tw-drop-shadow", "var(--tw-drop-shadow-size)"),
                  ];
          }
        }),
        i("drop-shadow", () => [
          {
            values: ["current", "inherit", "transparent"],
            valueThemeKeys: ["--drop-shadow-color", "--color"],
            modifiers: Array.from({ length: 21 }, (b, $) => `${$ * 5}`),
          },
          { valueThemeKeys: ["--drop-shadow"] },
        ]),
        o("backdrop-opacity", {
          themeKeys: ["--backdrop-opacity", "--opacity"],
          handleBareValue: ({ value: b }) => (ot(b) ? `${b}%` : null),
          handle: (b) => [
            A(),
            n("--tw-backdrop-opacity", `opacity(${b})`),
            n("-webkit-backdrop-filter", f),
            n("backdrop-filter", f),
          ],
        }),
        i("backdrop-opacity", () => [
          {
            values: Array.from({ length: 21 }, (b, $) => `${$ * 5}`),
            valueThemeKeys: ["--backdrop-opacity", "--opacity"],
          },
        ]);
    }
    {
      let l = `var(--tw-ease, ${
          e.resolve(null, ["--default-transition-timing-function"]) ?? "ease"
        })`,
        f = `var(--tw-duration, ${
          e.resolve(null, ["--default-transition-duration"]) ?? "0s"
        })`;
      o("transition", {
        defaultValue:
          "color, background-color, border-color, outline-color, text-decoration-color, fill, stroke, --tw-gradient-from, --tw-gradient-via, --tw-gradient-to, opacity, box-shadow, transform, translate, scale, rotate, filter, -webkit-backdrop-filter, backdrop-filter, display, content-visibility, overlay, pointer-events",
        themeKeys: ["--transition-property"],
        handle: (h) => [
          n("transition-property", h),
          n("transition-timing-function", l),
          n("transition-duration", f),
        ],
        staticValues: {
          none: [n("transition-property", "none")],
          all: [
            n("transition-property", "all"),
            n("transition-timing-function", l),
            n("transition-duration", f),
          ],
          colors: [
            n(
              "transition-property",
              "color, background-color, border-color, outline-color, text-decoration-color, fill, stroke, --tw-gradient-from, --tw-gradient-via, --tw-gradient-to"
            ),
            n("transition-timing-function", l),
            n("transition-duration", f),
          ],
          opacity: [
            n("transition-property", "opacity"),
            n("transition-timing-function", l),
            n("transition-duration", f),
          ],
          shadow: [
            n("transition-property", "box-shadow"),
            n("transition-timing-function", l),
            n("transition-duration", f),
          ],
          transform: [
            n("transition-property", "transform, translate, scale, rotate"),
            n("transition-timing-function", l),
            n("transition-duration", f),
          ],
        },
      }),
        t("transition-discrete", [["transition-behavior", "allow-discrete"]]),
        t("transition-normal", [["transition-behavior", "normal"]]),
        o("delay", {
          handleBareValue: ({ value: h }) => (T(h) ? `${h}ms` : null),
          themeKeys: ["--transition-delay"],
          handle: (h) => [n("transition-delay", h)],
        });
      {
        let h = () => j([S("--tw-duration")]);
        t("duration-initial", [h, ["--tw-duration", "initial"]]),
          r.functional("duration", (A) => {
            if (A.modifier || !A.value) return;
            let b = null;
            if (
              (A.value.kind === "arbitrary"
                ? (b = A.value.value)
                : ((b = e.resolve(A.value.fraction ?? A.value.value, [
                    "--transition-duration",
                  ])),
                  b === null && T(A.value.value) && (b = `${A.value.value}ms`)),
              b !== null)
            )
              return [h(), n("--tw-duration", b), n("transition-duration", b)];
          });
      }
      i("delay", () => [
        {
          values: ["75", "100", "150", "200", "300", "500", "700", "1000"],
          valueThemeKeys: ["--transition-delay"],
        },
      ]),
        i("duration", () => [
          {
            values: ["75", "100", "150", "200", "300", "500", "700", "1000"],
            valueThemeKeys: ["--transition-duration"],
          },
        ]);
    }
    {
      let l = () => j([S("--tw-ease")]);
      o("ease", {
        themeKeys: ["--ease"],
        handle: (f) => [
          l(),
          n("--tw-ease", f),
          n("transition-timing-function", f),
        ],
        staticValues: {
          initial: [l(), n("--tw-ease", "initial")],
          linear: [
            l(),
            n("--tw-ease", "linear"),
            n("transition-timing-function", "linear"),
          ],
        },
      });
    }
    t("will-change-auto", [["will-change", "auto"]]),
      t("will-change-scroll", [["will-change", "scroll-position"]]),
      t("will-change-contents", [["will-change", "contents"]]),
      t("will-change-transform", [["will-change", "transform"]]),
      o("will-change", { themeKeys: [], handle: (l) => [n("will-change", l)] }),
      t("content-none", [
        ["--tw-content", "none"],
        ["content", "none"],
      ]),
      o("content", {
        themeKeys: [],
        handle: (l) => [
          j([S("--tw-content", '""')]),
          n("--tw-content", l),
          n("content", "var(--tw-content)"),
        ],
      });
    {
      let l =
          "var(--tw-contain-size,) var(--tw-contain-layout,) var(--tw-contain-paint,) var(--tw-contain-style,)",
        f = () =>
          j([
            S("--tw-contain-size"),
            S("--tw-contain-layout"),
            S("--tw-contain-paint"),
            S("--tw-contain-style"),
          ]);
      t("contain-none", [["contain", "none"]]),
        t("contain-content", [["contain", "content"]]),
        t("contain-strict", [["contain", "strict"]]),
        t("contain-size", [f, ["--tw-contain-size", "size"], ["contain", l]]),
        t("contain-inline-size", [
          f,
          ["--tw-contain-size", "inline-size"],
          ["contain", l],
        ]),
        t("contain-layout", [
          f,
          ["--tw-contain-layout", "layout"],
          ["contain", l],
        ]),
        t("contain-paint", [
          f,
          ["--tw-contain-paint", "paint"],
          ["contain", l],
        ]),
        t("contain-style", [
          f,
          ["--tw-contain-style", "style"],
          ["contain", l],
        ]),
        o("contain", { themeKeys: [], handle: (h) => [n("contain", h)] });
    }
    t("forced-color-adjust-none", [["forced-color-adjust", "none"]]),
      t("forced-color-adjust-auto", [["forced-color-adjust", "auto"]]),
      a(
        "leading",
        ["--leading", "--spacing"],
        (l) => [
          j([S("--tw-leading")]),
          n("--tw-leading", l),
          n("line-height", l),
        ],
        {
          staticValues: {
            none: [
              j([S("--tw-leading")]),
              n("--tw-leading", "1"),
              n("line-height", "1"),
            ],
          },
        }
      ),
      o("tracking", {
        supportsNegative: !0,
        themeKeys: ["--tracking"],
        handle: (l) => [
          j([S("--tw-tracking")]),
          n("--tw-tracking", l),
          n("letter-spacing", l),
        ],
      }),
      t("antialiased", [
        ["-webkit-font-smoothing", "antialiased"],
        ["-moz-osx-font-smoothing", "grayscale"],
      ]),
      t("subpixel-antialiased", [
        ["-webkit-font-smoothing", "auto"],
        ["-moz-osx-font-smoothing", "auto"],
      ]);
    {
      let l =
          "var(--tw-ordinal,) var(--tw-slashed-zero,) var(--tw-numeric-figure,) var(--tw-numeric-spacing,) var(--tw-numeric-fraction,)",
        f = () =>
          j([
            S("--tw-ordinal"),
            S("--tw-slashed-zero"),
            S("--tw-numeric-figure"),
            S("--tw-numeric-spacing"),
            S("--tw-numeric-fraction"),
          ]);
      t("normal-nums", [["font-variant-numeric", "normal"]]),
        t("ordinal", [
          f,
          ["--tw-ordinal", "ordinal"],
          ["font-variant-numeric", l],
        ]),
        t("slashed-zero", [
          f,
          ["--tw-slashed-zero", "slashed-zero"],
          ["font-variant-numeric", l],
        ]),
        t("lining-nums", [
          f,
          ["--tw-numeric-figure", "lining-nums"],
          ["font-variant-numeric", l],
        ]),
        t("oldstyle-nums", [
          f,
          ["--tw-numeric-figure", "oldstyle-nums"],
          ["font-variant-numeric", l],
        ]),
        t("proportional-nums", [
          f,
          ["--tw-numeric-spacing", "proportional-nums"],
          ["font-variant-numeric", l],
        ]),
        t("tabular-nums", [
          f,
          ["--tw-numeric-spacing", "tabular-nums"],
          ["font-variant-numeric", l],
        ]),
        t("diagonal-fractions", [
          f,
          ["--tw-numeric-fraction", "diagonal-fractions"],
          ["font-variant-numeric", l],
        ]),
        t("stacked-fractions", [
          f,
          ["--tw-numeric-fraction", "stacked-fractions"],
          ["font-variant-numeric", l],
        ]);
    }
    {
      let l = () => j([S("--tw-outline-style", "solid")]);
      r.static("outline-hidden", () => [
        n("--tw-outline-style", "none"),
        n("outline-style", "none"),
        F("@media", "(forced-colors: active)", [
          n("outline", "2px solid transparent"),
          n("outline-offset", "2px"),
        ]),
      ]),
        t("outline-none", [
          ["--tw-outline-style", "none"],
          ["outline-style", "none"],
        ]),
        t("outline-solid", [
          ["--tw-outline-style", "solid"],
          ["outline-style", "solid"],
        ]),
        t("outline-dashed", [
          ["--tw-outline-style", "dashed"],
          ["outline-style", "dashed"],
        ]),
        t("outline-dotted", [
          ["--tw-outline-style", "dotted"],
          ["outline-style", "dotted"],
        ]),
        t("outline-double", [
          ["--tw-outline-style", "double"],
          ["outline-style", "double"],
        ]),
        r.functional("outline", (f) => {
          if (f.value === null) {
            if (f.modifier) return;
            let h = e.get(["--default-outline-width"]) ?? "1px";
            return [
              l(),
              n("outline-style", "var(--tw-outline-style)"),
              n("outline-width", h),
            ];
          }
          if (f.value.kind === "arbitrary") {
            let h = f.value.value;
            switch (
              f.value.dataType ??
              Z(h, ["color", "length", "number", "percentage"])
            ) {
              case "length":
              case "number":
              case "percentage":
                return f.modifier
                  ? void 0
                  : [
                      l(),
                      n("outline-style", "var(--tw-outline-style)"),
                      n("outline-width", h),
                    ];
              default:
                return (
                  (h = X(h, f.modifier, e)),
                  h === null ? void 0 : [n("outline-color", h)]
                );
            }
          }
          {
            let h = te(f, e, ["--outline-color", "--color"]);
            if (h) return [n("outline-color", h)];
          }
          {
            if (f.modifier) return;
            let h = e.resolve(f.value.value, ["--outline-width"]);
            if (h)
              return [
                l(),
                n("outline-style", "var(--tw-outline-style)"),
                n("outline-width", h),
              ];
            if (T(f.value.value))
              return [
                l(),
                n("outline-style", "var(--tw-outline-style)"),
                n("outline-width", `${f.value.value}px`),
              ];
          }
        }),
        i("outline", () => [
          {
            values: ["current", "inherit", "transparent"],
            valueThemeKeys: ["--outline-color", "--color"],
            modifiers: Array.from({ length: 21 }, (f, h) => `${h * 5}`),
            hasDefaultValue: !0,
          },
          {
            values: ["0", "1", "2", "4", "8"],
            valueThemeKeys: ["--outline-width"],
          },
        ]),
        o("outline-offset", {
          supportsNegative: !0,
          themeKeys: ["--outline-offset"],
          handleBareValue: ({ value: f }) => (T(f) ? `${f}px` : null),
          handle: (f) => [n("outline-offset", f)],
        }),
        i("outline-offset", () => [
          {
            supportsNegative: !0,
            values: ["0", "1", "2", "4", "8"],
            valueThemeKeys: ["--outline-offset"],
          },
        ]);
    }
    o("opacity", {
      themeKeys: ["--opacity"],
      handleBareValue: ({ value: l }) => (ot(l) ? `${l}%` : null),
      handle: (l) => [n("opacity", l)],
    }),
      i("opacity", () => [
        {
          values: Array.from({ length: 21 }, (l, f) => `${f * 5}`),
          valueThemeKeys: ["--opacity"],
        },
      ]),
      o("underline-offset", {
        supportsNegative: !0,
        themeKeys: ["--text-underline-offset"],
        handleBareValue: ({ value: l }) => (T(l) ? `${l}px` : null),
        handle: (l) => [n("text-underline-offset", l)],
        staticValues: { auto: [n("text-underline-offset", "auto")] },
      }),
      i("underline-offset", () => [
        {
          supportsNegative: !0,
          values: ["0", "1", "2", "4", "8"],
          valueThemeKeys: ["--text-underline-offset"],
        },
      ]),
      r.functional("text", (l) => {
        if (l.value) {
          if (l.value.kind === "arbitrary") {
            let f = l.value.value;
            switch (
              l.value.dataType ??
              Z(f, [
                "color",
                "length",
                "percentage",
                "absolute-size",
                "relative-size",
              ])
            ) {
              case "size":
              case "length":
              case "percentage":
              case "absolute-size":
              case "relative-size": {
                if (l.modifier) {
                  let A =
                    l.modifier.kind === "arbitrary"
                      ? l.modifier.value
                      : e.resolve(l.modifier.value, ["--leading"]);
                  if (!A && xe(l.modifier.value)) {
                    let b = e.resolve(null, ["--spacing"]);
                    if (!b) return null;
                    A = `calc(${b} * ${l.modifier.value})`;
                  }
                  return (
                    !A && l.modifier.value === "none" && (A = "1"),
                    A ? [n("font-size", f), n("line-height", A)] : null
                  );
                }
                return [n("font-size", f)];
              }
              default:
                return (
                  (f = X(f, l.modifier, e)),
                  f === null ? void 0 : [n("color", f)]
                );
            }
          }
          {
            let f = te(l, e, ["--text-color", "--color"]);
            if (f) return [n("color", f)];
          }
          {
            let f = e.resolveWith(
              l.value.value,
              ["--text"],
              ["--line-height", "--letter-spacing", "--font-weight"]
            );
            if (f) {
              let [h, A = {}] = Array.isArray(f) ? f : [f];
              if (l.modifier) {
                let b =
                  l.modifier.kind === "arbitrary"
                    ? l.modifier.value
                    : e.resolve(l.modifier.value, ["--leading"]);
                if (!b && xe(l.modifier.value)) {
                  let P = e.resolve(null, ["--spacing"]);
                  if (!P) return null;
                  b = `calc(${P} * ${l.modifier.value})`;
                }
                if ((!b && l.modifier.value === "none" && (b = "1"), !b))
                  return null;
                let $ = [n("font-size", h)];
                return b && $.push(n("line-height", b)), $;
              }
              return typeof A == "string"
                ? [n("font-size", h), n("line-height", A)]
                : [
                    n("font-size", h),
                    n(
                      "line-height",
                      A["--line-height"]
                        ? `var(--tw-leading, ${A["--line-height"]})`
                        : void 0
                    ),
                    n(
                      "letter-spacing",
                      A["--letter-spacing"]
                        ? `var(--tw-tracking, ${A["--letter-spacing"]})`
                        : void 0
                    ),
                    n(
                      "font-weight",
                      A["--font-weight"]
                        ? `var(--tw-font-weight, ${A["--font-weight"]})`
                        : void 0
                    ),
                  ];
            }
          }
        }
      }),
      i("text", () => [
        {
          values: ["current", "inherit", "transparent"],
          valueThemeKeys: ["--text-color", "--color"],
          modifiers: Array.from({ length: 21 }, (l, f) => `${f * 5}`),
        },
        {
          values: [],
          valueThemeKeys: ["--text"],
          modifiers: [],
          modifierThemeKeys: ["--leading"],
        },
      ]);
    let U = () =>
      j([
        S("--tw-text-shadow-color"),
        S("--tw-text-shadow-alpha", "100%", "<percentage>"),
      ]);
    t("text-shadow-initial", [U, ["--tw-text-shadow-color", "initial"]]),
      r.functional("text-shadow", (l) => {
        let f;
        if (
          (l.modifier &&
            (l.modifier.kind === "arbitrary"
              ? (f = l.modifier.value)
              : T(l.modifier.value) && (f = `${l.modifier.value}%`)),
          !l.value)
        ) {
          let h = e.get(["--text-shadow"]);
          return h === null
            ? void 0
            : [
                U(),
                n("--tw-text-shadow-alpha", f),
                ...pe(
                  "text-shadow",
                  h,
                  f,
                  (A) => `var(--tw-text-shadow-color, ${A})`
                ),
              ];
        }
        if (l.value.kind === "arbitrary") {
          let h = l.value.value;
          switch (l.value.dataType ?? Z(h, ["color"])) {
            case "color":
              return (
                (h = X(h, l.modifier, e)),
                h === null
                  ? void 0
                  : [
                      U(),
                      n(
                        "--tw-text-shadow-color",
                        Q(h, "var(--tw-text-shadow-alpha)")
                      ),
                    ]
              );
            default:
              return [
                U(),
                n("--tw-text-shadow-alpha", f),
                ...pe(
                  "text-shadow",
                  h,
                  f,
                  (b) => `var(--tw-text-shadow-color, ${b})`
                ),
              ];
          }
        }
        switch (l.value.value) {
          case "none":
            return l.modifier ? void 0 : [U(), n("text-shadow", "none")];
          case "inherit":
            return l.modifier
              ? void 0
              : [U(), n("--tw-text-shadow-color", "inherit")];
        }
        {
          let h = e.get([`--text-shadow-${l.value.value}`]);
          if (h)
            return [
              U(),
              n("--tw-text-shadow-alpha", f),
              ...pe(
                "text-shadow",
                h,
                f,
                (A) => `var(--tw-text-shadow-color, ${A})`
              ),
            ];
        }
        {
          let h = te(l, e, ["--text-shadow-color", "--color"]);
          if (h)
            return [
              U(),
              n("--tw-text-shadow-color", Q(h, "var(--tw-text-shadow-alpha)")),
            ];
        }
      }),
      i("text-shadow", () => [
        {
          values: ["current", "inherit", "transparent"],
          valueThemeKeys: ["--text-shadow-color", "--color"],
          modifiers: Array.from({ length: 21 }, (l, f) => `${f * 5}`),
        },
        { values: ["none"] },
        {
          valueThemeKeys: ["--text-shadow"],
          modifiers: Array.from({ length: 21 }, (l, f) => `${f * 5}`),
          hasDefaultValue: e.get(["--text-shadow"]) !== null,
        },
      ]);
    {
      let b = function (N) {
          return `var(--tw-ring-inset,) 0 0 0 calc(${N} + var(--tw-ring-offset-width)) var(--tw-ring-color, ${A})`;
        },
        $ = function (N) {
          return `inset 0 0 0 ${N} var(--tw-inset-ring-color, currentcolor)`;
        };
      var M = b,
        oe = $;
      let l = [
          "var(--tw-inset-shadow)",
          "var(--tw-inset-ring-shadow)",
          "var(--tw-ring-offset-shadow)",
          "var(--tw-ring-shadow)",
          "var(--tw-shadow)",
        ].join(", "),
        f = "0 0 #0000",
        h = () =>
          j([
            S("--tw-shadow", f),
            S("--tw-shadow-color"),
            S("--tw-shadow-alpha", "100%", "<percentage>"),
            S("--tw-inset-shadow", f),
            S("--tw-inset-shadow-color"),
            S("--tw-inset-shadow-alpha", "100%", "<percentage>"),
            S("--tw-ring-color"),
            S("--tw-ring-shadow", f),
            S("--tw-inset-ring-color"),
            S("--tw-inset-ring-shadow", f),
            S("--tw-ring-inset"),
            S("--tw-ring-offset-width", "0px", "<length>"),
            S("--tw-ring-offset-color", "#fff"),
            S("--tw-ring-offset-shadow", f),
          ]);
      t("shadow-initial", [h, ["--tw-shadow-color", "initial"]]),
        r.functional("shadow", (N) => {
          let E;
          if (
            (N.modifier &&
              (N.modifier.kind === "arbitrary"
                ? (E = N.modifier.value)
                : T(N.modifier.value) && (E = `${N.modifier.value}%`)),
            !N.value)
          ) {
            let I = e.get(["--shadow"]);
            return I === null
              ? void 0
              : [
                  h(),
                  n("--tw-shadow-alpha", E),
                  ...pe(
                    "--tw-shadow",
                    I,
                    E,
                    (se) => `var(--tw-shadow-color, ${se})`
                  ),
                  n("box-shadow", l),
                ];
          }
          if (N.value.kind === "arbitrary") {
            let I = N.value.value;
            switch (N.value.dataType ?? Z(I, ["color"])) {
              case "color":
                return (
                  (I = X(I, N.modifier, e)),
                  I === null
                    ? void 0
                    : [
                        h(),
                        n("--tw-shadow-color", Q(I, "var(--tw-shadow-alpha)")),
                      ]
                );
              default:
                return [
                  h(),
                  n("--tw-shadow-alpha", E),
                  ...pe(
                    "--tw-shadow",
                    I,
                    E,
                    (bt) => `var(--tw-shadow-color, ${bt})`
                  ),
                  n("box-shadow", l),
                ];
            }
          }
          switch (N.value.value) {
            case "none":
              return N.modifier
                ? void 0
                : [h(), n("--tw-shadow", f), n("box-shadow", l)];
            case "inherit":
              return N.modifier
                ? void 0
                : [h(), n("--tw-shadow-color", "inherit")];
          }
          {
            let I = e.get([`--shadow-${N.value.value}`]);
            if (I)
              return [
                h(),
                n("--tw-shadow-alpha", E),
                ...pe(
                  "--tw-shadow",
                  I,
                  E,
                  (se) => `var(--tw-shadow-color, ${se})`
                ),
                n("box-shadow", l),
              ];
          }
          {
            let I = te(N, e, ["--box-shadow-color", "--color"]);
            if (I)
              return [
                h(),
                n("--tw-shadow-color", Q(I, "var(--tw-shadow-alpha)")),
              ];
          }
        }),
        i("shadow", () => [
          {
            values: ["current", "inherit", "transparent"],
            valueThemeKeys: ["--box-shadow-color", "--color"],
            modifiers: Array.from({ length: 21 }, (N, E) => `${E * 5}`),
          },
          { values: ["none"] },
          {
            valueThemeKeys: ["--shadow"],
            modifiers: Array.from({ length: 21 }, (N, E) => `${E * 5}`),
            hasDefaultValue: e.get(["--shadow"]) !== null,
          },
        ]),
        t("inset-shadow-initial", [h, ["--tw-inset-shadow-color", "initial"]]),
        r.functional("inset-shadow", (N) => {
          let E;
          if (
            (N.modifier &&
              (N.modifier.kind === "arbitrary"
                ? (E = N.modifier.value)
                : T(N.modifier.value) && (E = `${N.modifier.value}%`)),
            !N.value)
          ) {
            let I = e.get(["--inset-shadow"]);
            return I === null
              ? void 0
              : [
                  h(),
                  n("--tw-inset-shadow-alpha", E),
                  ...pe(
                    "--tw-inset-shadow",
                    I,
                    E,
                    (se) => `var(--tw-inset-shadow-color, ${se})`
                  ),
                  n("box-shadow", l),
                ];
          }
          if (N.value.kind === "arbitrary") {
            let I = N.value.value;
            switch (N.value.dataType ?? Z(I, ["color"])) {
              case "color":
                return (
                  (I = X(I, N.modifier, e)),
                  I === null
                    ? void 0
                    : [
                        h(),
                        n(
                          "--tw-inset-shadow-color",
                          Q(I, "var(--tw-inset-shadow-alpha)")
                        ),
                      ]
                );
              default:
                return [
                  h(),
                  n("--tw-inset-shadow-alpha", E),
                  ...pe(
                    "--tw-inset-shadow",
                    I,
                    E,
                    (bt) => `var(--tw-inset-shadow-color, ${bt})`,
                    "inset "
                  ),
                  n("box-shadow", l),
                ];
            }
          }
          switch (N.value.value) {
            case "none":
              return N.modifier
                ? void 0
                : [h(), n("--tw-inset-shadow", f), n("box-shadow", l)];
            case "inherit":
              return N.modifier
                ? void 0
                : [h(), n("--tw-inset-shadow-color", "inherit")];
          }
          {
            let I = e.get([`--inset-shadow-${N.value.value}`]);
            if (I)
              return [
                h(),
                n("--tw-inset-shadow-alpha", E),
                ...pe(
                  "--tw-inset-shadow",
                  I,
                  E,
                  (se) => `var(--tw-inset-shadow-color, ${se})`
                ),
                n("box-shadow", l),
              ];
          }
          {
            let I = te(N, e, ["--box-shadow-color", "--color"]);
            if (I)
              return [
                h(),
                n(
                  "--tw-inset-shadow-color",
                  Q(I, "var(--tw-inset-shadow-alpha)")
                ),
              ];
          }
        }),
        i("inset-shadow", () => [
          {
            values: ["current", "inherit", "transparent"],
            valueThemeKeys: ["--box-shadow-color", "--color"],
            modifiers: Array.from({ length: 21 }, (N, E) => `${E * 5}`),
          },
          { values: ["none"] },
          {
            valueThemeKeys: ["--inset-shadow"],
            modifiers: Array.from({ length: 21 }, (N, E) => `${E * 5}`),
            hasDefaultValue: e.get(["--inset-shadow"]) !== null,
          },
        ]),
        t("ring-inset", [h, ["--tw-ring-inset", "inset"]]);
      let A = e.get(["--default-ring-color"]) ?? "currentcolor";
      r.functional("ring", (N) => {
        if (!N.value) {
          if (N.modifier) return;
          let E = e.get(["--default-ring-width"]) ?? "1px";
          return [h(), n("--tw-ring-shadow", b(E)), n("box-shadow", l)];
        }
        if (N.value.kind === "arbitrary") {
          let E = N.value.value;
          switch (N.value.dataType ?? Z(E, ["color", "length"])) {
            case "length":
              return N.modifier
                ? void 0
                : [h(), n("--tw-ring-shadow", b(E)), n("box-shadow", l)];
            default:
              return (
                (E = X(E, N.modifier, e)),
                E === null ? void 0 : [n("--tw-ring-color", E)]
              );
          }
        }
        {
          let E = te(N, e, ["--ring-color", "--color"]);
          if (E) return [n("--tw-ring-color", E)];
        }
        {
          if (N.modifier) return;
          let E = e.resolve(N.value.value, ["--ring-width"]);
          if ((E === null && T(N.value.value) && (E = `${N.value.value}px`), E))
            return [h(), n("--tw-ring-shadow", b(E)), n("box-shadow", l)];
        }
      }),
        i("ring", () => [
          {
            values: ["current", "inherit", "transparent"],
            valueThemeKeys: ["--ring-color", "--color"],
            modifiers: Array.from({ length: 21 }, (N, E) => `${E * 5}`),
          },
          {
            values: ["0", "1", "2", "4", "8"],
            valueThemeKeys: ["--ring-width"],
            hasDefaultValue: !0,
          },
        ]),
        r.functional("inset-ring", (N) => {
          if (!N.value)
            return N.modifier
              ? void 0
              : [
                  h(),
                  n("--tw-inset-ring-shadow", $("1px")),
                  n("box-shadow", l),
                ];
          if (N.value.kind === "arbitrary") {
            let E = N.value.value;
            switch (N.value.dataType ?? Z(E, ["color", "length"])) {
              case "length":
                return N.modifier
                  ? void 0
                  : [
                      h(),
                      n("--tw-inset-ring-shadow", $(E)),
                      n("box-shadow", l),
                    ];
              default:
                return (
                  (E = X(E, N.modifier, e)),
                  E === null ? void 0 : [n("--tw-inset-ring-color", E)]
                );
            }
          }
          {
            let E = te(N, e, ["--ring-color", "--color"]);
            if (E) return [n("--tw-inset-ring-color", E)];
          }
          {
            if (N.modifier) return;
            let E = e.resolve(N.value.value, ["--ring-width"]);
            if (
              (E === null && T(N.value.value) && (E = `${N.value.value}px`), E)
            )
              return [
                h(),
                n("--tw-inset-ring-shadow", $(E)),
                n("box-shadow", l),
              ];
          }
        }),
        i("inset-ring", () => [
          {
            values: ["current", "inherit", "transparent"],
            valueThemeKeys: ["--ring-color", "--color"],
            modifiers: Array.from({ length: 21 }, (N, E) => `${E * 5}`),
          },
          {
            values: ["0", "1", "2", "4", "8"],
            valueThemeKeys: ["--ring-width"],
            hasDefaultValue: !0,
          },
        ]);
      let P =
        "var(--tw-ring-inset,) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color)";
      r.functional("ring-offset", (N) => {
        if (N.value) {
          if (N.value.kind === "arbitrary") {
            let E = N.value.value;
            switch (N.value.dataType ?? Z(E, ["color", "length"])) {
              case "length":
                return N.modifier
                  ? void 0
                  : [
                      n("--tw-ring-offset-width", E),
                      n("--tw-ring-offset-shadow", P),
                    ];
              default:
                return (
                  (E = X(E, N.modifier, e)),
                  E === null ? void 0 : [n("--tw-ring-offset-color", E)]
                );
            }
          }
          {
            let E = e.resolve(N.value.value, ["--ring-offset-width"]);
            if (E)
              return N.modifier
                ? void 0
                : [
                    n("--tw-ring-offset-width", E),
                    n("--tw-ring-offset-shadow", P),
                  ];
            if (T(N.value.value))
              return N.modifier
                ? void 0
                : [
                    n("--tw-ring-offset-width", `${N.value.value}px`),
                    n("--tw-ring-offset-shadow", P),
                  ];
          }
          {
            let E = te(N, e, ["--ring-offset-color", "--color"]);
            if (E) return [n("--tw-ring-offset-color", E)];
          }
        }
      });
    }
    return (
      i("ring-offset", () => [
        {
          values: ["current", "inherit", "transparent"],
          valueThemeKeys: ["--ring-offset-color", "--color"],
          modifiers: Array.from({ length: 21 }, (l, f) => `${f * 5}`),
        },
        {
          values: ["0", "1", "2", "4", "8"],
          valueThemeKeys: ["--ring-offset-width"],
        },
      ]),
      r.functional("@container", (l) => {
        let f = null;
        if (
          (l.value === null
            ? (f = "inline-size")
            : l.value.kind === "arbitrary"
            ? (f = l.value.value)
            : l.value.kind === "named" && l.value.value === "normal"
            ? (f = "normal")
            : !1,
          f !== null)
        )
          return l.modifier
            ? [n("container-type", f), n("container-name", l.modifier.value)]
            : [n("container-type", f)];
      }),
      i("@container", () => [
        { values: ["normal"], valueThemeKeys: [], hasDefaultValue: !0 },
      ]),
      r
    );
  }
  var Ut = ["number", "integer", "ratio", "percentage"];
  function _r(e) {
    let r = e.params;
    return Po.test(r)
      ? (i) => {
          let t = {
            "--value": {
              usedSpacingInteger: !1,
              usedSpacingNumber: !1,
              themeKeys: new Set(),
              literals: new Set(),
            },
            "--modifier": {
              usedSpacingInteger: !1,
              usedSpacingNumber: !1,
              themeKeys: new Set(),
              literals: new Set(),
            },
          };
          K(e.nodes, (o) => {
            if (
              o.kind !== "declaration" ||
              !o.value ||
              (!o.value.includes("--value(") &&
                !o.value.includes("--modifier("))
            )
              return;
            let s = G(o.value);
            ee(s, (a) => {
              if (a.kind !== "function") return;
              if (
                a.value === "--spacing" &&
                !(
                  t["--modifier"].usedSpacingNumber &&
                  t["--value"].usedSpacingNumber
                )
              )
                return (
                  ee(a.nodes, (u) => {
                    if (
                      u.kind !== "function" ||
                      (u.value !== "--value" && u.value !== "--modifier")
                    )
                      return;
                    let c = u.value;
                    for (let m of u.nodes)
                      if (m.kind === "word") {
                        if (m.value === "integer")
                          t[c].usedSpacingInteger ||= !0;
                        else if (
                          m.value === "number" &&
                          ((t[c].usedSpacingNumber ||= !0),
                          t["--modifier"].usedSpacingNumber &&
                            t["--value"].usedSpacingNumber)
                        )
                          return 2;
                      }
                  }),
                  0
                );
              if (a.value !== "--value" && a.value !== "--modifier") return;
              let d = z(J(a.nodes), ",");
              for (let [u, c] of d.entries())
                (c = c.replace(/\\\*/g, "*")),
                  (c = c.replace(/--(.*?)\s--(.*?)/g, "--$1-*--$2")),
                  (c = c.replace(/\s+/g, "")),
                  (c = c.replace(/(-\*){2,}/g, "-*")),
                  c[0] === "-" &&
                    c[1] === "-" &&
                    !c.includes("-*") &&
                    (c += "-*"),
                  (d[u] = c);
              a.nodes = G(d.join(","));
              for (let u of a.nodes)
                if (
                  u.kind === "word" &&
                  (u.value[0] === '"' || u.value[0] === "'") &&
                  u.value[0] === u.value[u.value.length - 1]
                ) {
                  let c = u.value.slice(1, -1);
                  t[a.value].literals.add(c);
                } else if (
                  u.kind === "word" &&
                  u.value[0] === "-" &&
                  u.value[1] === "-"
                ) {
                  let c = u.value.replace(/-\*.*$/g, "");
                  t[a.value].themeKeys.add(c);
                } else if (
                  u.kind === "word" &&
                  !(
                    u.value[0] === "[" && u.value[u.value.length - 1] === "]"
                  ) &&
                  !Ut.includes(u.value)
                ) {
                  console.warn(`Unsupported bare value data type: "${u.value}".
Only valid data types are: ${Ut.map((w) => `"${w}"`).join(", ")}.
`);
                  let c = u.value,
                    m = structuredClone(a),
                    g = "\xB6";
                  ee(m.nodes, (w, { replaceWith: x }) => {
                    w.kind === "word" &&
                      w.value === c &&
                      x({ kind: "word", value: g });
                  });
                  let p = "^".repeat(J([u]).length),
                    v = J([m]).indexOf(g),
                    k = ["```css", J([a]), " ".repeat(v) + p, "```"].join(`
`);
                  console.warn(k);
                }
            }),
              (o.value = J(s));
          }),
            i.utilities.functional(r.slice(0, -2), (o) => {
              let s = structuredClone(e),
                a = o.value,
                d = o.modifier;
              if (a === null) return;
              let u = !1,
                c = !1,
                m = !1,
                g = !1,
                p = new Map(),
                v = !1;
              if (
                (K([s], (k, { parent: w, replaceWith: x }) => {
                  if (
                    (w?.kind !== "rule" && w?.kind !== "at-rule") ||
                    k.kind !== "declaration" ||
                    !k.value
                  )
                    return;
                  let V = G(k.value);
                  (ee(V, (y, { replaceWith: _ }) => {
                    if (y.kind === "function") {
                      if (y.value === "--value") {
                        u = !0;
                        let R = Tr(a, y, i);
                        return R
                          ? ((c = !0),
                            R.ratio ? (v = !0) : p.set(k, w),
                            _(R.nodes),
                            1)
                          : ((u ||= !1), x([]), 2);
                      } else if (y.value === "--modifier") {
                        if (d === null) return x([]), 2;
                        m = !0;
                        let R = Tr(d, y, i);
                        return R
                          ? ((g = !0), _(R.nodes), 1)
                          : ((m ||= !1), x([]), 2);
                      }
                    }
                  }) ?? 0) === 0 && (k.value = J(V));
                }),
                (u && !c) || (m && !g) || (v && g) || (d && !v && !g))
              )
                return null;
              if (v)
                for (let [k, w] of p) {
                  let x = w.nodes.indexOf(k);
                  x !== -1 && w.nodes.splice(x, 1);
                }
              return s.nodes;
            }),
            i.utilities.suggest(r.slice(0, -2), () => {
              let o = [],
                s = [];
              for (let [
                a,
                {
                  literals: d,
                  usedSpacingNumber: u,
                  usedSpacingInteger: c,
                  themeKeys: m,
                },
              ] of [
                [o, t["--value"]],
                [s, t["--modifier"]],
              ]) {
                for (let g of d) a.push(g);
                if (u) a.push(...lt);
                else if (c) for (let g of lt) T(g) && a.push(g);
                for (let g of i.theme.keysInNamespaces(m))
                  a.push(g.replace(Pr, (p, v, k) => `${v}.${k}`));
              }
              return [{ values: o, modifiers: s }];
            });
        }
      : Ro.test(r)
      ? (i) => {
          i.utilities.static(r, () => structuredClone(e.nodes));
        }
      : null;
  }
  function Tr(e, r, i) {
    for (let t of r.nodes) {
      if (
        e.kind === "named" &&
        t.kind === "word" &&
        (t.value[0] === "'" || t.value[0] === '"') &&
        t.value[t.value.length - 1] === t.value[0] &&
        t.value.slice(1, -1) === e.value
      )
        return { nodes: G(e.value) };
      if (
        e.kind === "named" &&
        t.kind === "word" &&
        t.value[0] === "-" &&
        t.value[1] === "-"
      ) {
        let o = t.value;
        if (o.endsWith("-*")) {
          o = o.slice(0, -2);
          let s = i.theme.resolve(e.value, [o]);
          if (s) return { nodes: G(s) };
        } else {
          let s = o.split("-*");
          if (s.length <= 1) continue;
          let a = [s.shift()],
            d = i.theme.resolveWith(e.value, a, s);
          if (d) {
            let [, u = {}] = d;
            {
              let c = u[s.pop()];
              if (c) return { nodes: G(c) };
            }
          }
        }
      } else if (e.kind === "named" && t.kind === "word") {
        if (!Ut.includes(t.value)) continue;
        let o = t.value === "ratio" && "fraction" in e ? e.fraction : e.value;
        if (!o) continue;
        let s = Z(o, [t.value]);
        if (s === null) continue;
        if (s === "ratio") {
          let [a, d] = z(o, "/");
          if (!T(a) || !T(d)) continue;
        } else {
          if (s === "number" && !xe(o)) continue;
          if (s === "percentage" && !T(o.slice(0, -1))) continue;
        }
        return { nodes: G(o), ratio: s === "ratio" };
      } else if (
        e.kind === "arbitrary" &&
        t.kind === "word" &&
        t.value[0] === "[" &&
        t.value[t.value.length - 1] === "]"
      ) {
        let o = t.value.slice(1, -1);
        if (o === "*") return { nodes: G(e.value) };
        if ("dataType" in e && e.dataType && e.dataType !== o) continue;
        if ("dataType" in e && e.dataType) return { nodes: G(e.value) };
        if (Z(e.value, [o]) !== null) return { nodes: G(e.value) };
      }
    }
  }
  function pe(e, r, i, t, o = "") {
    let s = !1,
      a = ze(r, (u) =>
        i == null
          ? t(u)
          : u.startsWith("current")
          ? t(Q(u, i))
          : ((u.startsWith("var(") || i.startsWith("var(")) && (s = !0),
            t(Rr(u, i)))
      );
    function d(u) {
      return o
        ? z(u, ",")
            .map((c) => o + c)
            .join(",")
        : u;
    }
    return s
      ? [
          n(e, d(ze(r, t))),
          Y("@supports (color: lab(from red l a b))", [n(e, d(a))]),
        ]
      : [n(e, d(a))];
  }
  function nt(e, r, i, t, o = "") {
    let s = !1,
      a = z(r, ",")
        .map((d) =>
          ze(d, (u) =>
            i == null
              ? t(u)
              : u.startsWith("current")
              ? t(Q(u, i))
              : ((u.startsWith("var(") || i.startsWith("var(")) && (s = !0),
                t(Rr(u, i)))
          )
        )
        .map((d) => `drop-shadow(${d})`)
        .join(" ");
    return s
      ? [
          n(
            e,
            o +
              z(r, ",")
                .map((d) => `drop-shadow(${ze(d, t)})`)
                .join(" ")
          ),
          Y("@supports (color: lab(from red l a b))", [n(e, o + a)]),
        ]
      : [n(e, o + a)];
  }
  var zt = { "--alpha": Oo, "--spacing": _o, "--theme": Do, theme: Uo };
  function Oo(e, r, i, ...t) {
    let [o, s] = z(i, "/").map((a) => a.trim());
    if (!o || !s)
      throw new Error(
        `The --alpha(\u2026) function requires a color and an alpha value, e.g.: \`--alpha(${
          o || "var(--my-color)"
        } / ${s || "50%"})\``
      );
    if (t.length > 0)
      throw new Error(
        `The --alpha(\u2026) function only accepts one argument, e.g.: \`--alpha(${
          o || "var(--my-color)"
        } / ${s || "50%"})\``
      );
    return Q(o, s);
  }
  function _o(e, r, i, ...t) {
    if (!i)
      throw new Error(
        "The --spacing(\u2026) function requires an argument, but received none."
      );
    if (t.length > 0)
      throw new Error(
        `The --spacing(\u2026) function only accepts a single argument, but received ${
          t.length + 1
        }.`
      );
    let o = e.theme.resolve(null, ["--spacing"]);
    if (!o)
      throw new Error(
        "The --spacing(\u2026) function requires that the `--spacing` theme variable exists, but it was not found."
      );
    return `calc(${o} * ${i})`;
  }
  function Do(e, r, i, ...t) {
    if (!i.startsWith("--"))
      throw new Error(
        "The --theme(\u2026) function can only be used with CSS variables from your theme."
      );
    let o = !1;
    i.endsWith(" inline") && ((o = !0), (i = i.slice(0, -7))),
      r.kind === "at-rule" && (o = !0);
    let s = e.resolveThemeValue(i, o);
    if (!s) {
      if (t.length > 0) return t.join(", ");
      throw new Error(
        `Could not resolve value for theme function: \`theme(${i})\`. Consider checking if the variable name is correct or provide a fallback value to silence this error.`
      );
    }
    if (t.length === 0) return s;
    let a = t.join(", ");
    if (a === "initial") return s;
    if (s === "initial") return a;
    if (
      s.startsWith("var(") ||
      s.startsWith("theme(") ||
      s.startsWith("--theme(")
    ) {
      let d = G(s);
      return Ko(d, a), J(d);
    }
    return s;
  }
  function Uo(e, r, i, ...t) {
    i = zo(i);
    let o = e.resolveThemeValue(i);
    if (!o && t.length > 0) return t.join(", ");
    if (!o)
      throw new Error(
        `Could not resolve value for theme function: \`theme(${i})\`. Consider checking if the path is correct or provide a fallback value to silence this error.`
      );
    return o;
  }
  var Dr = new RegExp(
    Object.keys(zt)
      .map((e) => `${e}\\(`)
      .join("|")
  );
  function Ve(e, r) {
    let i = 0;
    return (
      K(e, (t) => {
        if (t.kind === "declaration" && t.value && Dr.test(t.value)) {
          (i |= 8), (t.value = Ur(t.value, t, r));
          return;
        }
        t.kind === "at-rule" &&
          (t.name === "@media" ||
            t.name === "@custom-media" ||
            t.name === "@container" ||
            t.name === "@supports") &&
          Dr.test(t.params) &&
          ((i |= 8), (t.params = Ur(t.params, t, r)));
      }),
      i
    );
  }
  function Ur(e, r, i) {
    let t = G(e);
    return (
      ee(t, (o, { replaceWith: s }) => {
        if (o.kind === "function" && o.value in zt) {
          let a = z(J(o.nodes).trim(), ",").map((u) => u.trim()),
            d = zt[o.value](i, r, ...a);
          return s(G(d));
        }
      }),
      J(t)
    );
  }
  function zo(e) {
    if (e[0] !== "'" && e[0] !== '"') return e;
    let r = "",
      i = e[0];
    for (let t = 1; t < e.length - 1; t++) {
      let o = e[t],
        s = e[t + 1];
      o === "\\" && (s === i || s === "\\") ? ((r += s), t++) : (r += o);
    }
    return r;
  }
  function Ko(e, r) {
    ee(e, (i) => {
      if (
        i.kind === "function" &&
        !(i.value !== "var" && i.value !== "theme" && i.value !== "--theme")
      )
        if (i.nodes.length === 1)
          i.nodes.push({ kind: "word", value: `, ${r}` });
        else {
          let t = i.nodes[i.nodes.length - 1];
          t.kind === "word" && t.value === "initial" && (t.value = r);
        }
    });
  }
  function st(e, r) {
    let i = e.length,
      t = r.length,
      o = i < t ? i : t;
    for (let s = 0; s < o; s++) {
      let a = e.charCodeAt(s),
        d = r.charCodeAt(s);
      if (a >= 48 && a <= 57 && d >= 48 && d <= 57) {
        let u = s,
          c = s + 1,
          m = s,
          g = s + 1;
        for (a = e.charCodeAt(c); a >= 48 && a <= 57; ) a = e.charCodeAt(++c);
        for (d = r.charCodeAt(g); d >= 48 && d <= 57; ) d = r.charCodeAt(++g);
        let p = e.slice(u, c),
          v = r.slice(m, g),
          k = Number(p) - Number(v);
        if (k) return k;
        if (p < v) return -1;
        if (p > v) return 1;
        continue;
      }
      if (a !== d) return a - d;
    }
    return e.length - r.length;
  }
  var Lo = /^\d+\/\d+$/;
  function zr(e) {
    let r = new B((o) => ({
      name: o,
      utility: o,
      fraction: !1,
      modifiers: [],
    }));
    for (let o of e.utilities.keys("static")) {
      let s = r.get(o);
      (s.fraction = !1), (s.modifiers = []);
    }
    for (let o of e.utilities.keys("functional")) {
      let s = e.utilities.getCompletions(o);
      for (let a of s)
        for (let d of a.values) {
          let u = d !== null && Lo.test(d),
            c = d === null ? o : `${o}-${d}`,
            m = r.get(c);
          if (
            ((m.utility = o),
            (m.fraction ||= u),
            m.modifiers.push(...a.modifiers),
            a.supportsNegative)
          ) {
            let g = r.get(`-${c}`);
            (g.utility = `-${o}`),
              (g.fraction ||= u),
              g.modifiers.push(...a.modifiers);
          }
          m.modifiers = Array.from(new Set(m.modifiers));
        }
    }
    if (r.size === 0) return [];
    let i = Array.from(r.values());
    return i.sort((o, s) => st(o.name, s.name)), Io(i);
  }
  function Io(e) {
    let r = [],
      i = null,
      t = new Map(),
      o = new B(() => []);
    for (let a of e) {
      let { utility: d, fraction: u } = a;
      i || ((i = { utility: d, items: [] }), t.set(d, i)),
        d !== i.utility &&
          (r.push(i), (i = { utility: d, items: [] }), t.set(d, i)),
        u ? o.get(d).push(a) : i.items.push(a);
    }
    i && r[r.length - 1] !== i && r.push(i);
    for (let [a, d] of o) {
      let u = t.get(a);
      u && u.items.push(...d);
    }
    let s = [];
    for (let a of r)
      for (let d of a.items) s.push([d.name, { modifiers: d.modifiers }]);
    return s;
  }
  function Kr(e) {
    let r = [];
    for (let [t, o] of e.variants.entries()) {
      let d = function ({ value: u, modifier: c } = {}) {
        let m = t;
        u && (m += s ? `-${u}` : u), c && (m += `/${c}`);
        let g = e.parseVariant(m);
        if (!g) return [];
        let p = W(".__placeholder__", []);
        if (Ee(p, g, e.variants) === null) return [];
        let v = [];
        return (
          Xe(p.nodes, (k, { path: w }) => {
            if (
              (k.kind !== "rule" && k.kind !== "at-rule") ||
              k.nodes.length > 0
            )
              return;
            w.sort((C, y) => {
              let _ = C.kind === "at-rule",
                R = y.kind === "at-rule";
              return _ && !R ? -1 : !_ && R ? 1 : 0;
            });
            let x = w.flatMap((C) =>
                C.kind === "rule"
                  ? C.selector === "&"
                    ? []
                    : [C.selector]
                  : C.kind === "at-rule"
                  ? [`${C.name} ${C.params}`]
                  : []
              ),
              V = "";
            for (let C = x.length - 1; C >= 0; C--)
              V = V === "" ? x[C] : `${x[C]} { ${V} }`;
            v.push(V);
          }),
          v
        );
      };
      var i = d;
      if (o.kind === "arbitrary") continue;
      let s = t !== "@",
        a = e.variants.getCompletions(t);
      switch (o.kind) {
        case "static": {
          r.push({
            name: t,
            values: a,
            isArbitrary: !1,
            hasDash: s,
            selectors: d,
          });
          break;
        }
        case "functional": {
          r.push({
            name: t,
            values: a,
            isArbitrary: !0,
            hasDash: s,
            selectors: d,
          });
          break;
        }
        case "compound": {
          r.push({
            name: t,
            values: a,
            isArbitrary: !0,
            hasDash: s,
            selectors: d,
          });
          break;
        }
      }
    }
    return r;
  }
  function Lr(e, r) {
    let { astNodes: i, nodeSorting: t } = he(Array.from(r), e),
      o = new Map(r.map((a) => [a, null])),
      s = 0n;
    for (let a of i) {
      let d = t.get(a)?.candidate;
      d && o.set(d, o.get(d) ?? s++);
    }
    return r.map((a) => [a, o.get(a) ?? null]);
  }
  var ut = /^@?[a-z0-9][a-zA-Z0-9_-]*(?<![_-])$/;
  var Kt = class {
    compareFns = new Map();
    variants = new Map();
    completions = new Map();
    groupOrder = null;
    lastOrder = 0;
    static(r, i, { compounds: t, order: o } = {}) {
      this.set(r, {
        kind: "static",
        applyFn: i,
        compoundsWith: 0,
        compounds: t ?? 2,
        order: o,
      });
    }
    fromAst(r, i, t) {
      let o = [],
        s = !1;
      K(i, (a) => {
        a.kind === "rule"
          ? o.push(a.selector)
          : a.kind === "at-rule" && a.name === "@variant"
          ? (s = !0)
          : a.kind === "at-rule" &&
            a.name !== "@slot" &&
            o.push(`${a.name} ${a.params}`);
      }),
        this.static(
          r,
          (a) => {
            let d = structuredClone(i);
            s && It(d, t), Lt(d, a.nodes), (a.nodes = d);
          },
          { compounds: Ae(o) }
        );
    }
    functional(r, i, { compounds: t, order: o } = {}) {
      this.set(r, {
        kind: "functional",
        applyFn: i,
        compoundsWith: 0,
        compounds: t ?? 2,
        order: o,
      });
    }
    compound(r, i, t, { compounds: o, order: s } = {}) {
      this.set(r, {
        kind: "compound",
        applyFn: t,
        compoundsWith: i,
        compounds: o ?? 2,
        order: s,
      });
    }
    group(r, i) {
      (this.groupOrder = this.nextOrder()),
        i && this.compareFns.set(this.groupOrder, i),
        r(),
        (this.groupOrder = null);
    }
    has(r) {
      return this.variants.has(r);
    }
    get(r) {
      return this.variants.get(r);
    }
    kind(r) {
      return this.variants.get(r)?.kind;
    }
    compoundsWith(r, i) {
      let t = this.variants.get(r),
        o =
          typeof i == "string"
            ? this.variants.get(i)
            : i.kind === "arbitrary"
            ? { compounds: Ae([i.selector]) }
            : this.variants.get(i.root);
      return !(
        !t ||
        !o ||
        t.kind !== "compound" ||
        o.compounds === 0 ||
        t.compoundsWith === 0 ||
        (t.compoundsWith & o.compounds) === 0
      );
    }
    suggest(r, i) {
      this.completions.set(r, i);
    }
    getCompletions(r) {
      return this.completions.get(r)?.() ?? [];
    }
    compare(r, i) {
      if (r === i) return 0;
      if (r === null) return -1;
      if (i === null) return 1;
      if (r.kind === "arbitrary" && i.kind === "arbitrary")
        return r.selector < i.selector ? -1 : 1;
      if (r.kind === "arbitrary") return 1;
      if (i.kind === "arbitrary") return -1;
      let t = this.variants.get(r.root).order,
        o = this.variants.get(i.root).order,
        s = t - o;
      if (s !== 0) return s;
      if (r.kind === "compound" && i.kind === "compound") {
        let c = this.compare(r.variant, i.variant);
        return c !== 0
          ? c
          : r.modifier && i.modifier
          ? r.modifier.value < i.modifier.value
            ? -1
            : 1
          : r.modifier
          ? 1
          : i.modifier
          ? -1
          : 0;
      }
      let a = this.compareFns.get(t);
      if (a !== void 0) return a(r, i);
      if (r.root !== i.root) return r.root < i.root ? -1 : 1;
      let d = r.value,
        u = i.value;
      return d === null
        ? -1
        : u === null || (d.kind === "arbitrary" && u.kind !== "arbitrary")
        ? 1
        : (d.kind !== "arbitrary" && u.kind === "arbitrary") ||
          d.value < u.value
        ? -1
        : 1;
    }
    keys() {
      return this.variants.keys();
    }
    entries() {
      return this.variants.entries();
    }
    set(r, { kind: i, applyFn: t, compounds: o, compoundsWith: s, order: a }) {
      let d = this.variants.get(r);
      d
        ? Object.assign(d, { kind: i, applyFn: t, compounds: o })
        : (a === void 0 &&
            ((this.lastOrder = this.nextOrder()), (a = this.lastOrder)),
          this.variants.set(r, {
            kind: i,
            applyFn: t,
            order: a,
            compoundsWith: s,
            compounds: o,
          }));
    }
    nextOrder() {
      return this.groupOrder ?? this.lastOrder + 1;
    }
  };
  function Ae(e) {
    let r = 0;
    for (let i of e) {
      if (i[0] === "@") {
        if (
          !i.startsWith("@media") &&
          !i.startsWith("@supports") &&
          !i.startsWith("@container")
        )
          return 0;
        r |= 1;
        continue;
      }
      if (i.includes("::")) return 0;
      r |= 2;
    }
    return r;
  }
  function jr(e) {
    let r = new Kt();
    function i(c, m, { compounds: g } = {}) {
      (g = g ?? Ae(m)),
        r.static(
          c,
          (p) => {
            p.nodes = m.map((v) => Y(v, p.nodes));
          },
          { compounds: g }
        );
    }
    i("*", [":is(& > *)"], { compounds: 0 }),
      i("**", [":is(& *)"], { compounds: 0 });
    function t(c, m) {
      return m.map((g) => {
        g = g.trim();
        let p = z(g, " ");
        return p[0] === "not"
          ? p.slice(1).join(" ")
          : c === "@container"
          ? p[0][0] === "("
            ? `not ${g}`
            : p[1] === "not"
            ? `${p[0]} ${p.slice(2).join(" ")}`
            : `${p[0]} not ${p.slice(1).join(" ")}`
          : `not ${g}`;
      });
    }
    let o = ["@media", "@supports", "@container"];
    function s(c) {
      for (let m of o) {
        if (m !== c.name) continue;
        let g = z(c.params, ",");
        return g.length > 1
          ? null
          : ((g = t(c.name, g)), F(c.name, g.join(", ")));
      }
      return null;
    }
    function a(c) {
      return c.includes("::")
        ? null
        : `&:not(${z(c, ",")
            .map((g) => ((g = g.replaceAll("&", "*")), g))
            .join(", ")})`;
    }
    r.compound("not", 3, (c, m) => {
      if ((m.variant.kind === "arbitrary" && m.variant.relative) || m.modifier)
        return null;
      let g = !1;
      if (
        (K([c], (p, { path: v }) => {
          if (p.kind !== "rule" && p.kind !== "at-rule") return 0;
          if (p.nodes.length > 0) return 0;
          let k = [],
            w = [];
          for (let V of v)
            V.kind === "at-rule" ? k.push(V) : V.kind === "rule" && w.push(V);
          if (k.length > 1) return 2;
          if (w.length > 1) return 2;
          let x = [];
          for (let V of w) {
            let C = a(V.selector);
            if (!C) return (g = !1), 2;
            x.push(W(C, []));
          }
          for (let V of k) {
            let C = s(V);
            if (!C) return (g = !1), 2;
            x.push(C);
          }
          return Object.assign(c, W("&", x)), (g = !0), 1;
        }),
        c.kind === "rule" &&
          c.selector === "&" &&
          c.nodes.length === 1 &&
          Object.assign(c, c.nodes[0]),
        !g)
      )
        return null;
    }),
      r.suggest("not", () =>
        Array.from(r.keys()).filter((c) => r.compoundsWith("not", c))
      ),
      r.compound("group", 2, (c, m) => {
        if (m.variant.kind === "arbitrary" && m.variant.relative) return null;
        let g = m.modifier
            ? `:where(.${e.prefix ? `${e.prefix}\\:` : ""}group\\/${
                m.modifier.value
              })`
            : `:where(.${e.prefix ? `${e.prefix}\\:` : ""}group)`,
          p = !1;
        if (
          (K([c], (v, { path: k }) => {
            if (v.kind !== "rule") return 0;
            for (let x of k.slice(0, -1))
              if (x.kind === "rule") return (p = !1), 2;
            let w = v.selector.replaceAll("&", g);
            z(w, ",").length > 1 && (w = `:is(${w})`),
              (v.selector = `&:is(${w} *)`),
              (p = !0);
          }),
          !p)
        )
          return null;
      }),
      r.suggest("group", () =>
        Array.from(r.keys()).filter((c) => r.compoundsWith("group", c))
      ),
      r.compound("peer", 2, (c, m) => {
        if (m.variant.kind === "arbitrary" && m.variant.relative) return null;
        let g = m.modifier
            ? `:where(.${e.prefix ? `${e.prefix}\\:` : ""}peer\\/${
                m.modifier.value
              })`
            : `:where(.${e.prefix ? `${e.prefix}\\:` : ""}peer)`,
          p = !1;
        if (
          (K([c], (v, { path: k }) => {
            if (v.kind !== "rule") return 0;
            for (let x of k.slice(0, -1))
              if (x.kind === "rule") return (p = !1), 2;
            let w = v.selector.replaceAll("&", g);
            z(w, ",").length > 1 && (w = `:is(${w})`),
              (v.selector = `&:is(${w} ~ *)`),
              (p = !0);
          }),
          !p)
        )
          return null;
      }),
      r.suggest("peer", () =>
        Array.from(r.keys()).filter((c) => r.compoundsWith("peer", c))
      ),
      i("first-letter", ["&::first-letter"]),
      i("first-line", ["&::first-line"]),
      i("marker", [
        "& *::marker",
        "&::marker",
        "& *::-webkit-details-marker",
        "&::-webkit-details-marker",
      ]),
      i("selection", ["& *::selection", "&::selection"]),
      i("file", ["&::file-selector-button"]),
      i("placeholder", ["&::placeholder"]),
      i("backdrop", ["&::backdrop"]),
      i("details-content", ["&::details-content"]);
    {
      let c = function () {
        return j([
          F("@property", "--tw-content", [
            n("syntax", '"*"'),
            n("initial-value", '""'),
            n("inherits", "false"),
          ]),
        ]);
      };
      var d = c;
      r.static(
        "before",
        (m) => {
          m.nodes = [
            W("&::before", [
              c(),
              n("content", "var(--tw-content)"),
              ...m.nodes,
            ]),
          ];
        },
        { compounds: 0 }
      ),
        r.static(
          "after",
          (m) => {
            m.nodes = [
              W("&::after", [
                c(),
                n("content", "var(--tw-content)"),
                ...m.nodes,
              ]),
            ];
          },
          { compounds: 0 }
        );
    }
    i("first", ["&:first-child"]),
      i("last", ["&:last-child"]),
      i("only", ["&:only-child"]),
      i("odd", ["&:nth-child(odd)"]),
      i("even", ["&:nth-child(even)"]),
      i("first-of-type", ["&:first-of-type"]),
      i("last-of-type", ["&:last-of-type"]),
      i("only-of-type", ["&:only-of-type"]),
      i("visited", ["&:visited"]),
      i("target", ["&:target"]),
      i("open", ["&:is([open], :popover-open, :open)"]),
      i("default", ["&:default"]),
      i("checked", ["&:checked"]),
      i("indeterminate", ["&:indeterminate"]),
      i("placeholder-shown", ["&:placeholder-shown"]),
      i("autofill", ["&:autofill"]),
      i("optional", ["&:optional"]),
      i("required", ["&:required"]),
      i("valid", ["&:valid"]),
      i("invalid", ["&:invalid"]),
      i("user-valid", ["&:user-valid"]),
      i("user-invalid", ["&:user-invalid"]),
      i("in-range", ["&:in-range"]),
      i("out-of-range", ["&:out-of-range"]),
      i("read-only", ["&:read-only"]),
      i("empty", ["&:empty"]),
      i("focus-within", ["&:focus-within"]),
      r.static("hover", (c) => {
        c.nodes = [W("&:hover", [F("@media", "(hover: hover)", c.nodes)])];
      }),
      i("focus", ["&:focus"]),
      i("focus-visible", ["&:focus-visible"]),
      i("active", ["&:active"]),
      i("enabled", ["&:enabled"]),
      i("disabled", ["&:disabled"]),
      i("inert", ["&:is([inert], [inert] *)"]),
      r.compound("in", 2, (c, m) => {
        if (m.modifier) return null;
        let g = !1;
        if (
          (K([c], (p, { path: v }) => {
            if (p.kind !== "rule") return 0;
            for (let k of v.slice(0, -1))
              if (k.kind === "rule") return (g = !1), 2;
            (p.selector = `:where(${p.selector.replaceAll("&", "*")}) &`),
              (g = !0);
          }),
          !g)
        )
          return null;
      }),
      r.suggest("in", () =>
        Array.from(r.keys()).filter((c) => r.compoundsWith("in", c))
      ),
      r.compound("has", 2, (c, m) => {
        if (m.modifier) return null;
        let g = !1;
        if (
          (K([c], (p, { path: v }) => {
            if (p.kind !== "rule") return 0;
            for (let k of v.slice(0, -1))
              if (k.kind === "rule") return (g = !1), 2;
            (p.selector = `&:has(${p.selector.replaceAll("&", "*")})`),
              (g = !0);
          }),
          !g)
        )
          return null;
      }),
      r.suggest("has", () =>
        Array.from(r.keys()).filter((c) => r.compoundsWith("has", c))
      ),
      r.functional("aria", (c, m) => {
        if (!m.value || m.modifier) return null;
        m.value.kind === "arbitrary"
          ? (c.nodes = [W(`&[aria-${Ir(m.value.value)}]`, c.nodes)])
          : (c.nodes = [W(`&[aria-${m.value.value}="true"]`, c.nodes)]);
      }),
      r.suggest("aria", () => [
        "busy",
        "checked",
        "disabled",
        "expanded",
        "hidden",
        "pressed",
        "readonly",
        "required",
        "selected",
      ]),
      r.functional("data", (c, m) => {
        if (!m.value || m.modifier) return null;
        c.nodes = [W(`&[data-${Ir(m.value.value)}]`, c.nodes)];
      }),
      r.functional("nth", (c, m) => {
        if (
          !m.value ||
          m.modifier ||
          (m.value.kind === "named" && !T(m.value.value))
        )
          return null;
        c.nodes = [W(`&:nth-child(${m.value.value})`, c.nodes)];
      }),
      r.functional("nth-last", (c, m) => {
        if (
          !m.value ||
          m.modifier ||
          (m.value.kind === "named" && !T(m.value.value))
        )
          return null;
        c.nodes = [W(`&:nth-last-child(${m.value.value})`, c.nodes)];
      }),
      r.functional("nth-of-type", (c, m) => {
        if (
          !m.value ||
          m.modifier ||
          (m.value.kind === "named" && !T(m.value.value))
        )
          return null;
        c.nodes = [W(`&:nth-of-type(${m.value.value})`, c.nodes)];
      }),
      r.functional("nth-last-of-type", (c, m) => {
        if (
          !m.value ||
          m.modifier ||
          (m.value.kind === "named" && !T(m.value.value))
        )
          return null;
        c.nodes = [W(`&:nth-last-of-type(${m.value.value})`, c.nodes)];
      }),
      r.functional(
        "supports",
        (c, m) => {
          if (!m.value || m.modifier) return null;
          let g = m.value.value;
          if (g === null) return null;
          if (/^[\w-]*\s*\(/.test(g)) {
            let p = g.replace(/\b(and|or|not)\b/g, " $1 ");
            c.nodes = [F("@supports", p, c.nodes)];
            return;
          }
          g.includes(":") || (g = `${g}: var(--tw)`),
            (g[0] !== "(" || g[g.length - 1] !== ")") && (g = `(${g})`),
            (c.nodes = [F("@supports", g, c.nodes)]);
        },
        { compounds: 1 }
      ),
      i("motion-safe", ["@media (prefers-reduced-motion: no-preference)"]),
      i("motion-reduce", ["@media (prefers-reduced-motion: reduce)"]),
      i("contrast-more", ["@media (prefers-contrast: more)"]),
      i("contrast-less", ["@media (prefers-contrast: less)"]);
    {
      let c = function (m, g, p, v) {
        if (m === g) return 0;
        let k = v.get(m);
        if (k === null) return p === "asc" ? -1 : 1;
        let w = v.get(g);
        return w === null ? (p === "asc" ? 1 : -1) : ye(k, w, p);
      };
      var u = c;
      {
        let m = e.namespace("--breakpoint"),
          g = new B((p) => {
            switch (p.kind) {
              case "static":
                return e.resolveValue(p.root, ["--breakpoint"]) ?? null;
              case "functional": {
                if (!p.value || p.modifier) return null;
                let v = null;
                return (
                  p.value.kind === "arbitrary"
                    ? (v = p.value.value)
                    : p.value.kind === "named" &&
                      (v = e.resolveValue(p.value.value, ["--breakpoint"])),
                  !v || v.includes("var(") ? null : v
                );
              }
              case "arbitrary":
              case "compound":
                return null;
            }
          });
        r.group(
          () => {
            r.functional(
              "max",
              (p, v) => {
                if (v.modifier) return null;
                let k = g.get(v);
                if (k === null) return null;
                p.nodes = [F("@media", `(width < ${k})`, p.nodes)];
              },
              { compounds: 1 }
            );
          },
          (p, v) => c(p, v, "desc", g)
        ),
          r.suggest("max", () =>
            Array.from(m.keys()).filter((p) => p !== null)
          ),
          r.group(
            () => {
              for (let [p, v] of e.namespace("--breakpoint"))
                p !== null &&
                  r.static(
                    p,
                    (k) => {
                      k.nodes = [F("@media", `(width >= ${v})`, k.nodes)];
                    },
                    { compounds: 1 }
                  );
              r.functional(
                "min",
                (p, v) => {
                  if (v.modifier) return null;
                  let k = g.get(v);
                  if (k === null) return null;
                  p.nodes = [F("@media", `(width >= ${k})`, p.nodes)];
                },
                { compounds: 1 }
              );
            },
            (p, v) => c(p, v, "asc", g)
          ),
          r.suggest("min", () =>
            Array.from(m.keys()).filter((p) => p !== null)
          );
      }
      {
        let m = e.namespace("--container"),
          g = new B((p) => {
            switch (p.kind) {
              case "functional": {
                if (p.value === null) return null;
                let v = null;
                return (
                  p.value.kind === "arbitrary"
                    ? (v = p.value.value)
                    : p.value.kind === "named" &&
                      (v = e.resolveValue(p.value.value, ["--container"])),
                  !v || v.includes("var(") ? null : v
                );
              }
              case "static":
              case "arbitrary":
              case "compound":
                return null;
            }
          });
        r.group(
          () => {
            r.functional(
              "@max",
              (p, v) => {
                let k = g.get(v);
                if (k === null) return null;
                p.nodes = [
                  F(
                    "@container",
                    v.modifier
                      ? `${v.modifier.value} (width < ${k})`
                      : `(width < ${k})`,
                    p.nodes
                  ),
                ];
              },
              { compounds: 1 }
            );
          },
          (p, v) => c(p, v, "desc", g)
        ),
          r.suggest("@max", () =>
            Array.from(m.keys()).filter((p) => p !== null)
          ),
          r.group(
            () => {
              r.functional(
                "@",
                (p, v) => {
                  let k = g.get(v);
                  if (k === null) return null;
                  p.nodes = [
                    F(
                      "@container",
                      v.modifier
                        ? `${v.modifier.value} (width >= ${k})`
                        : `(width >= ${k})`,
                      p.nodes
                    ),
                  ];
                },
                { compounds: 1 }
              ),
                r.functional(
                  "@min",
                  (p, v) => {
                    let k = g.get(v);
                    if (k === null) return null;
                    p.nodes = [
                      F(
                        "@container",
                        v.modifier
                          ? `${v.modifier.value} (width >= ${k})`
                          : `(width >= ${k})`,
                        p.nodes
                      ),
                    ];
                  },
                  { compounds: 1 }
                );
            },
            (p, v) => c(p, v, "asc", g)
          ),
          r.suggest("@min", () =>
            Array.from(m.keys()).filter((p) => p !== null)
          ),
          r.suggest("@", () => Array.from(m.keys()).filter((p) => p !== null));
      }
    }
    return (
      i("portrait", ["@media (orientation: portrait)"]),
      i("landscape", ["@media (orientation: landscape)"]),
      i("ltr", ['&:where(:dir(ltr), [dir="ltr"], [dir="ltr"] *)']),
      i("rtl", ['&:where(:dir(rtl), [dir="rtl"], [dir="rtl"] *)']),
      i("dark", ["@media (prefers-color-scheme: dark)"]),
      i("starting", ["@starting-style"]),
      i("print", ["@media print"]),
      i("forced-colors", ["@media (forced-colors: active)"]),
      i("inverted-colors", ["@media (inverted-colors: inverted)"]),
      i("pointer-none", ["@media (pointer: none)"]),
      i("pointer-coarse", ["@media (pointer: coarse)"]),
      i("pointer-fine", ["@media (pointer: fine)"]),
      i("any-pointer-none", ["@media (any-pointer: none)"]),
      i("any-pointer-coarse", ["@media (any-pointer: coarse)"]),
      i("any-pointer-fine", ["@media (any-pointer: fine)"]),
      i("noscript", ["@media (scripting: none)"]),
      r
    );
  }
  function Ir(e) {
    if (e.includes("=")) {
      let [r, ...i] = z(e, "="),
        t = i.join("=").trim();
      if (t[0] === "'" || t[0] === '"') return e;
      if (t.length > 1) {
        let o = t[t.length - 1];
        if (
          t[t.length - 2] === " " &&
          (o === "i" || o === "I" || o === "s" || o === "S")
        )
          return `${r}="${t.slice(0, -2)}" ${o}`;
      }
      return `${r}="${t}"`;
    }
    return e;
  }
  function Lt(e, r) {
    K(e, (i, { replaceWith: t }) => {
      if (i.kind === "at-rule" && i.name === "@slot") t(r);
      else if (
        i.kind === "at-rule" &&
        (i.name === "@keyframes" || i.name === "@property")
      )
        return Object.assign(i, j([F(i.name, i.params, i.nodes)])), 1;
    });
  }
  function It(e, r) {
    let i = 0;
    return (
      K(e, (t, { replaceWith: o }) => {
        if (t.kind !== "at-rule" || t.name !== "@variant") return;
        let s = W("&", t.nodes),
          a = t.params,
          d = r.parseVariant(a);
        if (d === null)
          throw new Error(`Cannot use \`@variant\` with unknown variant: ${a}`);
        if (Ee(s, d, r.variants) === null)
          throw new Error(`Cannot use \`@variant\` with variant: ${a}`);
        o(s), (i |= 32);
      }),
      i
    );
  }
  function Fr(e) {
    let r = Or(e),
      i = jr(e),
      t = new B((u) => yr(u, d)),
      o = new B((u) => Array.from(br(u, d))),
      s = new B(
        (u) =>
          new B((c) => {
            let m = Mr(c, d, u);
            try {
              Ve(
                m.map(({ node: g }) => g),
                d
              );
            } catch {
              return [];
            }
            return m;
          })
      ),
      a = new B((u) => {
        for (let c of Qe(u)) e.markUsedVariable(c);
      }),
      d = {
        theme: e,
        utilities: r,
        variants: i,
        invalidCandidates: new Set(),
        important: !1,
        candidatesToCss(u) {
          let c = [];
          for (let m of u) {
            let g = !1,
              { astNodes: p } = he([m], this, {
                onInvalidCandidate() {
                  g = !0;
                },
              });
            (p = be(p, d, 0)),
              p.length === 0 || g ? c.push(null) : c.push(ne(p));
          }
          return c;
        },
        getClassOrder(u) {
          return Lr(this, u);
        },
        getClassList() {
          return zr(this);
        },
        getVariants() {
          return Kr(this);
        },
        parseCandidate(u) {
          return o.get(u);
        },
        parseVariant(u) {
          return t.get(u);
        },
        compileAstNodes(u, c = 1) {
          return s.get(c).get(u);
        },
        printCandidate(u) {
          return Ar(d, u);
        },
        printVariant(u) {
          return rt(u);
        },
        getVariantOrder() {
          let u = Array.from(t.values());
          u.sort((p, v) => this.variants.compare(p, v));
          let c = new Map(),
            m,
            g = 0;
          for (let p of u)
            p !== null &&
              (m !== void 0 && this.variants.compare(m, p) !== 0 && g++,
              c.set(p, g),
              (m = p));
          return c;
        },
        resolveThemeValue(u, c = !0) {
          let m = u.lastIndexOf("/"),
            g = null;
          m !== -1 && ((g = u.slice(m + 1).trim()), (u = u.slice(0, m).trim()));
          let p = e.resolve(null, [u], c ? 1 : 0) ?? void 0;
          return g && p ? Q(p, g) : p;
        },
        trackUsedVariables(u) {
          a.get(u);
        },
      };
    return d;
  }
  var jt = [
    "container-type",
    "pointer-events",
    "visibility",
    "position",
    "inset",
    "inset-inline",
    "inset-block",
    "inset-inline-start",
    "inset-inline-end",
    "top",
    "right",
    "bottom",
    "left",
    "isolation",
    "z-index",
    "order",
    "grid-column",
    "grid-column-start",
    "grid-column-end",
    "grid-row",
    "grid-row-start",
    "grid-row-end",
    "float",
    "clear",
    "--tw-container-component",
    "margin",
    "margin-inline",
    "margin-block",
    "margin-inline-start",
    "margin-inline-end",
    "margin-top",
    "margin-right",
    "margin-bottom",
    "margin-left",
    "box-sizing",
    "display",
    "field-sizing",
    "aspect-ratio",
    "height",
    "max-height",
    "min-height",
    "width",
    "max-width",
    "min-width",
    "flex",
    "flex-shrink",
    "flex-grow",
    "flex-basis",
    "table-layout",
    "caption-side",
    "border-collapse",
    "border-spacing",
    "transform-origin",
    "translate",
    "--tw-translate-x",
    "--tw-translate-y",
    "--tw-translate-z",
    "scale",
    "--tw-scale-x",
    "--tw-scale-y",
    "--tw-scale-z",
    "rotate",
    "--tw-rotate-x",
    "--tw-rotate-y",
    "--tw-rotate-z",
    "--tw-skew-x",
    "--tw-skew-y",
    "transform",
    "animation",
    "cursor",
    "touch-action",
    "--tw-pan-x",
    "--tw-pan-y",
    "--tw-pinch-zoom",
    "resize",
    "scroll-snap-type",
    "--tw-scroll-snap-strictness",
    "scroll-snap-align",
    "scroll-snap-stop",
    "scroll-margin",
    "scroll-margin-inline",
    "scroll-margin-block",
    "scroll-margin-inline-start",
    "scroll-margin-inline-end",
    "scroll-margin-top",
    "scroll-margin-right",
    "scroll-margin-bottom",
    "scroll-margin-left",
    "scroll-padding",
    "scroll-padding-inline",
    "scroll-padding-block",
    "scroll-padding-inline-start",
    "scroll-padding-inline-end",
    "scroll-padding-top",
    "scroll-padding-right",
    "scroll-padding-bottom",
    "scroll-padding-left",
    "list-style-position",
    "list-style-type",
    "list-style-image",
    "appearance",
    "columns",
    "break-before",
    "break-inside",
    "break-after",
    "grid-auto-columns",
    "grid-auto-flow",
    "grid-auto-rows",
    "grid-template-columns",
    "grid-template-rows",
    "flex-direction",
    "flex-wrap",
    "place-content",
    "place-items",
    "align-content",
    "align-items",
    "justify-content",
    "justify-items",
    "gap",
    "column-gap",
    "row-gap",
    "--tw-space-x-reverse",
    "--tw-space-y-reverse",
    "divide-x-width",
    "divide-y-width",
    "--tw-divide-y-reverse",
    "divide-style",
    "divide-color",
    "place-self",
    "align-self",
    "justify-self",
    "overflow",
    "overflow-x",
    "overflow-y",
    "overscroll-behavior",
    "overscroll-behavior-x",
    "overscroll-behavior-y",
    "scroll-behavior",
    "border-radius",
    "border-start-radius",
    "border-end-radius",
    "border-top-radius",
    "border-right-radius",
    "border-bottom-radius",
    "border-left-radius",
    "border-start-start-radius",
    "border-start-end-radius",
    "border-end-end-radius",
    "border-end-start-radius",
    "border-top-left-radius",
    "border-top-right-radius",
    "border-bottom-right-radius",
    "border-bottom-left-radius",
    "border-width",
    "border-inline-width",
    "border-block-width",
    "border-inline-start-width",
    "border-inline-end-width",
    "border-top-width",
    "border-right-width",
    "border-bottom-width",
    "border-left-width",
    "border-style",
    "border-inline-style",
    "border-block-style",
    "border-inline-start-style",
    "border-inline-end-style",
    "border-top-style",
    "border-right-style",
    "border-bottom-style",
    "border-left-style",
    "border-color",
    "border-inline-color",
    "border-block-color",
    "border-inline-start-color",
    "border-inline-end-color",
    "border-top-color",
    "border-right-color",
    "border-bottom-color",
    "border-left-color",
    "background-color",
    "background-image",
    "--tw-gradient-position",
    "--tw-gradient-stops",
    "--tw-gradient-via-stops",
    "--tw-gradient-from",
    "--tw-gradient-from-position",
    "--tw-gradient-via",
    "--tw-gradient-via-position",
    "--tw-gradient-to",
    "--tw-gradient-to-position",
    "mask-image",
    "--tw-mask-top",
    "--tw-mask-top-from-color",
    "--tw-mask-top-from-position",
    "--tw-mask-top-to-color",
    "--tw-mask-top-to-position",
    "--tw-mask-right",
    "--tw-mask-right-from-color",
    "--tw-mask-right-from-position",
    "--tw-mask-right-to-color",
    "--tw-mask-right-to-position",
    "--tw-mask-bottom",
    "--tw-mask-bottom-from-color",
    "--tw-mask-bottom-from-position",
    "--tw-mask-bottom-to-color",
    "--tw-mask-bottom-to-position",
    "--tw-mask-left",
    "--tw-mask-left-from-color",
    "--tw-mask-left-from-position",
    "--tw-mask-left-to-color",
    "--tw-mask-left-to-position",
    "--tw-mask-linear",
    "--tw-mask-linear-position",
    "--tw-mask-linear-from-color",
    "--tw-mask-linear-from-position",
    "--tw-mask-linear-to-color",
    "--tw-mask-linear-to-position",
    "--tw-mask-radial",
    "--tw-mask-radial-shape",
    "--tw-mask-radial-size",
    "--tw-mask-radial-position",
    "--tw-mask-radial-from-color",
    "--tw-mask-radial-from-position",
    "--tw-mask-radial-to-color",
    "--tw-mask-radial-to-position",
    "--tw-mask-conic",
    "--tw-mask-conic-position",
    "--tw-mask-conic-from-color",
    "--tw-mask-conic-from-position",
    "--tw-mask-conic-to-color",
    "--tw-mask-conic-to-position",
    "box-decoration-break",
    "background-size",
    "background-attachment",
    "background-clip",
    "background-position",
    "background-repeat",
    "background-origin",
    "mask-composite",
    "mask-mode",
    "mask-type",
    "mask-size",
    "mask-clip",
    "mask-position",
    "mask-repeat",
    "mask-origin",
    "fill",
    "stroke",
    "stroke-width",
    "object-fit",
    "object-position",
    "padding",
    "padding-inline",
    "padding-block",
    "padding-inline-start",
    "padding-inline-end",
    "padding-top",
    "padding-right",
    "padding-bottom",
    "padding-left",
    "text-align",
    "text-indent",
    "vertical-align",
    "font-family",
    "font-size",
    "line-height",
    "font-weight",
    "letter-spacing",
    "text-wrap",
    "overflow-wrap",
    "word-break",
    "text-overflow",
    "hyphens",
    "white-space",
    "color",
    "text-transform",
    "font-style",
    "font-stretch",
    "font-variant-numeric",
    "text-decoration-line",
    "text-decoration-color",
    "text-decoration-style",
    "text-decoration-thickness",
    "text-underline-offset",
    "-webkit-font-smoothing",
    "placeholder-color",
    "caret-color",
    "accent-color",
    "color-scheme",
    "opacity",
    "background-blend-mode",
    "mix-blend-mode",
    "box-shadow",
    "--tw-shadow",
    "--tw-shadow-color",
    "--tw-ring-shadow",
    "--tw-ring-color",
    "--tw-inset-shadow",
    "--tw-inset-shadow-color",
    "--tw-inset-ring-shadow",
    "--tw-inset-ring-color",
    "--tw-ring-offset-width",
    "--tw-ring-offset-color",
    "outline",
    "outline-width",
    "outline-offset",
    "outline-color",
    "--tw-blur",
    "--tw-brightness",
    "--tw-contrast",
    "--tw-drop-shadow",
    "--tw-grayscale",
    "--tw-hue-rotate",
    "--tw-invert",
    "--tw-saturate",
    "--tw-sepia",
    "filter",
    "--tw-backdrop-blur",
    "--tw-backdrop-brightness",
    "--tw-backdrop-contrast",
    "--tw-backdrop-grayscale",
    "--tw-backdrop-hue-rotate",
    "--tw-backdrop-invert",
    "--tw-backdrop-opacity",
    "--tw-backdrop-saturate",
    "--tw-backdrop-sepia",
    "backdrop-filter",
    "transition-property",
    "transition-behavior",
    "transition-delay",
    "transition-duration",
    "transition-timing-function",
    "will-change",
    "contain",
    "content",
    "forced-color-adjust",
  ];
  function he(e, r, { onInvalidCandidate: i, respectImportant: t } = {}) {
    let o = new Map(),
      s = [],
      a = new Map();
    for (let c of e) {
      if (r.invalidCandidates.has(c)) {
        i?.(c);
        continue;
      }
      let m = r.parseCandidate(c);
      if (m.length === 0) {
        i?.(c);
        continue;
      }
      a.set(c, m);
    }
    let d = 0;
    (t ?? !0) && (d |= 1);
    let u = r.getVariantOrder();
    for (let [c, m] of a) {
      let g = !1;
      for (let p of m) {
        let v = r.compileAstNodes(p, d);
        if (v.length !== 0) {
          g = !0;
          for (let { node: k, propertySort: w } of v) {
            let x = 0n;
            for (let V of p.variants) x |= 1n << BigInt(u.get(V));
            o.set(k, { properties: w, variants: x, candidate: c }), s.push(k);
          }
        }
      }
      g || i?.(c);
    }
    return (
      s.sort((c, m) => {
        let g = o.get(c),
          p = o.get(m);
        if (g.variants - p.variants !== 0n)
          return Number(g.variants - p.variants);
        let v = 0;
        for (
          ;
          v < g.properties.order.length &&
          v < p.properties.order.length &&
          g.properties.order[v] === p.properties.order[v];

        )
          v += 1;
        return (
          (g.properties.order[v] ?? 1 / 0) - (p.properties.order[v] ?? 1 / 0) ||
          p.properties.count - g.properties.count ||
          st(g.candidate, p.candidate)
        );
      }),
      { astNodes: s, nodeSorting: o }
    );
  }
  function Mr(e, r, i) {
    let t = jo(e, r);
    if (t.length === 0) return [];
    let o = r.important && !!(i & 1),
      s = [],
      a = `.${me(e.raw)}`;
    for (let d of t) {
      let u = Fo(d);
      (e.important || o) && Wr(d);
      let c = { kind: "rule", selector: a, nodes: d };
      for (let m of e.variants) if (Ee(c, m, r.variants) === null) return [];
      s.push({ node: c, propertySort: u });
    }
    return s;
  }
  function Ee(e, r, i, t = 0) {
    if (r.kind === "arbitrary") {
      if (r.relative && t === 0) return null;
      e.nodes = [Y(r.selector, e.nodes)];
      return;
    }
    let { applyFn: o } = i.get(r.root);
    if (r.kind === "compound") {
      let a = F("@slot");
      if (
        Ee(a, r.variant, i, t + 1) === null ||
        (r.root === "not" && a.nodes.length > 1)
      )
        return null;
      for (let u of a.nodes)
        if ((u.kind !== "rule" && u.kind !== "at-rule") || o(u, r) === null)
          return null;
      K(a.nodes, (u) => {
        if ((u.kind === "rule" || u.kind === "at-rule") && u.nodes.length <= 0)
          return (u.nodes = e.nodes), 1;
      }),
        (e.nodes = a.nodes);
      return;
    }
    if (o(e, r) === null) return null;
  }
  function Br(e) {
    let r = e.options?.types ?? [];
    return r.length > 1 && r.includes("any");
  }
  function jo(e, r) {
    if (e.kind === "arbitrary") {
      let a = e.value;
      return (
        e.modifier && (a = X(a, e.modifier, r.theme)),
        a === null ? [] : [[n(e.property, a)]]
      );
    }
    let i = r.utilities.get(e.root) ?? [],
      t = [],
      o = i.filter((a) => !Br(a));
    for (let a of o) {
      if (a.kind !== e.kind) continue;
      let d = a.compileFn(e);
      if (d !== void 0) {
        if (d === null) return t;
        t.push(d);
      }
    }
    if (t.length > 0) return t;
    let s = i.filter((a) => Br(a));
    for (let a of s) {
      if (a.kind !== e.kind) continue;
      let d = a.compileFn(e);
      if (d !== void 0) {
        if (d === null) return t;
        t.push(d);
      }
    }
    return t;
  }
  function Wr(e) {
    for (let r of e)
      r.kind !== "at-root" &&
        (r.kind === "declaration"
          ? (r.important = !0)
          : (r.kind === "rule" || r.kind === "at-rule") && Wr(r.nodes));
  }
  function Fo(e) {
    let r = new Set(),
      i = 0,
      t = e.slice(),
      o = !1;
    for (; t.length > 0; ) {
      let s = t.shift();
      if (s.kind === "declaration") {
        if (s.value === void 0 || (i++, o)) continue;
        if (s.property === "--tw-sort") {
          let d = jt.indexOf(s.value ?? "");
          if (d !== -1) {
            r.add(d), (o = !0);
            continue;
          }
        }
        let a = jt.indexOf(s.property);
        a !== -1 && r.add(a);
      } else if (s.kind === "rule" || s.kind === "at-rule")
        for (let a of s.nodes) t.push(a);
    }
    return { order: Array.from(r).sort((s, a) => s - a), count: i };
  }
  function Le(e, r) {
    let i = 0,
      t = Y("&", e),
      o = new Set(),
      s = new B(() => new Set()),
      a = new B(() => new Set());
    K([t], (g, { parent: p, path: v }) => {
      if (g.kind === "at-rule") {
        if (g.name === "@keyframes")
          return (
            K(g.nodes, (k) => {
              if (k.kind === "at-rule" && k.name === "@apply")
                throw new Error("You cannot use `@apply` inside `@keyframes`.");
            }),
            1
          );
        if (g.name === "@utility") {
          let k = g.params.replace(/-\*$/, "");
          a.get(k).add(g),
            K(g.nodes, (w) => {
              if (!(w.kind !== "at-rule" || w.name !== "@apply")) {
                o.add(g);
                for (let x of qr(w, r)) s.get(g).add(x);
              }
            });
          return;
        }
        if (g.name === "@apply") {
          if (p === null) return;
          (i |= 1), o.add(p);
          for (let k of qr(g, r))
            for (let w of v) w !== g && o.has(w) && s.get(w).add(k);
        }
      }
    });
    let d = new Set(),
      u = [],
      c = new Set();
    function m(g, p = []) {
      if (!d.has(g)) {
        if (c.has(g)) {
          let v = p[(p.indexOf(g) + 1) % p.length];
          throw (
            (g.kind === "at-rule" &&
              g.name === "@utility" &&
              v.kind === "at-rule" &&
              v.name === "@utility" &&
              K(g.nodes, (k) => {
                if (k.kind !== "at-rule" || k.name !== "@apply") return;
                let w = k.params.split(/\s+/g);
                for (let x of w)
                  for (let V of r.parseCandidate(x))
                    switch (V.kind) {
                      case "arbitrary":
                        break;
                      case "static":
                      case "functional":
                        if (v.params.replace(/-\*$/, "") === V.root)
                          throw new Error(
                            `You cannot \`@apply\` the \`${x}\` utility here because it creates a circular dependency.`
                          );
                        break;
                      default:
                    }
              }),
            new Error(`Circular dependency detected:

${ne([g])}
Relies on:

${ne([v])}`))
          );
        }
        c.add(g);
        for (let v of s.get(g))
          for (let k of a.get(v)) p.push(g), m(k, p), p.pop();
        d.add(g), c.delete(g), u.push(g);
      }
    }
    for (let g of o) m(g);
    for (let g of u)
      "nodes" in g &&
        K(g.nodes, (p, { replaceWith: v }) => {
          if (p.kind !== "at-rule" || p.name !== "@apply") return;
          let k = p.params.split(/(\s+)/g),
            w = {},
            x = 0;
          for (let [V, C] of k.entries())
            V % 2 === 0 && (w[C] = x), (x += C.length);
          {
            let V = Object.keys(w),
              C = he(V, r, {
                respectImportant: !1,
                onInvalidCandidate: (D) => {
                  if (r.theme.prefix && !D.startsWith(r.theme.prefix))
                    throw new Error(
                      `Cannot apply unprefixed utility class \`${D}\`. Did you mean \`${r.theme.prefix}:${D}\`?`
                    );
                  if (r.invalidCandidates.has(D))
                    throw new Error(
                      `Cannot apply utility class \`${D}\` because it has been explicitly disabled: https://tailwindcss.com/docs/detecting-classes-in-source-files#explicitly-excluding-classes`
                    );
                  let U = z(D, ":");
                  if (U.length > 1) {
                    let H = U.pop();
                    if (r.candidatesToCss([H])[0]) {
                      let O = r.candidatesToCss(
                          U.map((q) => `${q}:[--tw-variant-check:1]`)
                        ),
                        L = U.filter((q, M) => O[M] === null);
                      if (L.length > 0) {
                        if (L.length === 1)
                          throw new Error(
                            `Cannot apply utility class \`${D}\` because the ${L.map(
                              (q) => `\`${q}\``
                            )} variant does not exist.`
                          );
                        {
                          let q = new Intl.ListFormat("en", {
                            style: "long",
                            type: "conjunction",
                          });
                          throw new Error(
                            `Cannot apply utility class \`${D}\` because the ${q.format(
                              L.map((M) => `\`${M}\``)
                            )} variants do not exist.`
                          );
                        }
                      }
                    }
                  }
                  throw r.theme.size === 0
                    ? new Error(
                        `Cannot apply unknown utility class \`${D}\`. Are you using CSS modules or similar and missing \`@reference\`? https://tailwindcss.com/docs/functions-and-directives#reference-directive`
                      )
                    : new Error(`Cannot apply unknown utility class \`${D}\``);
                },
              }),
              y = p.src,
              _ = C.astNodes.map((D) => {
                let U = C.nodeSorting.get(D)?.candidate,
                  H = U ? w[U] : void 0;
                if (((D = structuredClone(D)), !y || !U || H === void 0))
                  return (
                    K([D], (L) => {
                      L.src = y;
                    }),
                    D
                  );
                let O = [y[0], y[1], y[2]];
                return (
                  (O[1] += 7 + H),
                  (O[2] = O[1] + U.length),
                  K([D], (L) => {
                    L.src = O;
                  }),
                  D
                );
              }),
              R = [];
            for (let D of _)
              if (D.kind === "rule") for (let U of D.nodes) R.push(U);
              else R.push(D);
            v(R);
          }
        });
    return i;
  }
  function* qr(e, r) {
    for (let i of e.params.split(/\s+/g))
      for (let t of r.parseCandidate(i))
        switch (t.kind) {
          case "arbitrary":
            break;
          case "static":
          case "functional":
            yield t.root;
            break;
          default:
        }
  }
  async function Ft(e, r, i, t = 0, o = !1) {
    let s = 0,
      a = [];
    return (
      K(e, (d, { replaceWith: u }) => {
        if (
          d.kind === "at-rule" &&
          (d.name === "@import" || d.name === "@reference")
        ) {
          let c = Mo(G(d.params));
          if (c === null) return;
          d.name === "@reference" && (c.media = "reference"), (s |= 2);
          let { uri: m, layer: g, media: p, supports: v } = c;
          if (
            m.startsWith("data:") ||
            m.startsWith("http://") ||
            m.startsWith("https://")
          )
            return;
          let k = ue({}, []);
          return (
            a.push(
              (async () => {
                if (t > 100)
                  throw new Error(
                    `Exceeded maximum recursion depth while resolving \`${m}\` in \`${r}\`)`
                  );
                let w = await i(m, r),
                  x = Se(w.content, { from: o ? w.path : void 0 });
                await Ft(x, w.base, i, t + 1, o),
                  (k.nodes = Bo(d, [ue({ base: w.base }, x)], g, p, v));
              })()
            ),
            u(k),
            1
          );
        }
      }),
      a.length > 0 && (await Promise.all(a)),
      s
    );
  }
  function Mo(e) {
    let r,
      i = null,
      t = null,
      o = null;
    for (let s = 0; s < e.length; s++) {
      let a = e[s];
      if (a.kind !== "separator") {
        if (a.kind === "word" && !r) {
          if (!a.value || (a.value[0] !== '"' && a.value[0] !== "'"))
            return null;
          r = a.value.slice(1, -1);
          continue;
        }
        if ((a.kind === "function" && a.value.toLowerCase() === "url") || !r)
          return null;
        if (
          (a.kind === "word" || a.kind === "function") &&
          a.value.toLowerCase() === "layer"
        ) {
          if (i) return null;
          if (o)
            throw new Error(
              "`layer(\u2026)` in an `@import` should come before any other functions or conditions"
            );
          "nodes" in a ? (i = J(a.nodes)) : (i = "");
          continue;
        }
        if (a.kind === "function" && a.value.toLowerCase() === "supports") {
          if (o) return null;
          o = J(a.nodes);
          continue;
        }
        t = J(e.slice(s));
        break;
      }
    }
    return r ? { uri: r, layer: i, media: t, supports: o } : null;
  }
  function Bo(e, r, i, t, o) {
    let s = r;
    if (i !== null) {
      let a = F("@layer", i, s);
      (a.src = e.src), (s = [a]);
    }
    if (t !== null) {
      let a = F("@media", t, s);
      (a.src = e.src), (s = [a]);
    }
    if (o !== null) {
      let a = F("@supports", o[0] === "(" ? o : `(${o})`, s);
      (a.src = e.src), (s = [a]);
    }
    return s;
  }
  function Te(e, r = null) {
    return Array.isArray(e) &&
      e.length === 2 &&
      typeof e[1] == "object" &&
      typeof e[1] !== null
      ? r
        ? e[1][r] ?? null
        : e[0]
      : Array.isArray(e) && r === null
      ? e.join(", ")
      : typeof e == "string" && r === null
      ? e
      : null;
  }
  function Hr(e, { theme: r }, i) {
    for (let t of i) {
      let o = ct([t]);
      o && e.theme.clearNamespace(`--${o}`, 4);
    }
    for (let [t, o] of Wo(r)) {
      if (typeof o != "string" && typeof o != "number") continue;
      if (
        (typeof o == "string" && (o = o.replace(/<alpha-value>/g, "1")),
        t[0] === "opacity" && (typeof o == "number" || typeof o == "string"))
      ) {
        let a = typeof o == "string" ? parseFloat(o) : o;
        a >= 0 && a <= 1 && (o = a * 100 + "%");
      }
      let s = ct(t);
      s && e.theme.add(`--${s}`, "" + o, 7);
    }
    if (Object.hasOwn(r, "fontFamily")) {
      let t = 5;
      {
        let o = Te(r.fontFamily.sans);
        o &&
          e.theme.hasDefault("--font-sans") &&
          (e.theme.add("--default-font-family", o, t),
          e.theme.add(
            "--default-font-feature-settings",
            Te(r.fontFamily.sans, "fontFeatureSettings") ?? "normal",
            t
          ),
          e.theme.add(
            "--default-font-variation-settings",
            Te(r.fontFamily.sans, "fontVariationSettings") ?? "normal",
            t
          ));
      }
      {
        let o = Te(r.fontFamily.mono);
        o &&
          e.theme.hasDefault("--font-mono") &&
          (e.theme.add("--default-mono-font-family", o, t),
          e.theme.add(
            "--default-mono-font-feature-settings",
            Te(r.fontFamily.mono, "fontFeatureSettings") ?? "normal",
            t
          ),
          e.theme.add(
            "--default-mono-font-variation-settings",
            Te(r.fontFamily.mono, "fontVariationSettings") ?? "normal",
            t
          ));
      }
    }
    return r;
  }
  function Wo(e) {
    let r = [];
    return (
      Gr(e, [], (i, t) => {
        if (Ho(i)) return r.push([t, i]), 1;
        if (Go(i)) {
          r.push([t, i[0]]);
          for (let o of Reflect.ownKeys(i[1]))
            r.push([[...t, `-${o}`], i[1][o]]);
          return 1;
        }
        if (Array.isArray(i) && i.every((o) => typeof o == "string"))
          return (
            t[0] === "fontSize"
              ? (r.push([t, i[0]]),
                i.length >= 2 && r.push([[...t, "-line-height"], i[1]]))
              : r.push([t, i.join(", ")]),
            1
          );
      }),
      r
    );
  }
  var qo = /^[a-zA-Z0-9-_%/\.]+$/;
  function ct(e) {
    if (e[0] === "container") return null;
    (e = structuredClone(e)),
      e[0] === "animation" && (e[0] = "animate"),
      e[0] === "aspectRatio" && (e[0] = "aspect"),
      e[0] === "borderRadius" && (e[0] = "radius"),
      e[0] === "boxShadow" && (e[0] = "shadow"),
      e[0] === "colors" && (e[0] = "color"),
      e[0] === "containers" && (e[0] = "container"),
      e[0] === "fontFamily" && (e[0] = "font"),
      e[0] === "fontSize" && (e[0] = "text"),
      e[0] === "letterSpacing" && (e[0] = "tracking"),
      e[0] === "lineHeight" && (e[0] = "leading"),
      e[0] === "maxWidth" && (e[0] = "container"),
      e[0] === "screens" && (e[0] = "breakpoint"),
      e[0] === "transitionTimingFunction" && (e[0] = "ease");
    for (let r of e) if (!qo.test(r)) return null;
    return e
      .map((r, i, t) => (r === "1" && i !== t.length - 1 ? "" : r))
      .map((r) =>
        r
          .replaceAll(".", "_")
          .replace(/([a-z])([A-Z])/g, (i, t, o) => `${t}-${o.toLowerCase()}`)
      )
      .filter((r, i) => r !== "DEFAULT" || i !== e.length - 1)
      .join("-");
  }
  function Ho(e) {
    return typeof e == "number" || typeof e == "string";
  }
  function Go(e) {
    if (
      !Array.isArray(e) ||
      e.length !== 2 ||
      (typeof e[0] != "string" && typeof e[0] != "number") ||
      e[1] === void 0 ||
      e[1] === null ||
      typeof e[1] != "object"
    )
      return !1;
    for (let r of Reflect.ownKeys(e[1]))
      if (
        typeof r != "string" ||
        (typeof e[1][r] != "string" && typeof e[1][r] != "number")
      )
        return !1;
    return !0;
  }
  function Gr(e, r = [], i) {
    for (let t of Reflect.ownKeys(e)) {
      let o = e[t];
      if (o == null) continue;
      let s = [...r, t],
        a = i(o, s) ?? 0;
      if (a !== 1) {
        if (a === 2) return 2;
        if (!(!Array.isArray(o) && typeof o != "object") && Gr(o, s, i) === 2)
          return 2;
      }
    }
  }
  function ft(e) {
    let r = [];
    for (let i of z(e, ".")) {
      if (!i.includes("[")) {
        r.push(i);
        continue;
      }
      let t = 0;
      for (;;) {
        let o = i.indexOf("[", t),
          s = i.indexOf("]", o);
        if (o === -1 || s === -1) break;
        o > t && r.push(i.slice(t, o)), r.push(i.slice(o + 1, s)), (t = s + 1);
      }
      t <= i.length - 1 && r.push(i.slice(t));
    }
    return r;
  }
  function Re(e) {
    if (Object.prototype.toString.call(e) !== "[object Object]") return !1;
    let r = Object.getPrototypeOf(e);
    return r === null || Object.getPrototypeOf(r) === null;
  }
  function Ie(e, r, i, t = []) {
    for (let o of r)
      if (o != null)
        for (let s of Reflect.ownKeys(o)) {
          t.push(s);
          let a = i(e[s], o[s], t);
          a !== void 0
            ? (e[s] = a)
            : !Re(e[s]) || !Re(o[s])
            ? (e[s] = o[s])
            : (e[s] = Ie({}, [e[s], o[s]], i, t)),
            t.pop();
        }
    return e;
  }
  function dt(e, r, i) {
    return function (o, s) {
      let a = o.lastIndexOf("/"),
        d = null;
      a !== -1 && ((d = o.slice(a + 1).trim()), (o = o.slice(0, a).trim()));
      let u = (() => {
        let c = ft(o),
          [m, g] = Yo(e.theme, c),
          p = i(Yr(r() ?? {}, c) ?? null);
        if (
          (typeof p == "string" && (p = p.replace("<alpha-value>", "1")),
          typeof m != "object")
        )
          return typeof g != "object" && g & 4 ? p ?? m : m;
        if (p !== null && typeof p == "object" && !Array.isArray(p)) {
          let v = Ie({}, [p], (k, w) => w);
          if (m === null && Object.hasOwn(p, "__CSS_VALUES__")) {
            let k = {};
            for (let w in p.__CSS_VALUES__) (k[w] = p[w]), delete v[w];
            m = k;
          }
          for (let k in m)
            k !== "__CSS_VALUES__" &&
              ((p?.__CSS_VALUES__?.[k] & 4 && Yr(v, k.split("-")) !== void 0) ||
                (v[ve(k)] = m[k]));
          return v;
        }
        if (Array.isArray(m) && Array.isArray(g) && Array.isArray(p)) {
          let v = m[0],
            k = m[1];
          g[0] & 4 && (v = p[0] ?? v);
          for (let w of Object.keys(k)) g[1][w] & 4 && (k[w] = p[1][w] ?? k[w]);
          return [v, k];
        }
        return m ?? p;
      })();
      return d && typeof u == "string" && (u = Q(u, d)), u ?? s;
    };
  }
  function Yo(e, r) {
    if (r.length === 1 && r[0].startsWith("--"))
      return [e.get([r[0]]), e.getOptions(r[0])];
    let i = ct(r),
      t = new Map(),
      o = new B(() => new Map()),
      s = e.namespace(`--${i}`);
    if (s.size === 0) return [null, 0];
    let a = new Map();
    for (let [m, g] of s) {
      if (!m || !m.includes("--")) {
        t.set(m, g), a.set(m, e.getOptions(m ? `--${i}-${m}` : `--${i}`));
        continue;
      }
      let p = m.indexOf("--"),
        v = m.slice(0, p),
        k = m.slice(p + 2);
      (k = k.replace(/-([a-z])/g, (w, x) => x.toUpperCase())),
        o.get(v === "" ? null : v).set(k, [g, e.getOptions(`--${i}${m}`)]);
    }
    let d = e.getOptions(`--${i}`);
    for (let [m, g] of o) {
      let p = t.get(m);
      if (typeof p != "string") continue;
      let v = {},
        k = {};
      for (let [w, [x, V]] of g) (v[w] = x), (k[w] = V);
      t.set(m, [p, v]), a.set(m, [d, k]);
    }
    let u = {},
      c = {};
    for (let [m, g] of t) Zr(u, [m ?? "DEFAULT"], g);
    for (let [m, g] of a) Zr(c, [m ?? "DEFAULT"], g);
    return r[r.length - 1] === "DEFAULT"
      ? [u?.DEFAULT ?? null, c.DEFAULT ?? 0]
      : "DEFAULT" in u && Object.keys(u).length === 1
      ? [u.DEFAULT, c.DEFAULT ?? 0]
      : ((u.__CSS_VALUES__ = c), [u, c]);
  }
  function Yr(e, r) {
    for (let i = 0; i < r.length; ++i) {
      let t = r[i];
      if (e?.[t] === void 0) {
        if (r[i + 1] === void 0) return;
        r[i + 1] = `${t}-${r[i + 1]}`;
        continue;
      }
      e = e[t];
    }
    return e;
  }
  function Zr(e, r, i) {
    for (let t of r.slice(0, -1)) e[t] === void 0 && (e[t] = {}), (e = e[t]);
    e[r[r.length - 1]] = i;
  }
  function Zo(e) {
    return { kind: "combinator", value: e };
  }
  function Jo(e, r) {
    return { kind: "function", value: e, nodes: r };
  }
  function je(e) {
    return { kind: "selector", value: e };
  }
  function Qo(e) {
    return { kind: "separator", value: e };
  }
  function Xo(e) {
    return { kind: "value", value: e };
  }
  function Fe(e, r, i = null) {
    for (let t = 0; t < e.length; t++) {
      let o = e[t],
        s = !1,
        a = 0,
        d =
          r(o, {
            parent: i,
            replaceWith(u) {
              s ||
                ((s = !0),
                Array.isArray(u)
                  ? u.length === 0
                    ? (e.splice(t, 1), (a = 0))
                    : u.length === 1
                    ? ((e[t] = u[0]), (a = 1))
                    : (e.splice(t, 1, ...u), (a = u.length))
                  : ((e[t] = u), (a = 1)));
            },
          }) ?? 0;
      if (s) {
        d === 0 ? t-- : (t += a - 1);
        continue;
      }
      if (d === 2) return 2;
      if (d !== 1 && o.kind === "function" && Fe(o.nodes, r, o) === 2) return 2;
    }
  }
  function Me(e) {
    let r = "";
    for (let i of e)
      switch (i.kind) {
        case "combinator":
        case "selector":
        case "separator":
        case "value": {
          r += i.value;
          break;
        }
        case "function":
          r += i.value + "(" + Me(i.nodes) + ")";
      }
    return r;
  }
  var Jr = 92,
    en = 93,
    Qr = 41,
    tn = 58,
    Xr = 44,
    rn = 34,
    on = 46,
    ei = 62,
    ti = 10,
    nn = 35,
    ri = 91,
    ii = 40,
    oi = 43,
    ln = 39,
    ni = 32,
    li = 9,
    ai = 126;
  function pt(e) {
    e = e.replaceAll(
      `\r
`,
      `
`
    );
    let r = [],
      i = [],
      t = null,
      o = "",
      s;
    for (let a = 0; a < e.length; a++) {
      let d = e.charCodeAt(a);
      switch (d) {
        case Xr:
        case ei:
        case ti:
        case ni:
        case oi:
        case li:
        case ai: {
          if (o.length > 0) {
            let p = je(o);
            t ? t.nodes.push(p) : r.push(p), (o = "");
          }
          let u = a,
            c = a + 1;
          for (
            ;
            c < e.length &&
            ((s = e.charCodeAt(c)),
            !(
              s !== Xr &&
              s !== ei &&
              s !== ti &&
              s !== ni &&
              s !== oi &&
              s !== li &&
              s !== ai
            ));
            c++
          );
          a = c - 1;
          let m = e.slice(u, c),
            g = m.trim() === "," ? Qo(m) : Zo(m);
          t ? t.nodes.push(g) : r.push(g);
          break;
        }
        case ii: {
          let u = Jo(o, []);
          if (
            ((o = ""),
            u.value !== ":not" &&
              u.value !== ":where" &&
              u.value !== ":has" &&
              u.value !== ":is")
          ) {
            let c = a + 1,
              m = 0;
            for (let p = a + 1; p < e.length; p++) {
              if (((s = e.charCodeAt(p)), s === ii)) {
                m++;
                continue;
              }
              if (s === Qr) {
                if (m === 0) {
                  a = p;
                  break;
                }
                m--;
              }
            }
            let g = a;
            u.nodes.push(Xo(e.slice(c, g))),
              (o = ""),
              (a = g),
              t ? t.nodes.push(u) : r.push(u);
            break;
          }
          t ? t.nodes.push(u) : r.push(u), i.push(u), (t = u);
          break;
        }
        case Qr: {
          let u = i.pop();
          if (o.length > 0) {
            let c = je(o);
            u.nodes.push(c), (o = "");
          }
          i.length > 0 ? (t = i[i.length - 1]) : (t = null);
          break;
        }
        case on:
        case tn:
        case nn: {
          if (o.length > 0) {
            let u = je(o);
            t ? t.nodes.push(u) : r.push(u);
          }
          o = String.fromCharCode(d);
          break;
        }
        case ri: {
          if (o.length > 0) {
            let m = je(o);
            t ? t.nodes.push(m) : r.push(m);
          }
          o = "";
          let u = a,
            c = 0;
          for (let m = a + 1; m < e.length; m++) {
            if (((s = e.charCodeAt(m)), s === ri)) {
              c++;
              continue;
            }
            if (s === en) {
              if (c === 0) {
                a = m;
                break;
              }
              c--;
            }
          }
          o += e.slice(u, a + 1);
          break;
        }
        case ln:
        case rn: {
          let u = a;
          for (let c = a + 1; c < e.length; c++)
            if (((s = e.charCodeAt(c)), s === Jr)) c += 1;
            else if (s === d) {
              a = c;
              break;
            }
          o += e.slice(u, a + 1);
          break;
        }
        case Jr: {
          let u = e.charCodeAt(a + 1);
          (o += String.fromCharCode(d) + String.fromCharCode(u)), (a += 1);
          break;
        }
        default:
          o += String.fromCharCode(d);
      }
    }
    return o.length > 0 && r.push(je(o)), r;
  }
  var si = /^[a-z@][a-zA-Z0-9/%._-]*$/;
  function Mt({
    designSystem: e,
    ast: r,
    resolvedConfig: i,
    featuresRef: t,
    referenceMode: o,
    src: s,
  }) {
    let a = {
      addBase(d) {
        if (o) return;
        let u = ce(d);
        t.current |= Ve(u, e);
        let c = F("@layer", "base", u);
        K([c], (m) => {
          m.src = s;
        }),
          r.push(c);
      },
      addVariant(d, u) {
        if (!ut.test(d))
          throw new Error(
            `\`addVariant('${d}')\` defines an invalid variant name. Variants should only contain alphanumeric, dashes, or underscore characters and start with a lowercase letter or number.`
          );
        if (typeof u == "string") {
          if (u.includes(":merge(")) return;
        } else if (Array.isArray(u)) {
          if (u.some((m) => m.includes(":merge("))) return;
        } else if (typeof u == "object") {
          let m = function (g, p) {
            return Object.entries(g).some(
              ([v, k]) => v.includes(p) || (typeof k == "object" && m(k, p))
            );
          };
          var c = m;
          if (m(u, ":merge(")) return;
        }
        typeof u == "string" || Array.isArray(u)
          ? e.variants.static(
              d,
              (m) => {
                m.nodes = ui(u, m.nodes);
              },
              { compounds: Ae(typeof u == "string" ? [u] : u) }
            )
          : typeof u == "object" && e.variants.fromAst(d, ce(u), e);
      },
      matchVariant(d, u, c) {
        function m(p, v, k) {
          let w = u(p, { modifier: v?.value ?? null });
          return ui(w, k);
        }
        try {
          let p = u("a", { modifier: null });
          if (typeof p == "string" && p.includes(":merge(")) return;
          if (Array.isArray(p) && p.some((v) => v.includes(":merge("))) return;
        } catch {}
        let g = Object.keys(c?.values ?? {});
        e.variants.group(
          () => {
            e.variants.functional(d, (p, v) => {
              if (!v.value) {
                if (c?.values && "DEFAULT" in c.values) {
                  p.nodes = m(c.values.DEFAULT, v.modifier, p.nodes);
                  return;
                }
                return null;
              }
              if (v.value.kind === "arbitrary")
                p.nodes = m(v.value.value, v.modifier, p.nodes);
              else if (v.value.kind === "named" && c?.values) {
                let k = c.values[v.value.value];
                if (typeof k != "string") return null;
                p.nodes = m(k, v.modifier, p.nodes);
              } else return null;
            });
          },
          (p, v) => {
            if (p.kind !== "functional" || v.kind !== "functional") return 0;
            let k = p.value ? p.value.value : "DEFAULT",
              w = v.value ? v.value.value : "DEFAULT",
              x = c?.values?.[k] ?? k,
              V = c?.values?.[w] ?? w;
            if (c && typeof c.sort == "function")
              return c.sort(
                { value: x, modifier: p.modifier?.value ?? null },
                { value: V, modifier: v.modifier?.value ?? null }
              );
            let C = g.indexOf(k),
              y = g.indexOf(w);
            return (
              (C = C === -1 ? g.length : C),
              (y = y === -1 ? g.length : y),
              C !== y ? C - y : x < V ? -1 : 1
            );
          }
        ),
          e.variants.suggest(d, () =>
            Object.keys(c?.values ?? {}).filter((p) => p !== "DEFAULT")
          );
      },
      addUtilities(d) {
        d = Array.isArray(d) ? d : [d];
        let u = d.flatMap((m) => Object.entries(m));
        u = u.flatMap(([m, g]) => z(m, ",").map((p) => [p.trim(), g]));
        let c = new B(() => []);
        for (let [m, g] of u) {
          if (m.startsWith("@keyframes ")) {
            if (!o) {
              let k = Y(m, ce(g));
              K([k], (w) => {
                w.src = s;
              }),
                r.push(k);
            }
            continue;
          }
          let p = pt(m),
            v = !1;
          if (
            (Fe(p, (k) => {
              if (
                k.kind === "selector" &&
                k.value[0] === "." &&
                si.test(k.value.slice(1))
              ) {
                let w = k.value;
                k.value = "&";
                let x = Me(p),
                  V = w.slice(1),
                  C = x === "&" ? ce(g) : [Y(x, ce(g))];
                c.get(V).push(...C), (v = !0), (k.value = w);
                return;
              }
              if (k.kind === "function" && k.value === ":not") return 1;
            }),
            !v)
          )
            throw new Error(
              `\`addUtilities({ '${m}' : \u2026 })\` defines an invalid utility selector. Utilities must be a single class name and start with a lowercase letter, eg. \`.scrollbar-none\`.`
            );
        }
        for (let [m, g] of c)
          e.theme.prefix &&
            K(g, (p) => {
              if (p.kind === "rule") {
                let v = pt(p.selector);
                Fe(v, (k) => {
                  k.kind === "selector" &&
                    k.value[0] === "." &&
                    (k.value = `.${e.theme.prefix}\\:${k.value.slice(1)}`);
                }),
                  (p.selector = Me(v));
              }
            }),
            e.utilities.static(m, (p) => {
              let v = structuredClone(g);
              return ci(v, m, p.raw), (t.current |= Le(v, e)), v;
            });
      },
      matchUtilities(d, u) {
        let c = u?.type
          ? Array.isArray(u?.type)
            ? u.type
            : [u.type]
          : ["any"];
        for (let [g, p] of Object.entries(d)) {
          let v = function ({ negative: k }) {
            return (w) => {
              if (
                w.value?.kind === "arbitrary" &&
                c.length > 0 &&
                !c.includes("any") &&
                ((w.value.dataType && !c.includes(w.value.dataType)) ||
                  (!w.value.dataType && !Z(w.value.value, c)))
              )
                return;
              let x = c.includes("color"),
                V = null,
                C = !1;
              {
                let R = u?.values ?? {};
                x &&
                  (R = Object.assign(
                    {
                      inherit: "inherit",
                      transparent: "transparent",
                      current: "currentcolor",
                    },
                    R
                  )),
                  w.value
                    ? w.value.kind === "arbitrary"
                      ? (V = w.value.value)
                      : w.value.fraction && R[w.value.fraction]
                      ? ((V = R[w.value.fraction]), (C = !0))
                      : R[w.value.value]
                      ? (V = R[w.value.value])
                      : R.__BARE_VALUE__ &&
                        ((V = R.__BARE_VALUE__(w.value) ?? null),
                        (C =
                          (w.value.fraction !== null && V?.includes("/")) ??
                          !1))
                    : (V = R.DEFAULT ?? null);
              }
              if (V === null) return;
              let y;
              {
                let R = u?.modifiers ?? null;
                w.modifier
                  ? R === "any" || w.modifier.kind === "arbitrary"
                    ? (y = w.modifier.value)
                    : R?.[w.modifier.value]
                    ? (y = R[w.modifier.value])
                    : x && !Number.isNaN(Number(w.modifier.value))
                    ? (y = `${w.modifier.value}%`)
                    : (y = null)
                  : (y = null);
              }
              if (w.modifier && y === null && !C)
                return w.value?.kind === "arbitrary" ? null : void 0;
              x && y !== null && (V = Q(V, y)), k && (V = `calc(${V} * -1)`);
              let _ = ce(p(V, { modifier: y }));
              return ci(_, g, w.raw), (t.current |= Le(_, e)), _;
            };
          };
          var m = v;
          if (!si.test(g))
            throw new Error(
              `\`matchUtilities({ '${g}' : \u2026 })\` defines an invalid utility name. Utilities should be alphanumeric and start with a lowercase letter, eg. \`scrollbar\`.`
            );
          u?.supportsNegativeValues &&
            e.utilities.functional(`-${g}`, v({ negative: !0 }), { types: c }),
            e.utilities.functional(g, v({ negative: !1 }), { types: c }),
            e.utilities.suggest(g, () => {
              let k = u?.values ?? {},
                w = new Set(Object.keys(k));
              w.delete("__BARE_VALUE__"),
                w.delete("__CSS_VALUES__"),
                w.has("DEFAULT") && (w.delete("DEFAULT"), w.add(null));
              let x = u?.modifiers ?? {},
                V = x === "any" ? [] : Object.keys(x);
              return [
                {
                  supportsNegative: u?.supportsNegativeValues ?? !1,
                  values: Array.from(w),
                  modifiers: V,
                },
              ];
            });
        }
      },
      addComponents(d, u) {
        this.addUtilities(d, u);
      },
      matchComponents(d, u) {
        this.matchUtilities(d, u);
      },
      theme: dt(
        e,
        () => i.theme ?? {},
        (d) => d
      ),
      prefix(d) {
        return d;
      },
      config(d, u) {
        let c = i;
        if (!d) return c;
        let m = ft(d);
        for (let g = 0; g < m.length; ++g) {
          let p = m[g];
          if (c[p] === void 0) return u;
          c = c[p];
        }
        return c ?? u;
      },
    };
    return (
      (a.addComponents = a.addComponents.bind(a)),
      (a.matchComponents = a.matchComponents.bind(a)),
      a
    );
  }
  function ce(e) {
    let r = [];
    e = Array.isArray(e) ? e : [e];
    let i = e.flatMap((t) => Object.entries(t));
    for (let [t, o] of i)
      if (o != null && o !== !1)
        if (typeof o != "object") {
          if (!t.startsWith("--")) {
            if (o === "@slot") {
              r.push(Y(t, [F("@slot")]));
              continue;
            }
            t = t.replace(/([A-Z])/g, "-$1").toLowerCase();
          }
          r.push(n(t, String(o)));
        } else if (Array.isArray(o))
          for (let s of o)
            typeof s == "string" ? r.push(n(t, s)) : r.push(Y(t, ce(s)));
        else r.push(Y(t, ce(o)));
    return r;
  }
  function ui(e, r) {
    return (typeof e == "string" ? [e] : e).flatMap((t) => {
      if (t.trim().endsWith("}")) {
        let o = t.replace("}", "{@slot}}"),
          s = Se(o);
        return Lt(s, r), s;
      } else return Y(t, r);
    });
  }
  function ci(e, r, i) {
    K(e, (t) => {
      if (t.kind === "rule") {
        let o = pt(t.selector);
        Fe(o, (s) => {
          s.kind === "selector" &&
            s.value === `.${r}` &&
            (s.value = `.${me(i)}`);
        }),
          (t.selector = Me(o));
      }
    });
  }
  function fi(e, r, i) {
    for (let t of sn(r)) e.theme.addKeyframes(t);
  }
  function sn(e) {
    let r = [];
    if ("keyframes" in e.theme)
      for (let [i, t] of Object.entries(e.theme.keyframes))
        r.push(F("@keyframes", i, ce(t)));
    return r;
  }
  var mt = {
    inherit: "inherit",
    current: "currentcolor",
    transparent: "transparent",
    black: "#000",
    white: "#fff",
    slate: {
      50: "oklch(98.4% 0.003 247.858)",
      100: "oklch(96.8% 0.007 247.896)",
      200: "oklch(92.9% 0.013 255.508)",
      300: "oklch(86.9% 0.022 252.894)",
      400: "oklch(70.4% 0.04 256.788)",
      500: "oklch(55.4% 0.046 257.417)",
      600: "oklch(44.6% 0.043 257.281)",
      700: "oklch(37.2% 0.044 257.287)",
      800: "oklch(27.9% 0.041 260.031)",
      900: "oklch(20.8% 0.042 265.755)",
      950: "oklch(12.9% 0.042 264.695)",
    },
    gray: {
      50: "oklch(98.5% 0.002 247.839)",
      100: "oklch(96.7% 0.003 264.542)",
      200: "oklch(92.8% 0.006 264.531)",
      300: "oklch(87.2% 0.01 258.338)",
      400: "oklch(70.7% 0.022 261.325)",
      500: "oklch(55.1% 0.027 264.364)",
      600: "oklch(44.6% 0.03 256.802)",
      700: "oklch(37.3% 0.034 259.733)",
      800: "oklch(27.8% 0.033 256.848)",
      900: "oklch(21% 0.034 264.665)",
      950: "oklch(13% 0.028 261.692)",
    },
    zinc: {
      50: "oklch(98.5% 0 0)",
      100: "oklch(96.7% 0.001 286.375)",
      200: "oklch(92% 0.004 286.32)",
      300: "oklch(87.1% 0.006 286.286)",
      400: "oklch(70.5% 0.015 286.067)",
      500: "oklch(55.2% 0.016 285.938)",
      600: "oklch(44.2% 0.017 285.786)",
      700: "oklch(37% 0.013 285.805)",
      800: "oklch(27.4% 0.006 286.033)",
      900: "oklch(21% 0.006 285.885)",
      950: "oklch(14.1% 0.005 285.823)",
    },
    neutral: {
      50: "oklch(98.5% 0 0)",
      100: "oklch(97% 0 0)",
      200: "oklch(92.2% 0 0)",
      300: "oklch(87% 0 0)",
      400: "oklch(70.8% 0 0)",
      500: "oklch(55.6% 0 0)",
      600: "oklch(43.9% 0 0)",
      700: "oklch(37.1% 0 0)",
      800: "oklch(26.9% 0 0)",
      900: "oklch(20.5% 0 0)",
      950: "oklch(14.5% 0 0)",
    },
    stone: {
      50: "oklch(98.5% 0.001 106.423)",
      100: "oklch(97% 0.001 106.424)",
      200: "oklch(92.3% 0.003 48.717)",
      300: "oklch(86.9% 0.005 56.366)",
      400: "oklch(70.9% 0.01 56.259)",
      500: "oklch(55.3% 0.013 58.071)",
      600: "oklch(44.4% 0.011 73.639)",
      700: "oklch(37.4% 0.01 67.558)",
      800: "oklch(26.8% 0.007 34.298)",
      900: "oklch(21.6% 0.006 56.043)",
      950: "oklch(14.7% 0.004 49.25)",
    },
    red: {
      50: "oklch(97.1% 0.013 17.38)",
      100: "oklch(93.6% 0.032 17.717)",
      200: "oklch(88.5% 0.062 18.334)",
      300: "oklch(80.8% 0.114 19.571)",
      400: "oklch(70.4% 0.191 22.216)",
      500: "oklch(63.7% 0.237 25.331)",
      600: "oklch(57.7% 0.245 27.325)",
      700: "oklch(50.5% 0.213 27.518)",
      800: "oklch(44.4% 0.177 26.899)",
      900: "oklch(39.6% 0.141 25.723)",
      950: "oklch(25.8% 0.092 26.042)",
    },
    orange: {
      50: "oklch(98% 0.016 73.684)",
      100: "oklch(95.4% 0.038 75.164)",
      200: "oklch(90.1% 0.076 70.697)",
      300: "oklch(83.7% 0.128 66.29)",
      400: "oklch(75% 0.183 55.934)",
      500: "oklch(70.5% 0.213 47.604)",
      600: "oklch(64.6% 0.222 41.116)",
      700: "oklch(55.3% 0.195 38.402)",
      800: "oklch(47% 0.157 37.304)",
      900: "oklch(40.8% 0.123 38.172)",
      950: "oklch(26.6% 0.079 36.259)",
    },
    amber: {
      50: "oklch(98.7% 0.022 95.277)",
      100: "oklch(96.2% 0.059 95.617)",
      200: "oklch(92.4% 0.12 95.746)",
      300: "oklch(87.9% 0.169 91.605)",
      400: "oklch(82.8% 0.189 84.429)",
      500: "oklch(76.9% 0.188 70.08)",
      600: "oklch(66.6% 0.179 58.318)",
      700: "oklch(55.5% 0.163 48.998)",
      800: "oklch(47.3% 0.137 46.201)",
      900: "oklch(41.4% 0.112 45.904)",
      950: "oklch(27.9% 0.077 45.635)",
    },
    yellow: {
      50: "oklch(98.7% 0.026 102.212)",
      100: "oklch(97.3% 0.071 103.193)",
      200: "oklch(94.5% 0.129 101.54)",
      300: "oklch(90.5% 0.182 98.111)",
      400: "oklch(85.2% 0.199 91.936)",
      500: "oklch(79.5% 0.184 86.047)",
      600: "oklch(68.1% 0.162 75.834)",
      700: "oklch(55.4% 0.135 66.442)",
      800: "oklch(47.6% 0.114 61.907)",
      900: "oklch(42.1% 0.095 57.708)",
      950: "oklch(28.6% 0.066 53.813)",
    },
    lime: {
      50: "oklch(98.6% 0.031 120.757)",
      100: "oklch(96.7% 0.067 122.328)",
      200: "oklch(93.8% 0.127 124.321)",
      300: "oklch(89.7% 0.196 126.665)",
      400: "oklch(84.1% 0.238 128.85)",
      500: "oklch(76.8% 0.233 130.85)",
      600: "oklch(64.8% 0.2 131.684)",
      700: "oklch(53.2% 0.157 131.589)",
      800: "oklch(45.3% 0.124 130.933)",
      900: "oklch(40.5% 0.101 131.063)",
      950: "oklch(27.4% 0.072 132.109)",
    },
    green: {
      50: "oklch(98.2% 0.018 155.826)",
      100: "oklch(96.2% 0.044 156.743)",
      200: "oklch(92.5% 0.084 155.995)",
      300: "oklch(87.1% 0.15 154.449)",
      400: "oklch(79.2% 0.209 151.711)",
      500: "oklch(72.3% 0.219 149.579)",
      600: "oklch(62.7% 0.194 149.214)",
      700: "oklch(52.7% 0.154 150.069)",
      800: "oklch(44.8% 0.119 151.328)",
      900: "oklch(39.3% 0.095 152.535)",
      950: "oklch(26.6% 0.065 152.934)",
    },
    emerald: {
      50: "oklch(97.9% 0.021 166.113)",
      100: "oklch(95% 0.052 163.051)",
      200: "oklch(90.5% 0.093 164.15)",
      300: "oklch(84.5% 0.143 164.978)",
      400: "oklch(76.5% 0.177 163.223)",
      500: "oklch(69.6% 0.17 162.48)",
      600: "oklch(59.6% 0.145 163.225)",
      700: "oklch(50.8% 0.118 165.612)",
      800: "oklch(43.2% 0.095 166.913)",
      900: "oklch(37.8% 0.077 168.94)",
      950: "oklch(26.2% 0.051 172.552)",
    },
    teal: {
      50: "oklch(98.4% 0.014 180.72)",
      100: "oklch(95.3% 0.051 180.801)",
      200: "oklch(91% 0.096 180.426)",
      300: "oklch(85.5% 0.138 181.071)",
      400: "oklch(77.7% 0.152 181.912)",
      500: "oklch(70.4% 0.14 182.503)",
      600: "oklch(60% 0.118 184.704)",
      700: "oklch(51.1% 0.096 186.391)",
      800: "oklch(43.7% 0.078 188.216)",
      900: "oklch(38.6% 0.063 188.416)",
      950: "oklch(27.7% 0.046 192.524)",
    },
    cyan: {
      50: "oklch(98.4% 0.019 200.873)",
      100: "oklch(95.6% 0.045 203.388)",
      200: "oklch(91.7% 0.08 205.041)",
      300: "oklch(86.5% 0.127 207.078)",
      400: "oklch(78.9% 0.154 211.53)",
      500: "oklch(71.5% 0.143 215.221)",
      600: "oklch(60.9% 0.126 221.723)",
      700: "oklch(52% 0.105 223.128)",
      800: "oklch(45% 0.085 224.283)",
      900: "oklch(39.8% 0.07 227.392)",
      950: "oklch(30.2% 0.056 229.695)",
    },
    sky: {
      50: "oklch(97.7% 0.013 236.62)",
      100: "oklch(95.1% 0.026 236.824)",
      200: "oklch(90.1% 0.058 230.902)",
      300: "oklch(82.8% 0.111 230.318)",
      400: "oklch(74.6% 0.16 232.661)",
      500: "oklch(68.5% 0.169 237.323)",
      600: "oklch(58.8% 0.158 241.966)",
      700: "oklch(50% 0.134 242.749)",
      800: "oklch(44.3% 0.11 240.79)",
      900: "oklch(39.1% 0.09 240.876)",
      950: "oklch(29.3% 0.066 243.157)",
    },
    blue: {
      50: "oklch(97% 0.014 254.604)",
      100: "oklch(93.2% 0.032 255.585)",
      200: "oklch(88.2% 0.059 254.128)",
      300: "oklch(80.9% 0.105 251.813)",
      400: "oklch(70.7% 0.165 254.624)",
      500: "oklch(62.3% 0.214 259.815)",
      600: "oklch(54.6% 0.245 262.881)",
      700: "oklch(48.8% 0.243 264.376)",
      800: "oklch(42.4% 0.199 265.638)",
      900: "oklch(37.9% 0.146 265.522)",
      950: "oklch(28.2% 0.091 267.935)",
    },
    indigo: {
      50: "oklch(96.2% 0.018 272.314)",
      100: "oklch(93% 0.034 272.788)",
      200: "oklch(87% 0.065 274.039)",
      300: "oklch(78.5% 0.115 274.713)",
      400: "oklch(67.3% 0.182 276.935)",
      500: "oklch(58.5% 0.233 277.117)",
      600: "oklch(51.1% 0.262 276.966)",
      700: "oklch(45.7% 0.24 277.023)",
      800: "oklch(39.8% 0.195 277.366)",
      900: "oklch(35.9% 0.144 278.697)",
      950: "oklch(25.7% 0.09 281.288)",
    },
    violet: {
      50: "oklch(96.9% 0.016 293.756)",
      100: "oklch(94.3% 0.029 294.588)",
      200: "oklch(89.4% 0.057 293.283)",
      300: "oklch(81.1% 0.111 293.571)",
      400: "oklch(70.2% 0.183 293.541)",
      500: "oklch(60.6% 0.25 292.717)",
      600: "oklch(54.1% 0.281 293.009)",
      700: "oklch(49.1% 0.27 292.581)",
      800: "oklch(43.2% 0.232 292.759)",
      900: "oklch(38% 0.189 293.745)",
      950: "oklch(28.3% 0.141 291.089)",
    },
    purple: {
      50: "oklch(97.7% 0.014 308.299)",
      100: "oklch(94.6% 0.033 307.174)",
      200: "oklch(90.2% 0.063 306.703)",
      300: "oklch(82.7% 0.119 306.383)",
      400: "oklch(71.4% 0.203 305.504)",
      500: "oklch(62.7% 0.265 303.9)",
      600: "oklch(55.8% 0.288 302.321)",
      700: "oklch(49.6% 0.265 301.924)",
      800: "oklch(43.8% 0.218 303.724)",
      900: "oklch(38.1% 0.176 304.987)",
      950: "oklch(29.1% 0.149 302.717)",
    },
    fuchsia: {
      50: "oklch(97.7% 0.017 320.058)",
      100: "oklch(95.2% 0.037 318.852)",
      200: "oklch(90.3% 0.076 319.62)",
      300: "oklch(83.3% 0.145 321.434)",
      400: "oklch(74% 0.238 322.16)",
      500: "oklch(66.7% 0.295 322.15)",
      600: "oklch(59.1% 0.293 322.896)",
      700: "oklch(51.8% 0.253 323.949)",
      800: "oklch(45.2% 0.211 324.591)",
      900: "oklch(40.1% 0.17 325.612)",
      950: "oklch(29.3% 0.136 325.661)",
    },
    pink: {
      50: "oklch(97.1% 0.014 343.198)",
      100: "oklch(94.8% 0.028 342.258)",
      200: "oklch(89.9% 0.061 343.231)",
      300: "oklch(82.3% 0.12 346.018)",
      400: "oklch(71.8% 0.202 349.761)",
      500: "oklch(65.6% 0.241 354.308)",
      600: "oklch(59.2% 0.249 0.584)",
      700: "oklch(52.5% 0.223 3.958)",
      800: "oklch(45.9% 0.187 3.815)",
      900: "oklch(40.8% 0.153 2.432)",
      950: "oklch(28.4% 0.109 3.907)",
    },
    rose: {
      50: "oklch(96.9% 0.015 12.422)",
      100: "oklch(94.1% 0.03 12.58)",
      200: "oklch(89.2% 0.058 10.001)",
      300: "oklch(81% 0.117 11.638)",
      400: "oklch(71.2% 0.194 13.428)",
      500: "oklch(64.5% 0.246 16.439)",
      600: "oklch(58.6% 0.253 17.585)",
      700: "oklch(51.4% 0.222 16.935)",
      800: "oklch(45.5% 0.188 13.697)",
      900: "oklch(41% 0.159 10.272)",
      950: "oklch(27.1% 0.105 12.094)",
    },
  };
  function Ce(e) {
    return { __BARE_VALUE__: e };
  }
  var ae = Ce((e) => {
      if (T(e.value)) return e.value;
    }),
    ie = Ce((e) => {
      if (T(e.value)) return `${e.value}%`;
    }),
    ke = Ce((e) => {
      if (T(e.value)) return `${e.value}px`;
    }),
    di = Ce((e) => {
      if (T(e.value)) return `${e.value}ms`;
    }),
    gt = Ce((e) => {
      if (T(e.value)) return `${e.value}deg`;
    }),
    un = Ce((e) => {
      if (e.fraction === null) return;
      let [r, i] = z(e.fraction, "/");
      if (!(!T(r) || !T(i))) return e.fraction;
    }),
    pi = Ce((e) => {
      if (T(Number(e.value))) return `repeat(${e.value}, minmax(0, 1fr))`;
    }),
    mi = {
      accentColor: ({ theme: e }) => e("colors"),
      animation: {
        none: "none",
        spin: "spin 1s linear infinite",
        ping: "ping 1s cubic-bezier(0, 0, 0.2, 1) infinite",
        pulse: "pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        bounce: "bounce 1s infinite",
      },
      aria: {
        busy: 'busy="true"',
        checked: 'checked="true"',
        disabled: 'disabled="true"',
        expanded: 'expanded="true"',
        hidden: 'hidden="true"',
        pressed: 'pressed="true"',
        readonly: 'readonly="true"',
        required: 'required="true"',
        selected: 'selected="true"',
      },
      aspectRatio: { auto: "auto", square: "1 / 1", video: "16 / 9", ...un },
      backdropBlur: ({ theme: e }) => e("blur"),
      backdropBrightness: ({ theme: e }) => ({ ...e("brightness"), ...ie }),
      backdropContrast: ({ theme: e }) => ({ ...e("contrast"), ...ie }),
      backdropGrayscale: ({ theme: e }) => ({ ...e("grayscale"), ...ie }),
      backdropHueRotate: ({ theme: e }) => ({ ...e("hueRotate"), ...gt }),
      backdropInvert: ({ theme: e }) => ({ ...e("invert"), ...ie }),
      backdropOpacity: ({ theme: e }) => ({ ...e("opacity"), ...ie }),
      backdropSaturate: ({ theme: e }) => ({ ...e("saturate"), ...ie }),
      backdropSepia: ({ theme: e }) => ({ ...e("sepia"), ...ie }),
      backgroundColor: ({ theme: e }) => e("colors"),
      backgroundImage: {
        none: "none",
        "gradient-to-t": "linear-gradient(to top, var(--tw-gradient-stops))",
        "gradient-to-tr":
          "linear-gradient(to top right, var(--tw-gradient-stops))",
        "gradient-to-r": "linear-gradient(to right, var(--tw-gradient-stops))",
        "gradient-to-br":
          "linear-gradient(to bottom right, var(--tw-gradient-stops))",
        "gradient-to-b": "linear-gradient(to bottom, var(--tw-gradient-stops))",
        "gradient-to-bl":
          "linear-gradient(to bottom left, var(--tw-gradient-stops))",
        "gradient-to-l": "linear-gradient(to left, var(--tw-gradient-stops))",
        "gradient-to-tl":
          "linear-gradient(to top left, var(--tw-gradient-stops))",
      },
      backgroundOpacity: ({ theme: e }) => e("opacity"),
      backgroundPosition: {
        bottom: "bottom",
        center: "center",
        left: "left",
        "left-bottom": "left bottom",
        "left-top": "left top",
        right: "right",
        "right-bottom": "right bottom",
        "right-top": "right top",
        top: "top",
      },
      backgroundSize: { auto: "auto", cover: "cover", contain: "contain" },
      blur: {
        0: "0",
        none: "",
        sm: "4px",
        DEFAULT: "8px",
        md: "12px",
        lg: "16px",
        xl: "24px",
        "2xl": "40px",
        "3xl": "64px",
      },
      borderColor: ({ theme: e }) => ({
        DEFAULT: "currentcolor",
        ...e("colors"),
      }),
      borderOpacity: ({ theme: e }) => e("opacity"),
      borderRadius: {
        none: "0px",
        sm: "0.125rem",
        DEFAULT: "0.25rem",
        md: "0.375rem",
        lg: "0.5rem",
        xl: "0.75rem",
        "2xl": "1rem",
        "3xl": "1.5rem",
        full: "9999px",
      },
      borderSpacing: ({ theme: e }) => e("spacing"),
      borderWidth: {
        DEFAULT: "1px",
        0: "0px",
        2: "2px",
        4: "4px",
        8: "8px",
        ...ke,
      },
      boxShadow: {
        sm: "0 1px 2px 0 rgb(0 0 0 / 0.05)",
        DEFAULT:
          "0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1)",
        md: "0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)",
        lg: "0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)",
        xl: "0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)",
        "2xl": "0 25px 50px -12px rgb(0 0 0 / 0.25)",
        inner: "inset 0 2px 4px 0 rgb(0 0 0 / 0.05)",
        none: "none",
      },
      boxShadowColor: ({ theme: e }) => e("colors"),
      brightness: {
        0: "0",
        50: ".5",
        75: ".75",
        90: ".9",
        95: ".95",
        100: "1",
        105: "1.05",
        110: "1.1",
        125: "1.25",
        150: "1.5",
        200: "2",
        ...ie,
      },
      caretColor: ({ theme: e }) => e("colors"),
      colors: () => ({ ...mt }),
      columns: {
        auto: "auto",
        1: "1",
        2: "2",
        3: "3",
        4: "4",
        5: "5",
        6: "6",
        7: "7",
        8: "8",
        9: "9",
        10: "10",
        11: "11",
        12: "12",
        "3xs": "16rem",
        "2xs": "18rem",
        xs: "20rem",
        sm: "24rem",
        md: "28rem",
        lg: "32rem",
        xl: "36rem",
        "2xl": "42rem",
        "3xl": "48rem",
        "4xl": "56rem",
        "5xl": "64rem",
        "6xl": "72rem",
        "7xl": "80rem",
        ...ae,
      },
      container: {},
      content: { none: "none" },
      contrast: {
        0: "0",
        50: ".5",
        75: ".75",
        100: "1",
        125: "1.25",
        150: "1.5",
        200: "2",
        ...ie,
      },
      cursor: {
        auto: "auto",
        default: "default",
        pointer: "pointer",
        wait: "wait",
        text: "text",
        move: "move",
        help: "help",
        "not-allowed": "not-allowed",
        none: "none",
        "context-menu": "context-menu",
        progress: "progress",
        cell: "cell",
        crosshair: "crosshair",
        "vertical-text": "vertical-text",
        alias: "alias",
        copy: "copy",
        "no-drop": "no-drop",
        grab: "grab",
        grabbing: "grabbing",
        "all-scroll": "all-scroll",
        "col-resize": "col-resize",
        "row-resize": "row-resize",
        "n-resize": "n-resize",
        "e-resize": "e-resize",
        "s-resize": "s-resize",
        "w-resize": "w-resize",
        "ne-resize": "ne-resize",
        "nw-resize": "nw-resize",
        "se-resize": "se-resize",
        "sw-resize": "sw-resize",
        "ew-resize": "ew-resize",
        "ns-resize": "ns-resize",
        "nesw-resize": "nesw-resize",
        "nwse-resize": "nwse-resize",
        "zoom-in": "zoom-in",
        "zoom-out": "zoom-out",
      },
      divideColor: ({ theme: e }) => e("borderColor"),
      divideOpacity: ({ theme: e }) => e("borderOpacity"),
      divideWidth: ({ theme: e }) => ({ ...e("borderWidth"), ...ke }),
      dropShadow: {
        sm: "0 1px 1px rgb(0 0 0 / 0.05)",
        DEFAULT: ["0 1px 2px rgb(0 0 0 / 0.1)", "0 1px 1px rgb(0 0 0 / 0.06)"],
        md: ["0 4px 3px rgb(0 0 0 / 0.07)", "0 2px 2px rgb(0 0 0 / 0.06)"],
        lg: ["0 10px 8px rgb(0 0 0 / 0.04)", "0 4px 3px rgb(0 0 0 / 0.1)"],
        xl: ["0 20px 13px rgb(0 0 0 / 0.03)", "0 8px 5px rgb(0 0 0 / 0.08)"],
        "2xl": "0 25px 25px rgb(0 0 0 / 0.15)",
        none: "0 0 #0000",
      },
      fill: ({ theme: e }) => e("colors"),
      flex: {
        1: "1 1 0%",
        auto: "1 1 auto",
        initial: "0 1 auto",
        none: "none",
      },
      flexBasis: ({ theme: e }) => ({
        auto: "auto",
        "1/2": "50%",
        "1/3": "33.333333%",
        "2/3": "66.666667%",
        "1/4": "25%",
        "2/4": "50%",
        "3/4": "75%",
        "1/5": "20%",
        "2/5": "40%",
        "3/5": "60%",
        "4/5": "80%",
        "1/6": "16.666667%",
        "2/6": "33.333333%",
        "3/6": "50%",
        "4/6": "66.666667%",
        "5/6": "83.333333%",
        "1/12": "8.333333%",
        "2/12": "16.666667%",
        "3/12": "25%",
        "4/12": "33.333333%",
        "5/12": "41.666667%",
        "6/12": "50%",
        "7/12": "58.333333%",
        "8/12": "66.666667%",
        "9/12": "75%",
        "10/12": "83.333333%",
        "11/12": "91.666667%",
        full: "100%",
        ...e("spacing"),
      }),
      flexGrow: { 0: "0", DEFAULT: "1", ...ae },
      flexShrink: { 0: "0", DEFAULT: "1", ...ae },
      fontFamily: {
        sans: [
          "ui-sans-serif",
          "system-ui",
          "sans-serif",
          '"Apple Color Emoji"',
          '"Segoe UI Emoji"',
          '"Segoe UI Symbol"',
          '"Noto Color Emoji"',
        ],
        serif: [
          "ui-serif",
          "Georgia",
          "Cambria",
          '"Times New Roman"',
          "Times",
          "serif",
        ],
        mono: [
          "ui-monospace",
          "SFMono-Regular",
          "Menlo",
          "Monaco",
          "Consolas",
          '"Liberation Mono"',
          '"Courier New"',
          "monospace",
        ],
      },
      fontSize: {
        xs: ["0.75rem", { lineHeight: "1rem" }],
        sm: ["0.875rem", { lineHeight: "1.25rem" }],
        base: ["1rem", { lineHeight: "1.5rem" }],
        lg: ["1.125rem", { lineHeight: "1.75rem" }],
        xl: ["1.25rem", { lineHeight: "1.75rem" }],
        "2xl": ["1.5rem", { lineHeight: "2rem" }],
        "3xl": ["1.875rem", { lineHeight: "2.25rem" }],
        "4xl": ["2.25rem", { lineHeight: "2.5rem" }],
        "5xl": ["3rem", { lineHeight: "1" }],
        "6xl": ["3.75rem", { lineHeight: "1" }],
        "7xl": ["4.5rem", { lineHeight: "1" }],
        "8xl": ["6rem", { lineHeight: "1" }],
        "9xl": ["8rem", { lineHeight: "1" }],
      },
      fontWeight: {
        thin: "100",
        extralight: "200",
        light: "300",
        normal: "400",
        medium: "500",
        semibold: "600",
        bold: "700",
        extrabold: "800",
        black: "900",
      },
      gap: ({ theme: e }) => e("spacing"),
      gradientColorStops: ({ theme: e }) => e("colors"),
      gradientColorStopPositions: {
        "0%": "0%",
        "5%": "5%",
        "10%": "10%",
        "15%": "15%",
        "20%": "20%",
        "25%": "25%",
        "30%": "30%",
        "35%": "35%",
        "40%": "40%",
        "45%": "45%",
        "50%": "50%",
        "55%": "55%",
        "60%": "60%",
        "65%": "65%",
        "70%": "70%",
        "75%": "75%",
        "80%": "80%",
        "85%": "85%",
        "90%": "90%",
        "95%": "95%",
        "100%": "100%",
        ...ie,
      },
      grayscale: { 0: "0", DEFAULT: "100%", ...ie },
      gridAutoColumns: {
        auto: "auto",
        min: "min-content",
        max: "max-content",
        fr: "minmax(0, 1fr)",
      },
      gridAutoRows: {
        auto: "auto",
        min: "min-content",
        max: "max-content",
        fr: "minmax(0, 1fr)",
      },
      gridColumn: {
        auto: "auto",
        "span-1": "span 1 / span 1",
        "span-2": "span 2 / span 2",
        "span-3": "span 3 / span 3",
        "span-4": "span 4 / span 4",
        "span-5": "span 5 / span 5",
        "span-6": "span 6 / span 6",
        "span-7": "span 7 / span 7",
        "span-8": "span 8 / span 8",
        "span-9": "span 9 / span 9",
        "span-10": "span 10 / span 10",
        "span-11": "span 11 / span 11",
        "span-12": "span 12 / span 12",
        "span-full": "1 / -1",
      },
      gridColumnEnd: {
        auto: "auto",
        1: "1",
        2: "2",
        3: "3",
        4: "4",
        5: "5",
        6: "6",
        7: "7",
        8: "8",
        9: "9",
        10: "10",
        11: "11",
        12: "12",
        13: "13",
        ...ae,
      },
      gridColumnStart: {
        auto: "auto",
        1: "1",
        2: "2",
        3: "3",
        4: "4",
        5: "5",
        6: "6",
        7: "7",
        8: "8",
        9: "9",
        10: "10",
        11: "11",
        12: "12",
        13: "13",
        ...ae,
      },
      gridRow: {
        auto: "auto",
        "span-1": "span 1 / span 1",
        "span-2": "span 2 / span 2",
        "span-3": "span 3 / span 3",
        "span-4": "span 4 / span 4",
        "span-5": "span 5 / span 5",
        "span-6": "span 6 / span 6",
        "span-7": "span 7 / span 7",
        "span-8": "span 8 / span 8",
        "span-9": "span 9 / span 9",
        "span-10": "span 10 / span 10",
        "span-11": "span 11 / span 11",
        "span-12": "span 12 / span 12",
        "span-full": "1 / -1",
      },
      gridRowEnd: {
        auto: "auto",
        1: "1",
        2: "2",
        3: "3",
        4: "4",
        5: "5",
        6: "6",
        7: "7",
        8: "8",
        9: "9",
        10: "10",
        11: "11",
        12: "12",
        13: "13",
        ...ae,
      },
      gridRowStart: {
        auto: "auto",
        1: "1",
        2: "2",
        3: "3",
        4: "4",
        5: "5",
        6: "6",
        7: "7",
        8: "8",
        9: "9",
        10: "10",
        11: "11",
        12: "12",
        13: "13",
        ...ae,
      },
      gridTemplateColumns: {
        none: "none",
        subgrid: "subgrid",
        1: "repeat(1, minmax(0, 1fr))",
        2: "repeat(2, minmax(0, 1fr))",
        3: "repeat(3, minmax(0, 1fr))",
        4: "repeat(4, minmax(0, 1fr))",
        5: "repeat(5, minmax(0, 1fr))",
        6: "repeat(6, minmax(0, 1fr))",
        7: "repeat(7, minmax(0, 1fr))",
        8: "repeat(8, minmax(0, 1fr))",
        9: "repeat(9, minmax(0, 1fr))",
        10: "repeat(10, minmax(0, 1fr))",
        11: "repeat(11, minmax(0, 1fr))",
        12: "repeat(12, minmax(0, 1fr))",
        ...pi,
      },
      gridTemplateRows: {
        none: "none",
        subgrid: "subgrid",
        1: "repeat(1, minmax(0, 1fr))",
        2: "repeat(2, minmax(0, 1fr))",
        3: "repeat(3, minmax(0, 1fr))",
        4: "repeat(4, minmax(0, 1fr))",
        5: "repeat(5, minmax(0, 1fr))",
        6: "repeat(6, minmax(0, 1fr))",
        7: "repeat(7, minmax(0, 1fr))",
        8: "repeat(8, minmax(0, 1fr))",
        9: "repeat(9, minmax(0, 1fr))",
        10: "repeat(10, minmax(0, 1fr))",
        11: "repeat(11, minmax(0, 1fr))",
        12: "repeat(12, minmax(0, 1fr))",
        ...pi,
      },
      height: ({ theme: e }) => ({
        auto: "auto",
        "1/2": "50%",
        "1/3": "33.333333%",
        "2/3": "66.666667%",
        "1/4": "25%",
        "2/4": "50%",
        "3/4": "75%",
        "1/5": "20%",
        "2/5": "40%",
        "3/5": "60%",
        "4/5": "80%",
        "1/6": "16.666667%",
        "2/6": "33.333333%",
        "3/6": "50%",
        "4/6": "66.666667%",
        "5/6": "83.333333%",
        full: "100%",
        screen: "100vh",
        svh: "100svh",
        lvh: "100lvh",
        dvh: "100dvh",
        min: "min-content",
        max: "max-content",
        fit: "fit-content",
        ...e("spacing"),
      }),
      hueRotate: {
        0: "0deg",
        15: "15deg",
        30: "30deg",
        60: "60deg",
        90: "90deg",
        180: "180deg",
        ...gt,
      },
      inset: ({ theme: e }) => ({
        auto: "auto",
        "1/2": "50%",
        "1/3": "33.333333%",
        "2/3": "66.666667%",
        "1/4": "25%",
        "2/4": "50%",
        "3/4": "75%",
        full: "100%",
        ...e("spacing"),
      }),
      invert: { 0: "0", DEFAULT: "100%", ...ie },
      keyframes: {
        spin: { to: { transform: "rotate(360deg)" } },
        ping: { "75%, 100%": { transform: "scale(2)", opacity: "0" } },
        pulse: { "50%": { opacity: ".5" } },
        bounce: {
          "0%, 100%": {
            transform: "translateY(-25%)",
            animationTimingFunction: "cubic-bezier(0.8,0,1,1)",
          },
          "50%": {
            transform: "none",
            animationTimingFunction: "cubic-bezier(0,0,0.2,1)",
          },
        },
      },
      letterSpacing: {
        tighter: "-0.05em",
        tight: "-0.025em",
        normal: "0em",
        wide: "0.025em",
        wider: "0.05em",
        widest: "0.1em",
      },
      lineHeight: {
        none: "1",
        tight: "1.25",
        snug: "1.375",
        normal: "1.5",
        relaxed: "1.625",
        loose: "2",
        3: ".75rem",
        4: "1rem",
        5: "1.25rem",
        6: "1.5rem",
        7: "1.75rem",
        8: "2rem",
        9: "2.25rem",
        10: "2.5rem",
      },
      listStyleType: { none: "none", disc: "disc", decimal: "decimal" },
      listStyleImage: { none: "none" },
      margin: ({ theme: e }) => ({ auto: "auto", ...e("spacing") }),
      lineClamp: { 1: "1", 2: "2", 3: "3", 4: "4", 5: "5", 6: "6", ...ae },
      maxHeight: ({ theme: e }) => ({
        none: "none",
        full: "100%",
        screen: "100vh",
        svh: "100svh",
        lvh: "100lvh",
        dvh: "100dvh",
        min: "min-content",
        max: "max-content",
        fit: "fit-content",
        ...e("spacing"),
      }),
      maxWidth: ({ theme: e }) => ({
        none: "none",
        xs: "20rem",
        sm: "24rem",
        md: "28rem",
        lg: "32rem",
        xl: "36rem",
        "2xl": "42rem",
        "3xl": "48rem",
        "4xl": "56rem",
        "5xl": "64rem",
        "6xl": "72rem",
        "7xl": "80rem",
        full: "100%",
        min: "min-content",
        max: "max-content",
        fit: "fit-content",
        prose: "65ch",
        ...e("spacing"),
      }),
      minHeight: ({ theme: e }) => ({
        full: "100%",
        screen: "100vh",
        svh: "100svh",
        lvh: "100lvh",
        dvh: "100dvh",
        min: "min-content",
        max: "max-content",
        fit: "fit-content",
        ...e("spacing"),
      }),
      minWidth: ({ theme: e }) => ({
        full: "100%",
        min: "min-content",
        max: "max-content",
        fit: "fit-content",
        ...e("spacing"),
      }),
      objectPosition: {
        bottom: "bottom",
        center: "center",
        left: "left",
        "left-bottom": "left bottom",
        "left-top": "left top",
        right: "right",
        "right-bottom": "right bottom",
        "right-top": "right top",
        top: "top",
      },
      opacity: {
        0: "0",
        5: "0.05",
        10: "0.1",
        15: "0.15",
        20: "0.2",
        25: "0.25",
        30: "0.3",
        35: "0.35",
        40: "0.4",
        45: "0.45",
        50: "0.5",
        55: "0.55",
        60: "0.6",
        65: "0.65",
        70: "0.7",
        75: "0.75",
        80: "0.8",
        85: "0.85",
        90: "0.9",
        95: "0.95",
        100: "1",
        ...ie,
      },
      order: {
        first: "-9999",
        last: "9999",
        none: "0",
        1: "1",
        2: "2",
        3: "3",
        4: "4",
        5: "5",
        6: "6",
        7: "7",
        8: "8",
        9: "9",
        10: "10",
        11: "11",
        12: "12",
        ...ae,
      },
      outlineColor: ({ theme: e }) => e("colors"),
      outlineOffset: {
        0: "0px",
        1: "1px",
        2: "2px",
        4: "4px",
        8: "8px",
        ...ke,
      },
      outlineWidth: { 0: "0px", 1: "1px", 2: "2px", 4: "4px", 8: "8px", ...ke },
      padding: ({ theme: e }) => e("spacing"),
      placeholderColor: ({ theme: e }) => e("colors"),
      placeholderOpacity: ({ theme: e }) => e("opacity"),
      ringColor: ({ theme: e }) => ({
        DEFAULT: "currentcolor",
        ...e("colors"),
      }),
      ringOffsetColor: ({ theme: e }) => e("colors"),
      ringOffsetWidth: {
        0: "0px",
        1: "1px",
        2: "2px",
        4: "4px",
        8: "8px",
        ...ke,
      },
      ringOpacity: ({ theme: e }) => ({ DEFAULT: "0.5", ...e("opacity") }),
      ringWidth: {
        DEFAULT: "3px",
        0: "0px",
        1: "1px",
        2: "2px",
        4: "4px",
        8: "8px",
        ...ke,
      },
      rotate: {
        0: "0deg",
        1: "1deg",
        2: "2deg",
        3: "3deg",
        6: "6deg",
        12: "12deg",
        45: "45deg",
        90: "90deg",
        180: "180deg",
        ...gt,
      },
      saturate: { 0: "0", 50: ".5", 100: "1", 150: "1.5", 200: "2", ...ie },
      scale: {
        0: "0",
        50: ".5",
        75: ".75",
        90: ".9",
        95: ".95",
        100: "1",
        105: "1.05",
        110: "1.1",
        125: "1.25",
        150: "1.5",
        ...ie,
      },
      screens: {
        sm: "40rem",
        md: "48rem",
        lg: "64rem",
        xl: "80rem",
        "2xl": "96rem",
      },
      scrollMargin: ({ theme: e }) => e("spacing"),
      scrollPadding: ({ theme: e }) => e("spacing"),
      sepia: { 0: "0", DEFAULT: "100%", ...ie },
      skew: {
        0: "0deg",
        1: "1deg",
        2: "2deg",
        3: "3deg",
        6: "6deg",
        12: "12deg",
        ...gt,
      },
      space: ({ theme: e }) => e("spacing"),
      spacing: {
        px: "1px",
        0: "0px",
        0.5: "0.125rem",
        1: "0.25rem",
        1.5: "0.375rem",
        2: "0.5rem",
        2.5: "0.625rem",
        3: "0.75rem",
        3.5: "0.875rem",
        4: "1rem",
        5: "1.25rem",
        6: "1.5rem",
        7: "1.75rem",
        8: "2rem",
        9: "2.25rem",
        10: "2.5rem",
        11: "2.75rem",
        12: "3rem",
        14: "3.5rem",
        16: "4rem",
        20: "5rem",
        24: "6rem",
        28: "7rem",
        32: "8rem",
        36: "9rem",
        40: "10rem",
        44: "11rem",
        48: "12rem",
        52: "13rem",
        56: "14rem",
        60: "15rem",
        64: "16rem",
        72: "18rem",
        80: "20rem",
        96: "24rem",
      },
      stroke: ({ theme: e }) => ({ none: "none", ...e("colors") }),
      strokeWidth: { 0: "0", 1: "1", 2: "2", ...ae },
      supports: {},
      data: {},
      textColor: ({ theme: e }) => e("colors"),
      textDecorationColor: ({ theme: e }) => e("colors"),
      textDecorationThickness: {
        auto: "auto",
        "from-font": "from-font",
        0: "0px",
        1: "1px",
        2: "2px",
        4: "4px",
        8: "8px",
        ...ke,
      },
      textIndent: ({ theme: e }) => e("spacing"),
      textOpacity: ({ theme: e }) => e("opacity"),
      textUnderlineOffset: {
        auto: "auto",
        0: "0px",
        1: "1px",
        2: "2px",
        4: "4px",
        8: "8px",
        ...ke,
      },
      transformOrigin: {
        center: "center",
        top: "top",
        "top-right": "top right",
        right: "right",
        "bottom-right": "bottom right",
        bottom: "bottom",
        "bottom-left": "bottom left",
        left: "left",
        "top-left": "top left",
      },
      transitionDelay: {
        0: "0s",
        75: "75ms",
        100: "100ms",
        150: "150ms",
        200: "200ms",
        300: "300ms",
        500: "500ms",
        700: "700ms",
        1e3: "1000ms",
        ...di,
      },
      transitionDuration: {
        DEFAULT: "150ms",
        0: "0s",
        75: "75ms",
        100: "100ms",
        150: "150ms",
        200: "200ms",
        300: "300ms",
        500: "500ms",
        700: "700ms",
        1e3: "1000ms",
        ...di,
      },
      transitionProperty: {
        none: "none",
        all: "all",
        DEFAULT:
          "color, background-color, border-color, outline-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter",
        colors:
          "color, background-color, border-color, outline-color, text-decoration-color, fill, stroke",
        opacity: "opacity",
        shadow: "box-shadow",
        transform: "transform",
      },
      transitionTimingFunction: {
        DEFAULT: "cubic-bezier(0.4, 0, 0.2, 1)",
        linear: "linear",
        in: "cubic-bezier(0.4, 0, 1, 1)",
        out: "cubic-bezier(0, 0, 0.2, 1)",
        "in-out": "cubic-bezier(0.4, 0, 0.2, 1)",
      },
      translate: ({ theme: e }) => ({
        "1/2": "50%",
        "1/3": "33.333333%",
        "2/3": "66.666667%",
        "1/4": "25%",
        "2/4": "50%",
        "3/4": "75%",
        full: "100%",
        ...e("spacing"),
      }),
      size: ({ theme: e }) => ({
        auto: "auto",
        "1/2": "50%",
        "1/3": "33.333333%",
        "2/3": "66.666667%",
        "1/4": "25%",
        "2/4": "50%",
        "3/4": "75%",
        "1/5": "20%",
        "2/5": "40%",
        "3/5": "60%",
        "4/5": "80%",
        "1/6": "16.666667%",
        "2/6": "33.333333%",
        "3/6": "50%",
        "4/6": "66.666667%",
        "5/6": "83.333333%",
        "1/12": "8.333333%",
        "2/12": "16.666667%",
        "3/12": "25%",
        "4/12": "33.333333%",
        "5/12": "41.666667%",
        "6/12": "50%",
        "7/12": "58.333333%",
        "8/12": "66.666667%",
        "9/12": "75%",
        "10/12": "83.333333%",
        "11/12": "91.666667%",
        full: "100%",
        min: "min-content",
        max: "max-content",
        fit: "fit-content",
        ...e("spacing"),
      }),
      width: ({ theme: e }) => ({
        auto: "auto",
        "1/2": "50%",
        "1/3": "33.333333%",
        "2/3": "66.666667%",
        "1/4": "25%",
        "2/4": "50%",
        "3/4": "75%",
        "1/5": "20%",
        "2/5": "40%",
        "3/5": "60%",
        "4/5": "80%",
        "1/6": "16.666667%",
        "2/6": "33.333333%",
        "3/6": "50%",
        "4/6": "66.666667%",
        "5/6": "83.333333%",
        "1/12": "8.333333%",
        "2/12": "16.666667%",
        "3/12": "25%",
        "4/12": "33.333333%",
        "5/12": "41.666667%",
        "6/12": "50%",
        "7/12": "58.333333%",
        "8/12": "66.666667%",
        "9/12": "75%",
        "10/12": "83.333333%",
        "11/12": "91.666667%",
        full: "100%",
        screen: "100vw",
        svw: "100svw",
        lvw: "100lvw",
        dvw: "100dvw",
        min: "min-content",
        max: "max-content",
        fit: "fit-content",
        ...e("spacing"),
      }),
      willChange: {
        auto: "auto",
        scroll: "scroll-position",
        contents: "contents",
        transform: "transform",
      },
      zIndex: {
        auto: "auto",
        0: "0",
        10: "10",
        20: "20",
        30: "30",
        40: "40",
        50: "50",
        ...ae,
      },
    };
  function gi(e) {
    return {
      theme: {
        ...mi,
        colors: ({ theme: r }) => r("color", {}),
        extend: {
          fontSize: ({ theme: r }) => ({ ...r("text", {}) }),
          boxShadow: ({ theme: r }) => ({ ...r("shadow", {}) }),
          animation: ({ theme: r }) => ({ ...r("animate", {}) }),
          aspectRatio: ({ theme: r }) => ({ ...r("aspect", {}) }),
          borderRadius: ({ theme: r }) => ({ ...r("radius", {}) }),
          screens: ({ theme: r }) => ({ ...r("breakpoint", {}) }),
          letterSpacing: ({ theme: r }) => ({ ...r("tracking", {}) }),
          lineHeight: ({ theme: r }) => ({ ...r("leading", {}) }),
          transitionDuration: {
            DEFAULT: e.get(["--default-transition-duration"]) ?? null,
          },
          transitionTimingFunction: {
            DEFAULT: e.get(["--default-transition-timing-function"]) ?? null,
          },
          maxWidth: ({ theme: r }) => ({ ...r("container", {}) }),
        },
      },
    };
  }
  var cn = {
    blocklist: [],
    future: {},
    prefix: "",
    important: !1,
    darkMode: null,
    theme: {},
    plugins: [],
    content: { files: [] },
  };
  function Wt(e, r) {
    let i = {
      design: e,
      configs: [],
      plugins: [],
      content: { files: [] },
      theme: {},
      extend: {},
      result: structuredClone(cn),
    };
    for (let o of r) Bt(i, o);
    for (let o of i.configs)
      "darkMode" in o &&
        o.darkMode !== void 0 &&
        (i.result.darkMode = o.darkMode ?? null),
        "prefix" in o &&
          o.prefix !== void 0 &&
          (i.result.prefix = o.prefix ?? ""),
        "blocklist" in o &&
          o.blocklist !== void 0 &&
          (i.result.blocklist = o.blocklist ?? []),
        "important" in o &&
          o.important !== void 0 &&
          (i.result.important = o.important ?? !1);
    let t = dn(i);
    return {
      resolvedConfig: {
        ...i.result,
        content: i.content,
        theme: i.theme,
        plugins: i.plugins,
      },
      replacedThemeKeys: t,
    };
  }
  function fn(e, r) {
    if (Array.isArray(e) && Re(e[0])) return e.concat(r);
    if (Array.isArray(r) && Re(r[0]) && Re(e)) return [e, ...r];
    if (Array.isArray(r)) return r;
  }
  function Bt(e, { config: r, base: i, path: t, reference: o, src: s }) {
    let a = [];
    for (let c of r.plugins ?? [])
      "__isOptionsFunction" in c
        ? a.push({ ...c(), reference: o, src: s })
        : "handler" in c
        ? a.push({ ...c, reference: o, src: s })
        : a.push({ handler: c, reference: o, src: s });
    if (Array.isArray(r.presets) && r.presets.length === 0)
      throw new Error(
        "Error in the config file/plugin/preset. An empty preset (`preset: []`) is not currently supported."
      );
    for (let c of r.presets ?? [])
      Bt(e, { path: t, base: i, config: c, reference: o, src: s });
    for (let c of a)
      e.plugins.push(c),
        c.config &&
          Bt(e, {
            path: t,
            base: i,
            config: c.config,
            reference: !!c.reference,
            src: c.src ?? s,
          });
    let d = r.content ?? [],
      u = Array.isArray(d) ? d : d.files;
    for (let c of u)
      e.content.files.push(typeof c == "object" ? c : { base: i, pattern: c });
    e.configs.push(r);
  }
  function dn(e) {
    let r = new Set(),
      i = dt(e.design, () => e.theme, o),
      t = Object.assign(i, { theme: i, colors: mt });
    function o(s) {
      return typeof s == "function" ? s(t) ?? null : s ?? null;
    }
    for (let s of e.configs) {
      let a = s.theme ?? {},
        d = a.extend ?? {};
      for (let u in a) u !== "extend" && r.add(u);
      Object.assign(e.theme, a);
      for (let u in d) (e.extend[u] ??= []), e.extend[u].push(d[u]);
    }
    delete e.theme.extend;
    for (let s in e.extend) {
      let a = [e.theme[s], ...e.extend[s]];
      e.theme[s] = () => {
        let d = a.map(o);
        return Ie({}, d, fn);
      };
    }
    for (let s in e.theme) e.theme[s] = o(e.theme[s]);
    if (e.theme.screens && typeof e.theme.screens == "object")
      for (let s of Object.keys(e.theme.screens)) {
        let a = e.theme.screens[s];
        a &&
          typeof a == "object" &&
          ("raw" in a ||
            "max" in a ||
            ("min" in a && (e.theme.screens[s] = a.min)));
      }
    return r;
  }
  function hi(e, r) {
    let i = e.theme.container || {};
    if (typeof i != "object" || i === null) return;
    let t = pn(i, r);
    t.length !== 0 && r.utilities.static("container", () => structuredClone(t));
  }
  function pn({ center: e, padding: r, screens: i }, t) {
    let o = [],
      s = null;
    if (
      (e && o.push(n("margin-inline", "auto")),
      (typeof r == "string" ||
        (typeof r == "object" && r !== null && "DEFAULT" in r)) &&
        o.push(n("padding-inline", typeof r == "string" ? r : r.DEFAULT)),
      typeof i == "object" && i !== null)
    ) {
      s = new Map();
      let a = Array.from(t.theme.namespace("--breakpoint").entries());
      if ((a.sort((d, u) => ye(d[1], u[1], "asc")), a.length > 0)) {
        let [d] = a[0];
        o.push(
          F("@media", `(width >= --theme(--breakpoint-${d}))`, [
            n("max-width", "none"),
          ])
        );
      }
      for (let [d, u] of Object.entries(i)) {
        if (typeof u == "object")
          if ("min" in u) u = u.min;
          else continue;
        s.set(d, F("@media", `(width >= ${u})`, [n("max-width", u)]));
      }
    }
    if (typeof r == "object" && r !== null) {
      let a = Object.entries(r)
        .filter(([d]) => d !== "DEFAULT")
        .map(([d, u]) => [d, t.theme.resolveValue(d, ["--breakpoint"]), u])
        .filter(Boolean);
      a.sort((d, u) => ye(d[1], u[1], "asc"));
      for (let [d, , u] of a)
        if (s && s.has(d)) s.get(d).nodes.push(n("padding-inline", u));
        else {
          if (s) continue;
          o.push(
            F("@media", `(width >= theme(--breakpoint-${d}))`, [
              n("padding-inline", u),
            ])
          );
        }
    }
    if (s) for (let [, a] of s) o.push(a);
    return o;
  }
  function ki({ addVariant: e, config: r }) {
    let i = r("darkMode", null),
      [t, o = ".dark"] = Array.isArray(i) ? i : [i];
    if (t === "variant") {
      let s;
      if (
        (Array.isArray(o) || typeof o == "function"
          ? (s = o)
          : typeof o == "string" && (s = [o]),
        Array.isArray(s))
      )
        for (let a of s)
          a === ".dark"
            ? ((t = !1),
              console.warn(
                'When using `variant` for `darkMode`, you must provide a selector.\nExample: `darkMode: ["variant", ".your-selector &"]`'
              ))
            : a.includes("&") ||
              ((t = !1),
              console.warn(
                'When using `variant` for `darkMode`, your selector must contain `&`.\nExample `darkMode: ["variant", ".your-selector &"]`'
              ));
      o = s;
    }
    t === null ||
      (t === "selector"
        ? e("dark", `&:where(${o}, ${o} *)`)
        : t === "media"
        ? e("dark", "@media (prefers-color-scheme: dark)")
        : t === "variant"
        ? e("dark", o)
        : t === "class" && e("dark", `&:is(${o} *)`));
  }
  function vi(e) {
    for (let [r, i] of [
      ["t", "top"],
      ["tr", "top right"],
      ["r", "right"],
      ["br", "bottom right"],
      ["b", "bottom"],
      ["bl", "bottom left"],
      ["l", "left"],
      ["tl", "top left"],
    ])
      e.utilities.static(`bg-gradient-to-${r}`, () => [
        n("--tw-gradient-position", `to ${i} in oklab`),
        n("background-image", "linear-gradient(var(--tw-gradient-stops))"),
      ]);
    e.utilities.static("bg-left-top", () => [
      n("background-position", "left top"),
    ]),
      e.utilities.static("bg-right-top", () => [
        n("background-position", "right top"),
      ]),
      e.utilities.static("bg-left-bottom", () => [
        n("background-position", "left bottom"),
      ]),
      e.utilities.static("bg-right-bottom", () => [
        n("background-position", "right bottom"),
      ]),
      e.utilities.static("object-left-top", () => [
        n("object-position", "left top"),
      ]),
      e.utilities.static("object-right-top", () => [
        n("object-position", "right top"),
      ]),
      e.utilities.static("object-left-bottom", () => [
        n("object-position", "left bottom"),
      ]),
      e.utilities.static("object-right-bottom", () => [
        n("object-position", "right bottom"),
      ]),
      e.utilities.functional("max-w-screen", (r) => {
        if (!r.value || r.value.kind === "arbitrary") return;
        let i = e.theme.resolve(r.value.value, ["--breakpoint"]);
        if (i) return [n("max-width", i)];
      }),
      e.utilities.static("overflow-ellipsis", () => [
        n("text-overflow", "ellipsis"),
      ]),
      e.utilities.static("decoration-slice", () => [
        n("-webkit-box-decoration-break", "slice"),
        n("box-decoration-break", "slice"),
      ]),
      e.utilities.static("decoration-clone", () => [
        n("-webkit-box-decoration-break", "clone"),
        n("box-decoration-break", "clone"),
      ]),
      e.utilities.functional("flex-shrink", (r) => {
        if (!r.modifier) {
          if (!r.value) return [n("flex-shrink", "1")];
          if (r.value.kind === "arbitrary")
            return [n("flex-shrink", r.value.value)];
          if (T(r.value.value)) return [n("flex-shrink", r.value.value)];
        }
      }),
      e.utilities.functional("flex-grow", (r) => {
        if (!r.modifier) {
          if (!r.value) return [n("flex-grow", "1")];
          if (r.value.kind === "arbitrary")
            return [n("flex-grow", r.value.value)];
          if (T(r.value.value)) return [n("flex-grow", r.value.value)];
        }
      }),
      e.utilities.static("order-none", () => [n("order", "0")]);
  }
  function wi(e, r) {
    let i = e.theme.screens || {},
      t = r.variants.get("min")?.order ?? 0,
      o = [];
    for (let [a, d] of Object.entries(i)) {
      let p = function (v) {
        r.variants.static(
          a,
          (k) => {
            k.nodes = [F("@media", g, k.nodes)];
          },
          { order: v }
        );
      };
      var s = p;
      let u = r.variants.get(a),
        c = r.theme.resolveValue(a, ["--breakpoint"]);
      if (u && c && !r.theme.hasDefault(`--breakpoint-${a}`)) continue;
      let m = !0;
      typeof d == "string" && (m = !1);
      let g = mn(d);
      m ? o.push(p) : p(t);
    }
    if (o.length !== 0) {
      for (let [, a] of r.variants.variants)
        a.order > t && (a.order += o.length);
      r.variants.compareFns = new Map(
        Array.from(r.variants.compareFns).map(
          ([a, d]) => (a > t && (a += o.length), [a, d])
        )
      );
      for (let [a, d] of o.entries()) d(t + a + 1);
    }
  }
  function mn(e) {
    return (Array.isArray(e) ? e : [e])
      .map((i) =>
        typeof i == "string" ? { min: i } : i && typeof i == "object" ? i : null
      )
      .map((i) => {
        if (i === null) return null;
        if ("raw" in i) return i.raw;
        let t = "";
        return (
          i.max !== void 0 && (t += `${i.max} >= `),
          (t += "width"),
          i.min !== void 0 && (t += ` >= ${i.min}`),
          `(${t})`
        );
      })
      .filter(Boolean)
      .join(", ");
  }
  function bi(e, r) {
    let i = e.theme.aria || {},
      t = e.theme.supports || {},
      o = e.theme.data || {};
    if (Object.keys(i).length > 0) {
      let s = r.variants.get("aria"),
        a = s?.applyFn,
        d = s?.compounds;
      r.variants.functional(
        "aria",
        (u, c) => {
          let m = c.value;
          return m && m.kind === "named" && m.value in i
            ? a?.(u, { ...c, value: { kind: "arbitrary", value: i[m.value] } })
            : a?.(u, c);
        },
        { compounds: d }
      );
    }
    if (Object.keys(t).length > 0) {
      let s = r.variants.get("supports"),
        a = s?.applyFn,
        d = s?.compounds;
      r.variants.functional(
        "supports",
        (u, c) => {
          let m = c.value;
          return m && m.kind === "named" && m.value in t
            ? a?.(u, { ...c, value: { kind: "arbitrary", value: t[m.value] } })
            : a?.(u, c);
        },
        { compounds: d }
      );
    }
    if (Object.keys(o).length > 0) {
      let s = r.variants.get("data"),
        a = s?.applyFn,
        d = s?.compounds;
      r.variants.functional(
        "data",
        (u, c) => {
          let m = c.value;
          return m && m.kind === "named" && m.value in o
            ? a?.(u, { ...c, value: { kind: "arbitrary", value: o[m.value] } })
            : a?.(u, c);
        },
        { compounds: d }
      );
    }
  }
  var gn = /^[a-z]+$/;
  async function xi({
    designSystem: e,
    base: r,
    ast: i,
    loadModule: t,
    sources: o,
  }) {
    let s = 0,
      a = [],
      d = [];
    K(i, (g, { parent: p, replaceWith: v, context: k }) => {
      if (g.kind === "at-rule") {
        if (g.name === "@plugin") {
          if (p !== null) throw new Error("`@plugin` cannot be nested.");
          let w = g.params.slice(1, -1);
          if (w.length === 0) throw new Error("`@plugin` must have a path.");
          let x = {};
          for (let V of g.nodes ?? []) {
            if (V.kind !== "declaration")
              throw new Error(`Unexpected \`@plugin\` option:

${ne([V])}

\`@plugin\` options must be a flat list of declarations.`);
            if (V.value === void 0) continue;
            let C = V.value,
              y = z(C, ",").map((_) => {
                if (((_ = _.trim()), _ === "null")) return null;
                if (_ === "true") return !0;
                if (_ === "false") return !1;
                if (Number.isNaN(Number(_))) {
                  if (
                    (_[0] === '"' && _[_.length - 1] === '"') ||
                    (_[0] === "'" && _[_.length - 1] === "'")
                  )
                    return _.slice(1, -1);
                  if (_[0] === "{" && _[_.length - 1] === "}")
                    throw new Error(`Unexpected \`@plugin\` option: Value of declaration \`${ne(
                      [V]
                    ).trim()}\` is not supported.

Using an object as a plugin option is currently only supported in JavaScript configuration files.`);
                } else return Number(_);
                return _;
              });
            x[V.property] = y.length === 1 ? y[0] : y;
          }
          a.push([
            { id: w, base: k.base, reference: !!k.reference, src: g.src },
            Object.keys(x).length > 0 ? x : null,
          ]),
            v([]),
            (s |= 4);
          return;
        }
        if (g.name === "@config") {
          if (g.nodes.length > 0)
            throw new Error("`@config` cannot have a body.");
          if (p !== null) throw new Error("`@config` cannot be nested.");
          d.push({
            id: g.params.slice(1, -1),
            base: k.base,
            reference: !!k.reference,
            src: g.src,
          }),
            v([]),
            (s |= 4);
          return;
        }
      }
    }),
      vi(e);
    let u = e.resolveThemeValue;
    if (
      ((e.resolveThemeValue = function (p, v) {
        return p.startsWith("--")
          ? u(p, v)
          : ((s |= yi({
              designSystem: e,
              base: r,
              ast: i,
              sources: o,
              configs: [],
              pluginDetails: [],
            })),
            e.resolveThemeValue(p, v));
      }),
      !a.length && !d.length)
    )
      return 0;
    let [c, m] = await Promise.all([
      Promise.all(
        d.map(async ({ id: g, base: p, reference: v, src: k }) => {
          let w = await t(g, p, "config");
          return {
            path: g,
            base: w.base,
            config: w.module,
            reference: v,
            src: k,
          };
        })
      ),
      Promise.all(
        a.map(async ([{ id: g, base: p, reference: v, src: k }, w]) => {
          let x = await t(g, p, "plugin");
          return {
            path: g,
            base: x.base,
            plugin: x.module,
            options: w,
            reference: v,
            src: k,
          };
        })
      ),
    ]);
    return (
      (s |= yi({
        designSystem: e,
        base: r,
        ast: i,
        sources: o,
        configs: c,
        pluginDetails: m,
      })),
      s
    );
  }
  function yi({
    designSystem: e,
    base: r,
    ast: i,
    sources: t,
    configs: o,
    pluginDetails: s,
  }) {
    let a = 0,
      u = [
        ...s.map((w) => {
          if (!w.options)
            return {
              config: { plugins: [w.plugin] },
              base: w.base,
              reference: w.reference,
              src: w.src,
            };
          if ("__isOptionsFunction" in w.plugin)
            return {
              config: { plugins: [w.plugin(w.options)] },
              base: w.base,
              reference: w.reference,
              src: w.src,
            };
          throw new Error(`The plugin "${w.path}" does not accept options`);
        }),
        ...o,
      ],
      { resolvedConfig: c } = Wt(e, [
        { config: gi(e.theme), base: r, reference: !0, src: void 0 },
        ...u,
        { config: { plugins: [ki] }, base: r, reference: !0, src: void 0 },
      ]),
      { resolvedConfig: m, replacedThemeKeys: g } = Wt(e, u),
      p = {
        designSystem: e,
        ast: i,
        resolvedConfig: c,
        featuresRef: {
          set current(w) {
            a |= w;
          },
        },
      },
      v = Mt({ ...p, referenceMode: !1, src: void 0 }),
      k = e.resolveThemeValue;
    e.resolveThemeValue = function (x, V) {
      if (x[0] === "-" && x[1] === "-") return k(x, V);
      let C = v.theme(x, void 0);
      if (Array.isArray(C) && C.length === 2) return C[0];
      if (Array.isArray(C)) return C.join(", ");
      if (typeof C == "string") return C;
    };
    for (let { handler: w, reference: x, src: V } of c.plugins) {
      let C = Mt({ ...p, referenceMode: x ?? !1, src: V });
      w(C);
    }
    if (
      (Hr(e, m, g),
      fi(e, m, g),
      bi(m, e),
      wi(m, e),
      hi(m, e),
      !e.theme.prefix && c.prefix)
    ) {
      if (
        (c.prefix.endsWith("-") &&
          ((c.prefix = c.prefix.slice(0, -1)),
          console.warn(
            `The prefix "${c.prefix}" is invalid. Prefixes must be lowercase ASCII letters (a-z) only and is written as a variant before all utilities. We have fixed up the prefix for you. Remove the trailing \`-\` to silence this warning.`
          )),
        !gn.test(c.prefix))
      )
        throw new Error(
          `The prefix "${c.prefix}" is invalid. Prefixes must be lowercase ASCII letters (a-z) only.`
        );
      e.theme.prefix = c.prefix;
    }
    if (
      (!e.important && c.important === !0 && (e.important = !0),
      typeof c.important == "string")
    ) {
      let w = c.important;
      K(i, (x, { replaceWith: V, parent: C }) => {
        if (
          x.kind === "at-rule" &&
          !(x.name !== "@tailwind" || x.params !== "utilities")
        )
          return C?.kind === "rule" && C.selector === w ? 2 : (V(W(w, [x])), 2);
      });
    }
    for (let w of c.blocklist) e.invalidCandidates.add(w);
    for (let w of c.content.files) {
      if ("raw" in w)
        throw new Error(`Error in the config file/plugin/preset. The \`content\` key contains a \`raw\` entry:

${JSON.stringify(w, null, 2)}

This feature is not currently supported.`);
      let x = !1;
      w.pattern[0] == "!" && ((x = !0), (w.pattern = w.pattern.slice(1))),
        t.push({ ...w, negated: x });
    }
    return a;
  }
  function Ai(e) {
    let r = [0];
    for (let o = 0; o < e.length; o++) e.charCodeAt(o) === 10 && r.push(o + 1);
    function i(o) {
      let s = 0,
        a = r.length;
      for (; a > 0; ) {
        let u = (a | 0) >> 1,
          c = s + u;
        r[c] <= o ? ((s = c + 1), (a = a - u - 1)) : (a = u);
      }
      s -= 1;
      let d = o - r[s];
      return { line: s + 1, column: d };
    }
    function t({ line: o, column: s }) {
      (o -= 1), (o = Math.min(Math.max(o, 0), r.length - 1));
      let a = r[o],
        d = r[o + 1] ?? a;
      return Math.min(Math.max(a + s, 0), d);
    }
    return { find: i, findOffset: t };
  }
  function Ci({ ast: e }) {
    let r = new B((o) => Ai(o.code)),
      i = new B((o) => ({ url: o.file, content: o.code, ignore: !1 })),
      t = { file: null, sources: [], mappings: [] };
    K(e, (o) => {
      if (!o.src || !o.dst) return;
      let s = i.get(o.src[0]);
      if (!s.content) return;
      let a = r.get(o.src[0]),
        d = r.get(o.dst[0]),
        u = s.content.slice(o.src[1], o.src[2]),
        c = 0;
      for (let p of u.split(`
`)) {
        if (p.trim() !== "") {
          let v = a.find(o.src[1] + c),
            k = d.find(o.dst[1]);
          t.mappings.push({
            name: null,
            originalPosition: { source: s, ...v },
            generatedPosition: k,
          });
        }
        (c += p.length), (c += 1);
      }
      let m = a.find(o.src[2]),
        g = d.find(o.dst[2]);
      t.mappings.push({
        name: null,
        originalPosition: { source: s, ...m },
        generatedPosition: g,
      });
    });
    for (let o of r.keys()) t.sources.push(i.get(o));
    return (
      t.mappings.sort(
        (o, s) =>
          o.generatedPosition.line - s.generatedPosition.line ||
          o.generatedPosition.column - s.generatedPosition.column ||
          (o.originalPosition?.line ?? 0) - (s.originalPosition?.line ?? 0) ||
          (o.originalPosition?.column ?? 0) - (s.originalPosition?.column ?? 0)
      ),
      t
    );
  }
  var Si = /^(-?\d+)\.\.(-?\d+)(?:\.\.(-?\d+))?$/;
  function ht(e) {
    let r = e.indexOf("{");
    if (r === -1) return [e];
    let i = [],
      t = e.slice(0, r),
      o = e.slice(r),
      s = 0,
      a = o.lastIndexOf("}");
    for (let g = 0; g < o.length; g++) {
      let p = o[g];
      if (p === "{") s++;
      else if (p === "}" && (s--, s === 0)) {
        a = g;
        break;
      }
    }
    if (a === -1) throw new Error(`The pattern \`${e}\` is not balanced.`);
    let d = o.slice(1, a),
      u = o.slice(a + 1),
      c;
    hn(d) ? (c = kn(d)) : (c = z(d, ",")), (c = c.flatMap((g) => ht(g)));
    let m = ht(u);
    for (let g of m) for (let p of c) i.push(t + p + g);
    return i;
  }
  function hn(e) {
    return Si.test(e);
  }
  function kn(e) {
    let r = e.match(Si);
    if (!r) return [e];
    let [, i, t, o] = r,
      s = o ? parseInt(o, 10) : void 0,
      a = [];
    if (/^-?\d+$/.test(i) && /^-?\d+$/.test(t)) {
      let d = parseInt(i, 10),
        u = parseInt(t, 10);
      if ((s === void 0 && (s = d <= u ? 1 : -1), s === 0))
        throw new Error("Step cannot be zero in sequence expansion.");
      let c = d < u;
      c && s < 0 && (s = -s), !c && s > 0 && (s = -s);
      for (let m = d; c ? m <= u : m >= u; m += s) a.push(m.toString());
    }
    return a;
  }
  function $i(e, r) {
    let i = new Set(),
      t = new Set(),
      o = [];
    function s(a, d = []) {
      if (e.has(a) && !i.has(a)) {
        t.has(a) && r.onCircularDependency?.(d, a), t.add(a);
        for (let u of e.get(a) ?? []) d.push(a), s(u, d), d.pop();
        i.add(a), t.delete(a), o.push(a);
      }
    }
    for (let a of e.keys()) s(a);
    return o;
  }
  var vn = /^[a-z]+$/;
  function wn() {
    throw new Error("No `loadModule` function provided to `compile`");
  }
  function bn() {
    throw new Error("No `loadStylesheet` function provided to `compile`");
  }
  function yn(e) {
    let r = 0,
      i = null;
    for (let t of z(e, " "))
      t === "reference"
        ? (r |= 2)
        : t === "inline"
        ? (r |= 1)
        : t === "default"
        ? (r |= 4)
        : t === "static"
        ? (r |= 8)
        : t.startsWith("prefix(") && t.endsWith(")") && (i = t.slice(7, -1));
    return [r, i];
  }
  async function xn(
    e,
    { base: r = "", from: i, loadModule: t = wn, loadStylesheet: o = bn } = {}
  ) {
    let s = 0;
    (e = [ue({ base: r }, e)]), (s |= await Ft(e, r, o, 0, i !== void 0));
    let a = null,
      d = new Je(),
      u = new Map(),
      c = new Map(),
      m = [],
      g = null,
      p = null,
      v = [],
      k = [],
      w = [],
      x = [],
      V = null;
    K(e, (y, { parent: _, replaceWith: R, context: D }) => {
      if (y.kind === "at-rule") {
        if (
          y.name === "@tailwind" &&
          (y.params === "utilities" || y.params.startsWith("utilities"))
        ) {
          if (p !== null) {
            R([]);
            return;
          }
          if (D.reference) {
            R([]);
            return;
          }
          let U = z(y.params, " ");
          for (let H of U)
            if (H.startsWith("source(")) {
              let O = H.slice(7, -1);
              if (O === "none") {
                V = O;
                continue;
              }
              if (
                (O[0] === '"' && O[O.length - 1] !== '"') ||
                (O[0] === "'" && O[O.length - 1] !== "'") ||
                (O[0] !== "'" && O[0] !== '"')
              )
                throw new Error("`source(\u2026)` paths must be quoted.");
              V = { base: D.sourceBase ?? D.base, pattern: O.slice(1, -1) };
            }
          (p = y), (s |= 16);
        }
        if (y.name === "@utility") {
          if (_ !== null) throw new Error("`@utility` cannot be nested.");
          if (y.nodes.length === 0)
            throw new Error(
              `\`@utility ${y.params}\` is empty. Utilities should include at least one property.`
            );
          let U = _r(y);
          if (U === null) {
            if (!y.params.endsWith("-*")) {
              if (y.params.endsWith("*"))
                throw new Error(
                  `\`@utility ${y.params}\` defines an invalid utility name. A functional utility must end in \`-*\`.`
                );
              if (y.params.includes("*"))
                throw new Error(
                  `\`@utility ${y.params}\` defines an invalid utility name. The dynamic portion marked by \`-*\` must appear once at the end.`
                );
            }
            throw new Error(
              `\`@utility ${y.params}\` defines an invalid utility name. Utilities should be alphanumeric and start with a lowercase letter.`
            );
          }
          m.push(U);
        }
        if (y.name === "@source") {
          if (y.nodes.length > 0)
            throw new Error("`@source` cannot have a body.");
          if (_ !== null) throw new Error("`@source` cannot be nested.");
          let U = !1,
            H = !1,
            O = y.params;
          if (
            (O[0] === "n" &&
              O.startsWith("not ") &&
              ((U = !0), (O = O.slice(4))),
            O[0] === "i" &&
              O.startsWith("inline(") &&
              ((H = !0), (O = O.slice(7, -1))),
            (O[0] === '"' && O[O.length - 1] !== '"') ||
              (O[0] === "'" && O[O.length - 1] !== "'") ||
              (O[0] !== "'" && O[0] !== '"'))
          )
            throw new Error("`@source` paths must be quoted.");
          let L = O.slice(1, -1);
          if (H) {
            let q = U ? x : w,
              M = z(L, " ");
            for (let oe of M) for (let l of ht(oe)) q.push(l);
          } else k.push({ base: D.base, pattern: L, negated: U });
          R([]);
          return;
        }
        if (
          (y.name === "@variant" &&
            (_ === null
              ? y.nodes.length === 0
                ? (y.name = "@custom-variant")
                : (K(y.nodes, (U) => {
                    if (U.kind === "at-rule" && U.name === "@slot")
                      return (y.name = "@custom-variant"), 2;
                  }),
                  y.name === "@variant" && v.push(y))
              : v.push(y)),
          y.name === "@custom-variant")
        ) {
          if (_ !== null)
            throw new Error("`@custom-variant` cannot be nested.");
          R([]);
          let [U, H] = z(y.params, " ");
          if (!ut.test(U))
            throw new Error(
              `\`@custom-variant ${U}\` defines an invalid variant name. Variants should only contain alphanumeric, dashes, or underscore characters and start with a lowercase letter or number.`
            );
          if (y.nodes.length > 0 && H)
            throw new Error(
              `\`@custom-variant ${U}\` cannot have both a selector and a body.`
            );
          if (y.nodes.length === 0) {
            if (!H)
              throw new Error(
                `\`@custom-variant ${U}\` has no selector or body.`
              );
            let O = z(H.slice(1, -1), ",");
            if (O.length === 0 || O.some((M) => M.trim() === ""))
              throw new Error(
                `\`@custom-variant ${U} (${O.join(",")})\` selector is invalid.`
              );
            let L = [],
              q = [];
            for (let M of O)
              (M = M.trim()), M[0] === "@" ? L.push(M) : q.push(M);
            u.set(U, (M) => {
              M.variants.static(
                U,
                (oe) => {
                  let l = [];
                  q.length > 0 && l.push(W(q.join(", "), oe.nodes));
                  for (let f of L) l.push(Y(f, oe.nodes));
                  oe.nodes = l;
                },
                { compounds: Ae([...q, ...L]) }
              );
            }),
              c.set(U, new Set());
            return;
          } else {
            let O = new Set();
            K(y.nodes, (L) => {
              L.kind === "at-rule" && L.name === "@variant" && O.add(L.params);
            }),
              u.set(U, (L) => {
                L.variants.fromAst(U, y.nodes, L);
              }),
              c.set(U, O);
            return;
          }
        }
        if (y.name === "@media") {
          let U = z(y.params, " "),
            H = [];
          for (let O of U)
            if (O.startsWith("source(")) {
              let L = O.slice(7, -1);
              K(y.nodes, (q, { replaceWith: M }) => {
                if (
                  q.kind === "at-rule" &&
                  q.name === "@tailwind" &&
                  q.params === "utilities"
                )
                  return (
                    (q.params += ` source(${L})`),
                    M([ue({ sourceBase: D.base }, [q])]),
                    2
                  );
              });
            } else if (O.startsWith("theme(")) {
              let L = O.slice(6, -1),
                q = L.includes("reference");
              K(y.nodes, (M) => {
                if (M.kind !== "at-rule") {
                  if (q)
                    throw new Error(
                      'Files imported with `@import "\u2026" theme(reference)` must only contain `@theme` blocks.\nUse `@reference "\u2026";` instead.'
                    );
                  return 0;
                }
                if (M.name === "@theme") return (M.params += " " + L), 1;
              });
            } else if (O.startsWith("prefix(")) {
              let L = O.slice(7, -1);
              K(y.nodes, (q) => {
                if (q.kind === "at-rule" && q.name === "@theme")
                  return (q.params += ` prefix(${L})`), 1;
              });
            } else
              O === "important"
                ? (a = !0)
                : O === "reference"
                ? (y.nodes = [ue({ reference: !0 }, y.nodes)])
                : H.push(O);
          H.length > 0 ? (y.params = H.join(" ")) : U.length > 0 && R(y.nodes);
        }
        if (y.name === "@theme") {
          let [U, H] = yn(y.params);
          if (((s |= 64), D.reference && (U |= 2), H)) {
            if (!vn.test(H))
              throw new Error(
                `The prefix "${H}" is invalid. Prefixes must be lowercase ASCII letters (a-z) only.`
              );
            d.prefix = H;
          }
          return (
            K(y.nodes, (O) => {
              if (O.kind === "at-rule" && O.name === "@keyframes")
                return d.addKeyframes(O), 1;
              if (O.kind === "comment") return;
              if (O.kind === "declaration" && O.property.startsWith("--")) {
                d.add(ve(O.property), O.value ?? "", U, O.src);
                return;
              }
              let L = ne([F(y.name, y.params, [O])])
                .split(
                  `
`
                )
                .map(
                  (q, M, oe) =>
                    `${M === 0 || M >= oe.length - 2 ? " " : ">"} ${q}`
                ).join(`
`);
              throw new Error(`\`@theme\` blocks must only contain custom properties or \`@keyframes\`.

${L}`);
            }),
            g ? R([]) : ((g = W(":root, :host", [])), (g.src = y.src), R([g])),
            1
          );
        }
      }
    });
    let C = Fr(d);
    if ((a && (C.important = a), x.length > 0))
      for (let y of x) C.invalidCandidates.add(y);
    s |= await xi({
      designSystem: C,
      base: r,
      ast: e,
      loadModule: t,
      sources: k,
    });
    for (let y of u.keys()) C.variants.static(y, () => {});
    for (let y of $i(c, {
      onCircularDependency(_, R) {
        let D = ne(
          _.map((U, H) =>
            F("@custom-variant", U, [F("@variant", _[H + 1] ?? R, [])])
          )
        )
          .replaceAll(";", " { \u2026 }")
          .replace(
            `@custom-variant ${R} {`,
            `@custom-variant ${R} { /* \u2190 */`
          );
        throw new Error(`Circular dependency detected in custom variants:

${D}`);
      },
    }))
      u.get(y)?.(C);
    for (let y of m) y(C);
    if (g) {
      let y = [];
      for (let [R, D] of C.theme.entries()) {
        if (D.options & 2) continue;
        let U = n(me(R), D.value);
        (U.src = D.src), y.push(U);
      }
      let _ = C.theme.getKeyframes();
      for (let R of _) e.push(ue({ theme: !0 }, [j([R])]));
      g.nodes = [ue({ theme: !0 }, y)];
    }
    if (((s |= It(e, C)), (s |= Ve(e, C)), (s |= Le(e, C)), p)) {
      let y = p;
      (y.kind = "context"), (y.context = {});
    }
    return (
      K(e, (y, { replaceWith: _ }) => {
        if (y.kind === "at-rule") return y.name === "@utility" && _([]), 1;
      }),
      {
        designSystem: C,
        ast: e,
        sources: k,
        root: V,
        utilitiesNode: p,
        features: s,
        inlineCandidates: w,
      }
    );
  }
  async function An(e, r = {}) {
    let {
      designSystem: i,
      ast: t,
      sources: o,
      root: s,
      utilitiesNode: a,
      features: d,
      inlineCandidates: u,
    } = await xn(e, r);
    t.unshift(
      Ze(`! tailwindcss v${Yt} | MIT License | https://tailwindcss.com `)
    );
    function c(k) {
      i.invalidCandidates.add(k);
    }
    let m = new Set(),
      g = null,
      p = 0,
      v = !1;
    for (let k of u) i.invalidCandidates.has(k) || (m.add(k), (v = !0));
    return {
      sources: o,
      root: s,
      features: d,
      build(k) {
        if (d === 0) return e;
        if (!a) return (g ??= be(t, i, r.polyfills)), g;
        let w = v,
          x = !1;
        v = !1;
        let V = m.size;
        for (let y of k)
          if (!i.invalidCandidates.has(y))
            if (y[0] === "-" && y[1] === "-") {
              let _ = i.theme.markUsedVariable(y);
              (w ||= _), (x ||= _);
            } else m.add(y), (w ||= m.size !== V);
        if (!w) return (g ??= be(t, i, r.polyfills)), g;
        let C = he(m, i, { onInvalidCandidate: c }).astNodes;
        return (
          r.from &&
            K(C, (y) => {
              y.src ??= a.src;
            }),
          !x && p === C.length
            ? ((g ??= be(t, i, r.polyfills)), g)
            : ((p = C.length), (a.nodes = C), (g = be(t, i, r.polyfills)), g)
        );
      },
    };
  }
  async function Ni(e, r = {}) {
    let i = Se(e, { from: r.from }),
      t = await An(i, r),
      o = i,
      s = e;
    return {
      ...t,
      build(a) {
        let d = t.build(a);
        return d === o || ((s = ne(d, !!r.from)), (o = d)), s;
      },
      buildSourceMap() {
        return Ci({ ast: o });
      },
    };
  }
  var Vi = `@layer theme, base, components, utilities;

@import './theme.css' layer(theme);
@import './preflight.css' layer(base);
@import './utilities.css' layer(utilities);
`;
  var Ei = `/*
  1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)
  2. Remove default margins and padding
  3. Reset all borders.
*/

*,
::after,
::before,
::backdrop,
::file-selector-button {
  box-sizing: border-box; /* 1 */
  margin: 0; /* 2 */
  padding: 0; /* 2 */
  border: 0 solid; /* 3 */
}

/*
  1. Use a consistent sensible line-height in all browsers.
  2. Prevent adjustments of font size after orientation changes in iOS.
  3. Use a more readable tab size.
  4. Use the user's configured \`sans\` font-family by default.
  5. Use the user's configured \`sans\` font-feature-settings by default.
  6. Use the user's configured \`sans\` font-variation-settings by default.
  7. Disable tap highlights on iOS.
*/

html,
:host {
  line-height: 1.5; /* 1 */
  -webkit-text-size-adjust: 100%; /* 2 */
  tab-size: 4; /* 3 */
  font-family: --theme(
    --default-font-family,
    ui-sans-serif,
    system-ui,
    sans-serif,
    'Apple Color Emoji',
    'Segoe UI Emoji',
    'Segoe UI Symbol',
    'Noto Color Emoji'
  ); /* 4 */
  font-feature-settings: --theme(--default-font-feature-settings, normal); /* 5 */
  font-variation-settings: --theme(--default-font-variation-settings, normal); /* 6 */
  -webkit-tap-highlight-color: transparent; /* 7 */
}

/*
  1. Add the correct height in Firefox.
  2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
  3. Reset the default border style to a 1px solid border.
*/

hr {
  height: 0; /* 1 */
  color: inherit; /* 2 */
  border-top-width: 1px; /* 3 */
}

/*
  Add the correct text decoration in Chrome, Edge, and Safari.
*/

abbr:where([title]) {
  -webkit-text-decoration: underline dotted;
  text-decoration: underline dotted;
}

/*
  Remove the default font size and weight for headings.
*/

h1,
h2,
h3,
h4,
h5,
h6 {
  font-size: inherit;
  font-weight: inherit;
}

/*
  Reset links to optimize for opt-in styling instead of opt-out.
*/

a {
  color: inherit;
  -webkit-text-decoration: inherit;
  text-decoration: inherit;
}

/*
  Add the correct font weight in Edge and Safari.
*/

b,
strong {
  font-weight: bolder;
}

/*
  1. Use the user's configured \`mono\` font-family by default.
  2. Use the user's configured \`mono\` font-feature-settings by default.
  3. Use the user's configured \`mono\` font-variation-settings by default.
  4. Correct the odd \`em\` font sizing in all browsers.
*/

code,
kbd,
samp,
pre {
  font-family: --theme(
    --default-mono-font-family,
    ui-monospace,
    SFMono-Regular,
    Menlo,
    Monaco,
    Consolas,
    'Liberation Mono',
    'Courier New',
    monospace
  ); /* 1 */
  font-feature-settings: --theme(--default-mono-font-feature-settings, normal); /* 2 */
  font-variation-settings: --theme(--default-mono-font-variation-settings, normal); /* 3 */
  font-size: 1em; /* 4 */
}

/*
  Add the correct font size in all browsers.
*/

small {
  font-size: 80%;
}

/*
  Prevent \`sub\` and \`sup\` elements from affecting the line height in all browsers.
*/

sub,
sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

/*
  1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
  2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
  3. Remove gaps between table borders by default.
*/

table {
  text-indent: 0; /* 1 */
  border-color: inherit; /* 2 */
  border-collapse: collapse; /* 3 */
}

/*
  Use the modern Firefox focus style for all focusable elements.
*/

:-moz-focusring {
  outline: auto;
}

/*
  Add the correct vertical alignment in Chrome and Firefox.
*/

progress {
  vertical-align: baseline;
}

/*
  Add the correct display in Chrome and Safari.
*/

summary {
  display: list-item;
}

/*
  Make lists unstyled by default.
*/

ol,
ul,
menu {
  list-style: none;
}

/*
  1. Make replaced elements \`display: block\` by default. (https://github.com/mozdevs/cssremedy/issues/14)
  2. Add \`vertical-align: middle\` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)
      This can trigger a poorly considered lint error in some tools but is included by design.
*/

img,
svg,
video,
canvas,
audio,
iframe,
embed,
object {
  display: block; /* 1 */
  vertical-align: middle; /* 2 */
}

/*
  Constrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)
*/

img,
video {
  max-width: 100%;
  height: auto;
}

/*
  1. Inherit font styles in all browsers.
  2. Remove border radius in all browsers.
  3. Remove background color in all browsers.
  4. Ensure consistent opacity for disabled states in all browsers.
*/

button,
input,
select,
optgroup,
textarea,
::file-selector-button {
  font: inherit; /* 1 */
  font-feature-settings: inherit; /* 1 */
  font-variation-settings: inherit; /* 1 */
  letter-spacing: inherit; /* 1 */
  color: inherit; /* 1 */
  border-radius: 0; /* 2 */
  background-color: transparent; /* 3 */
  opacity: 1; /* 4 */
}

/*
  Restore default font weight.
*/

:where(select:is([multiple], [size])) optgroup {
  font-weight: bolder;
}

/*
  Restore indentation.
*/

:where(select:is([multiple], [size])) optgroup option {
  padding-inline-start: 20px;
}

/*
  Restore space after button.
*/

::file-selector-button {
  margin-inline-end: 4px;
}

/*
  Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)
*/

::placeholder {
  opacity: 1;
}

/*
  Set the default placeholder color to a semi-transparent version of the current text color in browsers that do not
  crash when using \`color-mix(\u2026)\` with \`currentcolor\`. (https://github.com/tailwindlabs/tailwindcss/issues/17194)
*/

@supports (not (-webkit-appearance: -apple-pay-button)) /* Not Safari */ or
  (contain-intrinsic-size: 1px) /* Safari 17+ */ {
  ::placeholder {
    color: color-mix(in oklab, currentcolor 50%, transparent);
  }
}

/*
  Prevent resizing textareas horizontally by default.
*/

textarea {
  resize: vertical;
}

/*
  Remove the inner padding in Chrome and Safari on macOS.
*/

::-webkit-search-decoration {
  -webkit-appearance: none;
}

/*
  1. Ensure date/time inputs have the same height when empty in iOS Safari.
  2. Ensure text alignment can be changed on date/time inputs in iOS Safari.
*/

::-webkit-date-and-time-value {
  min-height: 1lh; /* 1 */
  text-align: inherit; /* 2 */
}

/*
  Prevent height from changing on date/time inputs in macOS Safari when the input is set to \`display: block\`.
*/

::-webkit-datetime-edit {
  display: inline-flex;
}

/*
  Remove excess padding from pseudo-elements in date/time inputs to ensure consistent height across browsers.
*/

::-webkit-datetime-edit-fields-wrapper {
  padding: 0;
}

::-webkit-datetime-edit,
::-webkit-datetime-edit-year-field,
::-webkit-datetime-edit-month-field,
::-webkit-datetime-edit-day-field,
::-webkit-datetime-edit-hour-field,
::-webkit-datetime-edit-minute-field,
::-webkit-datetime-edit-second-field,
::-webkit-datetime-edit-millisecond-field,
::-webkit-datetime-edit-meridiem-field {
  padding-block: 0;
}

/*
  Center dropdown marker shown on inputs with paired \`<datalist>\`s in Chrome. (https://github.com/tailwindlabs/tailwindcss/issues/18499)
*/

::-webkit-calendar-picker-indicator {
  line-height: 1;
}

/*
  Remove the additional \`:invalid\` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)
*/

:-moz-ui-invalid {
  box-shadow: none;
}

/*
  Correct the inability to style the border radius in iOS Safari.
*/

button,
input:where([type='button'], [type='reset'], [type='submit']),
::file-selector-button {
  appearance: button;
}

/*
  Correct the cursor style of increment and decrement buttons in Safari.
*/

::-webkit-inner-spin-button,
::-webkit-outer-spin-button {
  height: auto;
}

/*
  Make elements with the HTML hidden attribute stay hidden by default.
*/

[hidden]:where(:not([hidden='until-found'])) {
  display: none !important;
}
`;
  var Ti = `@theme default {
  --font-sans:
    ui-sans-serif, system-ui, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol',
    'Noto Color Emoji';
  --font-serif: ui-serif, Georgia, Cambria, 'Times New Roman', Times, serif;
  --font-mono:
    ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New',
    monospace;

  --color-red-50: oklch(97.1% 0.013 17.38);
  --color-red-100: oklch(93.6% 0.032 17.717);
  --color-red-200: oklch(88.5% 0.062 18.334);
  --color-red-300: oklch(80.8% 0.114 19.571);
  --color-red-400: oklch(70.4% 0.191 22.216);
  --color-red-500: oklch(63.7% 0.237 25.331);
  --color-red-600: oklch(57.7% 0.245 27.325);
  --color-red-700: oklch(50.5% 0.213 27.518);
  --color-red-800: oklch(44.4% 0.177 26.899);
  --color-red-900: oklch(39.6% 0.141 25.723);
  --color-red-950: oklch(25.8% 0.092 26.042);

  --color-orange-50: oklch(98% 0.016 73.684);
  --color-orange-100: oklch(95.4% 0.038 75.164);
  --color-orange-200: oklch(90.1% 0.076 70.697);
  --color-orange-300: oklch(83.7% 0.128 66.29);
  --color-orange-400: oklch(75% 0.183 55.934);
  --color-orange-500: oklch(70.5% 0.213 47.604);
  --color-orange-600: oklch(64.6% 0.222 41.116);
  --color-orange-700: oklch(55.3% 0.195 38.402);
  --color-orange-800: oklch(47% 0.157 37.304);
  --color-orange-900: oklch(40.8% 0.123 38.172);
  --color-orange-950: oklch(26.6% 0.079 36.259);

  --color-amber-50: oklch(98.7% 0.022 95.277);
  --color-amber-100: oklch(96.2% 0.059 95.617);
  --color-amber-200: oklch(92.4% 0.12 95.746);
  --color-amber-300: oklch(87.9% 0.169 91.605);
  --color-amber-400: oklch(82.8% 0.189 84.429);
  --color-amber-500: oklch(76.9% 0.188 70.08);
  --color-amber-600: oklch(66.6% 0.179 58.318);
  --color-amber-700: oklch(55.5% 0.163 48.998);
  --color-amber-800: oklch(47.3% 0.137 46.201);
  --color-amber-900: oklch(41.4% 0.112 45.904);
  --color-amber-950: oklch(27.9% 0.077 45.635);

  --color-yellow-50: oklch(98.7% 0.026 102.212);
  --color-yellow-100: oklch(97.3% 0.071 103.193);
  --color-yellow-200: oklch(94.5% 0.129 101.54);
  --color-yellow-300: oklch(90.5% 0.182 98.111);
  --color-yellow-400: oklch(85.2% 0.199 91.936);
  --color-yellow-500: oklch(79.5% 0.184 86.047);
  --color-yellow-600: oklch(68.1% 0.162 75.834);
  --color-yellow-700: oklch(55.4% 0.135 66.442);
  --color-yellow-800: oklch(47.6% 0.114 61.907);
  --color-yellow-900: oklch(42.1% 0.095 57.708);
  --color-yellow-950: oklch(28.6% 0.066 53.813);

  --color-lime-50: oklch(98.6% 0.031 120.757);
  --color-lime-100: oklch(96.7% 0.067 122.328);
  --color-lime-200: oklch(93.8% 0.127 124.321);
  --color-lime-300: oklch(89.7% 0.196 126.665);
  --color-lime-400: oklch(84.1% 0.238 128.85);
  --color-lime-500: oklch(76.8% 0.233 130.85);
  --color-lime-600: oklch(64.8% 0.2 131.684);
  --color-lime-700: oklch(53.2% 0.157 131.589);
  --color-lime-800: oklch(45.3% 0.124 130.933);
  --color-lime-900: oklch(40.5% 0.101 131.063);
  --color-lime-950: oklch(27.4% 0.072 132.109);

  --color-green-50: oklch(98.2% 0.018 155.826);
  --color-green-100: oklch(96.2% 0.044 156.743);
  --color-green-200: oklch(92.5% 0.084 155.995);
  --color-green-300: oklch(87.1% 0.15 154.449);
  --color-green-400: oklch(79.2% 0.209 151.711);
  --color-green-500: oklch(72.3% 0.219 149.579);
  --color-green-600: oklch(62.7% 0.194 149.214);
  --color-green-700: oklch(52.7% 0.154 150.069);
  --color-green-800: oklch(44.8% 0.119 151.328);
  --color-green-900: oklch(39.3% 0.095 152.535);
  --color-green-950: oklch(26.6% 0.065 152.934);

  --color-emerald-50: oklch(97.9% 0.021 166.113);
  --color-emerald-100: oklch(95% 0.052 163.051);
  --color-emerald-200: oklch(90.5% 0.093 164.15);
  --color-emerald-300: oklch(84.5% 0.143 164.978);
  --color-emerald-400: oklch(76.5% 0.177 163.223);
  --color-emerald-500: oklch(69.6% 0.17 162.48);
  --color-emerald-600: oklch(59.6% 0.145 163.225);
  --color-emerald-700: oklch(50.8% 0.118 165.612);
  --color-emerald-800: oklch(43.2% 0.095 166.913);
  --color-emerald-900: oklch(37.8% 0.077 168.94);
  --color-emerald-950: oklch(26.2% 0.051 172.552);

  --color-teal-50: oklch(98.4% 0.014 180.72);
  --color-teal-100: oklch(95.3% 0.051 180.801);
  --color-teal-200: oklch(91% 0.096 180.426);
  --color-teal-300: oklch(85.5% 0.138 181.071);
  --color-teal-400: oklch(77.7% 0.152 181.912);
  --color-teal-500: oklch(70.4% 0.14 182.503);
  --color-teal-600: oklch(60% 0.118 184.704);
  --color-teal-700: oklch(51.1% 0.096 186.391);
  --color-teal-800: oklch(43.7% 0.078 188.216);
  --color-teal-900: oklch(38.6% 0.063 188.416);
  --color-teal-950: oklch(27.7% 0.046 192.524);

  --color-cyan-50: oklch(98.4% 0.019 200.873);
  --color-cyan-100: oklch(95.6% 0.045 203.388);
  --color-cyan-200: oklch(91.7% 0.08 205.041);
  --color-cyan-300: oklch(86.5% 0.127 207.078);
  --color-cyan-400: oklch(78.9% 0.154 211.53);
  --color-cyan-500: oklch(71.5% 0.143 215.221);
  --color-cyan-600: oklch(60.9% 0.126 221.723);
  --color-cyan-700: oklch(52% 0.105 223.128);
  --color-cyan-800: oklch(45% 0.085 224.283);
  --color-cyan-900: oklch(39.8% 0.07 227.392);
  --color-cyan-950: oklch(30.2% 0.056 229.695);

  --color-sky-50: oklch(97.7% 0.013 236.62);
  --color-sky-100: oklch(95.1% 0.026 236.824);
  --color-sky-200: oklch(90.1% 0.058 230.902);
  --color-sky-300: oklch(82.8% 0.111 230.318);
  --color-sky-400: oklch(74.6% 0.16 232.661);
  --color-sky-500: oklch(68.5% 0.169 237.323);
  --color-sky-600: oklch(58.8% 0.158 241.966);
  --color-sky-700: oklch(50% 0.134 242.749);
  --color-sky-800: oklch(44.3% 0.11 240.79);
  --color-sky-900: oklch(39.1% 0.09 240.876);
  --color-sky-950: oklch(29.3% 0.066 243.157);

  --color-blue-50: oklch(97% 0.014 254.604);
  --color-blue-100: oklch(93.2% 0.032 255.585);
  --color-blue-200: oklch(88.2% 0.059 254.128);
  --color-blue-300: oklch(80.9% 0.105 251.813);
  --color-blue-400: oklch(70.7% 0.165 254.624);
  --color-blue-500: oklch(62.3% 0.214 259.815);
  --color-blue-600: oklch(54.6% 0.245 262.881);
  --color-blue-700: oklch(48.8% 0.243 264.376);
  --color-blue-800: oklch(42.4% 0.199 265.638);
  --color-blue-900: oklch(37.9% 0.146 265.522);
  --color-blue-950: oklch(28.2% 0.091 267.935);

  --color-indigo-50: oklch(96.2% 0.018 272.314);
  --color-indigo-100: oklch(93% 0.034 272.788);
  --color-indigo-200: oklch(87% 0.065 274.039);
  --color-indigo-300: oklch(78.5% 0.115 274.713);
  --color-indigo-400: oklch(67.3% 0.182 276.935);
  --color-indigo-500: oklch(58.5% 0.233 277.117);
  --color-indigo-600: oklch(51.1% 0.262 276.966);
  --color-indigo-700: oklch(45.7% 0.24 277.023);
  --color-indigo-800: oklch(39.8% 0.195 277.366);
  --color-indigo-900: oklch(35.9% 0.144 278.697);
  --color-indigo-950: oklch(25.7% 0.09 281.288);

  --color-violet-50: oklch(96.9% 0.016 293.756);
  --color-violet-100: oklch(94.3% 0.029 294.588);
  --color-violet-200: oklch(89.4% 0.057 293.283);
  --color-violet-300: oklch(81.1% 0.111 293.571);
  --color-violet-400: oklch(70.2% 0.183 293.541);
  --color-violet-500: oklch(60.6% 0.25 292.717);
  --color-violet-600: oklch(54.1% 0.281 293.009);
  --color-violet-700: oklch(49.1% 0.27 292.581);
  --color-violet-800: oklch(43.2% 0.232 292.759);
  --color-violet-900: oklch(38% 0.189 293.745);
  --color-violet-950: oklch(28.3% 0.141 291.089);

  --color-purple-50: oklch(97.7% 0.014 308.299);
  --color-purple-100: oklch(94.6% 0.033 307.174);
  --color-purple-200: oklch(90.2% 0.063 306.703);
  --color-purple-300: oklch(82.7% 0.119 306.383);
  --color-purple-400: oklch(71.4% 0.203 305.504);
  --color-purple-500: oklch(62.7% 0.265 303.9);
  --color-purple-600: oklch(55.8% 0.288 302.321);
  --color-purple-700: oklch(49.6% 0.265 301.924);
  --color-purple-800: oklch(43.8% 0.218 303.724);
  --color-purple-900: oklch(38.1% 0.176 304.987);
  --color-purple-950: oklch(29.1% 0.149 302.717);

  --color-fuchsia-50: oklch(97.7% 0.017 320.058);
  --color-fuchsia-100: oklch(95.2% 0.037 318.852);
  --color-fuchsia-200: oklch(90.3% 0.076 319.62);
  --color-fuchsia-300: oklch(83.3% 0.145 321.434);
  --color-fuchsia-400: oklch(74% 0.238 322.16);
  --color-fuchsia-500: oklch(66.7% 0.295 322.15);
  --color-fuchsia-600: oklch(59.1% 0.293 322.896);
  --color-fuchsia-700: oklch(51.8% 0.253 323.949);
  --color-fuchsia-800: oklch(45.2% 0.211 324.591);
  --color-fuchsia-900: oklch(40.1% 0.17 325.612);
  --color-fuchsia-950: oklch(29.3% 0.136 325.661);

  --color-pink-50: oklch(97.1% 0.014 343.198);
  --color-pink-100: oklch(94.8% 0.028 342.258);
  --color-pink-200: oklch(89.9% 0.061 343.231);
  --color-pink-300: oklch(82.3% 0.12 346.018);
  --color-pink-400: oklch(71.8% 0.202 349.761);
  --color-pink-500: oklch(65.6% 0.241 354.308);
  --color-pink-600: oklch(59.2% 0.249 0.584);
  --color-pink-700: oklch(52.5% 0.223 3.958);
  --color-pink-800: oklch(45.9% 0.187 3.815);
  --color-pink-900: oklch(40.8% 0.153 2.432);
  --color-pink-950: oklch(28.4% 0.109 3.907);

  --color-rose-50: oklch(96.9% 0.015 12.422);
  --color-rose-100: oklch(94.1% 0.03 12.58);
  --color-rose-200: oklch(89.2% 0.058 10.001);
  --color-rose-300: oklch(81% 0.117 11.638);
  --color-rose-400: oklch(71.2% 0.194 13.428);
  --color-rose-500: oklch(64.5% 0.246 16.439);
  --color-rose-600: oklch(58.6% 0.253 17.585);
  --color-rose-700: oklch(51.4% 0.222 16.935);
  --color-rose-800: oklch(45.5% 0.188 13.697);
  --color-rose-900: oklch(41% 0.159 10.272);
  --color-rose-950: oklch(27.1% 0.105 12.094);

  --color-slate-50: oklch(98.4% 0.003 247.858);
  --color-slate-100: oklch(96.8% 0.007 247.896);
  --color-slate-200: oklch(92.9% 0.013 255.508);
  --color-slate-300: oklch(86.9% 0.022 252.894);
  --color-slate-400: oklch(70.4% 0.04 256.788);
  --color-slate-500: oklch(55.4% 0.046 257.417);
  --color-slate-600: oklch(44.6% 0.043 257.281);
  --color-slate-700: oklch(37.2% 0.044 257.287);
  --color-slate-800: oklch(27.9% 0.041 260.031);
  --color-slate-900: oklch(20.8% 0.042 265.755);
  --color-slate-950: oklch(12.9% 0.042 264.695);

  --color-gray-50: oklch(98.5% 0.002 247.839);
  --color-gray-100: oklch(96.7% 0.003 264.542);
  --color-gray-200: oklch(92.8% 0.006 264.531);
  --color-gray-300: oklch(87.2% 0.01 258.338);
  --color-gray-400: oklch(70.7% 0.022 261.325);
  --color-gray-500: oklch(55.1% 0.027 264.364);
  --color-gray-600: oklch(44.6% 0.03 256.802);
  --color-gray-700: oklch(37.3% 0.034 259.733);
  --color-gray-800: oklch(27.8% 0.033 256.848);
  --color-gray-900: oklch(21% 0.034 264.665);
  --color-gray-950: oklch(13% 0.028 261.692);

  --color-zinc-50: oklch(98.5% 0 0);
  --color-zinc-100: oklch(96.7% 0.001 286.375);
  --color-zinc-200: oklch(92% 0.004 286.32);
  --color-zinc-300: oklch(87.1% 0.006 286.286);
  --color-zinc-400: oklch(70.5% 0.015 286.067);
  --color-zinc-500: oklch(55.2% 0.016 285.938);
  --color-zinc-600: oklch(44.2% 0.017 285.786);
  --color-zinc-700: oklch(37% 0.013 285.805);
  --color-zinc-800: oklch(27.4% 0.006 286.033);
  --color-zinc-900: oklch(21% 0.006 285.885);
  --color-zinc-950: oklch(14.1% 0.005 285.823);

  --color-neutral-50: oklch(98.5% 0 0);
  --color-neutral-100: oklch(97% 0 0);
  --color-neutral-200: oklch(92.2% 0 0);
  --color-neutral-300: oklch(87% 0 0);
  --color-neutral-400: oklch(70.8% 0 0);
  --color-neutral-500: oklch(55.6% 0 0);
  --color-neutral-600: oklch(43.9% 0 0);
  --color-neutral-700: oklch(37.1% 0 0);
  --color-neutral-800: oklch(26.9% 0 0);
  --color-neutral-900: oklch(20.5% 0 0);
  --color-neutral-950: oklch(14.5% 0 0);

  --color-stone-50: oklch(98.5% 0.001 106.423);
  --color-stone-100: oklch(97% 0.001 106.424);
  --color-stone-200: oklch(92.3% 0.003 48.717);
  --color-stone-300: oklch(86.9% 0.005 56.366);
  --color-stone-400: oklch(70.9% 0.01 56.259);
  --color-stone-500: oklch(55.3% 0.013 58.071);
  --color-stone-600: oklch(44.4% 0.011 73.639);
  --color-stone-700: oklch(37.4% 0.01 67.558);
  --color-stone-800: oklch(26.8% 0.007 34.298);
  --color-stone-900: oklch(21.6% 0.006 56.043);
  --color-stone-950: oklch(14.7% 0.004 49.25);

  --color-black: #000;
  --color-white: #fff;

  --spacing: 0.25rem;

  --breakpoint-sm: 40rem;
  --breakpoint-md: 48rem;
  --breakpoint-lg: 64rem;
  --breakpoint-xl: 80rem;
  --breakpoint-2xl: 96rem;

  --container-3xs: 16rem;
  --container-2xs: 18rem;
  --container-xs: 20rem;
  --container-sm: 24rem;
  --container-md: 28rem;
  --container-lg: 32rem;
  --container-xl: 36rem;
  --container-2xl: 42rem;
  --container-3xl: 48rem;
  --container-4xl: 56rem;
  --container-5xl: 64rem;
  --container-6xl: 72rem;
  --container-7xl: 80rem;

  --text-xs: 0.75rem;
  --text-xs--line-height: calc(1 / 0.75);
  --text-sm: 0.875rem;
  --text-sm--line-height: calc(1.25 / 0.875);
  --text-base: 1rem;
  --text-base--line-height: calc(1.5 / 1);
  --text-lg: 1.125rem;
  --text-lg--line-height: calc(1.75 / 1.125);
  --text-xl: 1.25rem;
  --text-xl--line-height: calc(1.75 / 1.25);
  --text-2xl: 1.5rem;
  --text-2xl--line-height: calc(2 / 1.5);
  --text-3xl: 1.875rem;
  --text-3xl--line-height: calc(2.25 / 1.875);
  --text-4xl: 2.25rem;
  --text-4xl--line-height: calc(2.5 / 2.25);
  --text-5xl: 3rem;
  --text-5xl--line-height: 1;
  --text-6xl: 3.75rem;
  --text-6xl--line-height: 1;
  --text-7xl: 4.5rem;
  --text-7xl--line-height: 1;
  --text-8xl: 6rem;
  --text-8xl--line-height: 1;
  --text-9xl: 8rem;
  --text-9xl--line-height: 1;

  --font-weight-thin: 100;
  --font-weight-extralight: 200;
  --font-weight-light: 300;
  --font-weight-normal: 400;
  --font-weight-medium: 500;
  --font-weight-semibold: 600;
  --font-weight-bold: 700;
  --font-weight-extrabold: 800;
  --font-weight-black: 900;

  --tracking-tighter: -0.05em;
  --tracking-tight: -0.025em;
  --tracking-normal: 0em;
  --tracking-wide: 0.025em;
  --tracking-wider: 0.05em;
  --tracking-widest: 0.1em;

  --leading-tight: 1.25;
  --leading-snug: 1.375;
  --leading-normal: 1.5;
  --leading-relaxed: 1.625;
  --leading-loose: 2;

  --radius-xs: 0.125rem;
  --radius-sm: 0.25rem;
  --radius-md: 0.375rem;
  --radius-lg: 0.5rem;
  --radius-xl: 0.75rem;
  --radius-2xl: 1rem;
  --radius-3xl: 1.5rem;
  --radius-4xl: 2rem;

  --shadow-2xs: 0 1px rgb(0 0 0 / 0.05);
  --shadow-xs: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --shadow-sm: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
  --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
  --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
  --shadow-2xl: 0 25px 50px -12px rgb(0 0 0 / 0.25);

  --inset-shadow-2xs: inset 0 1px rgb(0 0 0 / 0.05);
  --inset-shadow-xs: inset 0 1px 1px rgb(0 0 0 / 0.05);
  --inset-shadow-sm: inset 0 2px 4px rgb(0 0 0 / 0.05);

  --drop-shadow-xs: 0 1px 1px rgb(0 0 0 / 0.05);
  --drop-shadow-sm: 0 1px 2px rgb(0 0 0 / 0.15);
  --drop-shadow-md: 0 3px 3px rgb(0 0 0 / 0.12);
  --drop-shadow-lg: 0 4px 4px rgb(0 0 0 / 0.15);
  --drop-shadow-xl: 0 9px 7px rgb(0 0 0 / 0.1);
  --drop-shadow-2xl: 0 25px 25px rgb(0 0 0 / 0.15);

  --text-shadow-2xs: 0px 1px 0px rgb(0 0 0 / 0.15);
  --text-shadow-xs: 0px 1px 1px rgb(0 0 0 / 0.2);
  --text-shadow-sm:
    0px 1px 0px rgb(0 0 0 / 0.075), 0px 1px 1px rgb(0 0 0 / 0.075), 0px 2px 2px rgb(0 0 0 / 0.075);
  --text-shadow-md:
    0px 1px 1px rgb(0 0 0 / 0.1), 0px 1px 2px rgb(0 0 0 / 0.1), 0px 2px 4px rgb(0 0 0 / 0.1);
  --text-shadow-lg:
    0px 1px 2px rgb(0 0 0 / 0.1), 0px 3px 2px rgb(0 0 0 / 0.1), 0px 4px 8px rgb(0 0 0 / 0.1);

  --ease-in: cubic-bezier(0.4, 0, 1, 1);
  --ease-out: cubic-bezier(0, 0, 0.2, 1);
  --ease-in-out: cubic-bezier(0.4, 0, 0.2, 1);

  --animate-spin: spin 1s linear infinite;
  --animate-ping: ping 1s cubic-bezier(0, 0, 0.2, 1) infinite;
  --animate-pulse: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
  --animate-bounce: bounce 1s infinite;

  @keyframes spin {
    to {
      transform: rotate(360deg);
    }
  }

  @keyframes ping {
    75%,
    100% {
      transform: scale(2);
      opacity: 0;
    }
  }

  @keyframes pulse {
    50% {
      opacity: 0.5;
    }
  }

  @keyframes bounce {
    0%,
    100% {
      transform: translateY(-25%);
      animation-timing-function: cubic-bezier(0.8, 0, 1, 1);
    }

    50% {
      transform: none;
      animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
    }
  }

  --blur-xs: 4px;
  --blur-sm: 8px;
  --blur-md: 12px;
  --blur-lg: 16px;
  --blur-xl: 24px;
  --blur-2xl: 40px;
  --blur-3xl: 64px;

  --perspective-dramatic: 100px;
  --perspective-near: 300px;
  --perspective-normal: 500px;
  --perspective-midrange: 800px;
  --perspective-distant: 1200px;

  --aspect-video: 16 / 9;

  --default-transition-duration: 150ms;
  --default-transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  --default-font-family: --theme(--font-sans, initial);
  --default-font-feature-settings: --theme(--font-sans--font-feature-settings, initial);
  --default-font-variation-settings: --theme(--font-sans--font-variation-settings, initial);
  --default-mono-font-family: --theme(--font-mono, initial);
  --default-mono-font-feature-settings: --theme(--font-mono--font-feature-settings, initial);
  --default-mono-font-variation-settings: --theme(--font-mono--font-variation-settings, initial);
}

/* Deprecated */
@theme default inline reference {
  --blur: 8px;
  --shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
  --shadow-inner: inset 0 2px 4px 0 rgb(0 0 0 / 0.05);
  --drop-shadow: 0 1px 2px rgb(0 0 0 / 0.1), 0 1px 1px rgb(0 0 0 / 0.06);
  --radius: 0.25rem;
  --max-width-prose: 65ch;
}
`;
  var Ri = `@tailwind utilities;
`;
  var Be = { index: Vi, preflight: Ei, theme: Ti, utilities: Ri };
  var kt = class {
    start(r) {
      performance.mark(`${r} (start)`);
    }
    end(r, i) {
      performance.mark(`${r} (end)`),
        performance.measure(r, {
          start: `${r} (start)`,
          end: `${r} (end)`,
          detail: i,
        });
    }
    hit(r, i) {
      performance.mark(r, { detail: i });
    }
    error(r) {
      throw (performance.mark("(error)", { detail: { error: `${r}` } }), r);
    }
  };
  var Oi = "text/tailwindcss",
    vt,
    Ht = new Set(),
    qt = "",
    Gt = document.createElement("style"),
    Pi = Promise.resolve(),
    Tn = 1,
    re = new kt();
  async function Rn() {
    re.start("Create compiler"), re.start("Reading Stylesheets");
    let e = document.querySelectorAll(`style[type="${Oi}"]`),
      r = "";
    for (let i of e)
      _i(i),
        (r +=
          i.textContent +
          `
`);
    if (
      (r.includes("@import") || (r = `@import "tailwindcss";${r}`),
      re.end("Reading Stylesheets", { size: r.length, changed: qt !== r }),
      qt !== r)
    ) {
      (qt = r), re.start("Compile CSS");
      try {
        vt = await Ni(r, { base: "/", loadStylesheet: Pn, loadModule: On });
      } finally {
        re.end("Compile CSS"), re.end("Create compiler");
      }
      Ht.clear();
    }
  }
  async function Pn(e, r) {
    function i() {
      if (e === "tailwindcss")
        return {
          path: "virtual:tailwindcss/index.css",
          base: r,
          content: Be.index,
        };
      if (
        e === "tailwindcss/preflight" ||
        e === "tailwindcss/preflight.css" ||
        e === "./preflight.css"
      )
        return {
          path: "virtual:tailwindcss/preflight.css",
          base: r,
          content: Be.preflight,
        };
      if (
        e === "tailwindcss/theme" ||
        e === "tailwindcss/theme.css" ||
        e === "./theme.css"
      )
        return {
          path: "virtual:tailwindcss/theme.css",
          base: r,
          content: Be.theme,
        };
      if (
        e === "tailwindcss/utilities" ||
        e === "tailwindcss/utilities.css" ||
        e === "./utilities.css"
      )
        return {
          path: "virtual:tailwindcss/utilities.css",
          base: r,
          content: Be.utilities,
        };
      throw new Error(`The browser build does not support @import for "${e}"`);
    }
    try {
      let t = i();
      return (
        re.hit("Loaded stylesheet", { id: e, base: r, size: t.content.length }),
        t
      );
    } catch (t) {
      throw (
        (re.hit("Failed to load stylesheet", {
          id: e,
          base: r,
          error: t.message ?? t,
        }),
        t)
      );
    }
  }
  async function On() {
    throw new Error(
      "The browser build does not support plugins or config files."
    );
  }
  async function _n(e) {
    if (!vt) return;
    let r = new Set();
    re.start("Collect classes");
    for (let i of document.querySelectorAll("[class]"))
      for (let t of i.classList) Ht.has(t) || (Ht.add(t), r.add(t));
    re.end("Collect classes", { count: r.size }),
      !(r.size === 0 && e === "incremental") &&
        (re.start("Build utilities"),
        (Gt.textContent = vt.build(Array.from(r))),
        re.end("Build utilities"));
  }
  function wt(e) {
    async function r() {
      if (!vt && e !== "full") return;
      let i = Tn++;
      re.start(`Build #${i} (${e})`),
        e === "full" && (await Rn()),
        re.start("Build"),
        await _n(e),
        re.end("Build"),
        re.end(`Build #${i} (${e})`);
    }
    Pi = Pi.then(r).catch((i) => re.error(i));
  }
  var Dn = new MutationObserver(() => wt("full"));
  function _i(e) {
    Dn.observe(e, {
      attributes: !0,
      attributeFilter: ["type"],
      characterData: !0,
      subtree: !0,
      childList: !0,
    });
  }
  new MutationObserver((e) => {
    let r = 0,
      i = 0;
    for (let t of e) {
      for (let o of t.addedNodes)
        o.nodeType === Node.ELEMENT_NODE &&
          o.tagName === "STYLE" &&
          o.getAttribute("type") === Oi &&
          (_i(o), r++);
      for (let o of t.addedNodes) o.nodeType === 1 && o !== Gt && i++;
      t.type === "attributes" && i++;
    }
    if (r > 0) return wt("full");
    if (i > 0) return wt("incremental");
  }).observe(document.documentElement, {
    attributes: !0,
    attributeFilter: ["class"],
    childList: !0,
    subtree: !0,
  });
  wt("full");
  document.head.append(Gt);
})();
